import React, { useEffect, useState } from 'react';
import { initLogic } from './logic.ts';

export function EidLogo({ className = "h-12", style }: { className?: string; style?: React.CSSProperties }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 1000 480" 
      className={className}
      style={style}
    >
      {/* 1. Circle with DNA Double Helix */}
      <g transform="translate(60, 0)">
        {/* Outer Circular frame in EID violet/purple */}
        <circle 
          cx="180" 
          cy="180" 
          r="160" 
          fill="none" 
          stroke="#7C3AED" 
          strokeWidth="10" 
        />
        
        {/* DNA Helix vertical curves */}
        {/* First Strand (Sine-like Wave) */}
        <path 
          d="M 130 70 Q 230 150 130 220 T 130 290" 
          fill="none" 
          stroke="#F43F5E" 
          strokeWidth="8" 
          strokeLinecap="round"
        />
        {/* Second Strand (Complementary Sine Wave) */}
        <path 
          d="M 230 70 Q 130 150 230 220 T 230 290" 
          fill="none" 
          stroke="#F43F5E" 
          strokeWidth="8" 
          strokeLinecap="round"
        />
        
        {/* DNA Base Pairs with circular connectors */}
        {/* Pair 1 */}
        <line x1="135" y1="90" x2="225" y2="90" stroke="#F43F5E" strokeWidth="5" />
        <circle cx="135" cy="90" r="10" fill="#F43F5E" />
        <circle cx="225" cy="90" r="10" fill="#F43F5E" />

        {/* Pair 2 */}
        <line x1="160" y1="130" x2="200" y2="130" stroke="#F43F5E" strokeWidth="5" />
        <circle cx="160" cy="130" r="10" fill="#F43F5E" />
        <circle cx="200" cy="130" r="10" fill="#F43F5E" />

        {/* Crossing point interaction */}
        <circle cx="180" cy="175" r="12" fill="#F43F5E" />

        {/* Pair 3 */}
        <line x1="160" y1="220" x2="200" y2="220" stroke="#F43F5E" strokeWidth="5" />
        <circle cx="160" cy="220" r="10" fill="#F43F5E" />
        <circle cx="200" cy="220" r="10" fill="#F43F5E" />

        {/* Pair 4 */}
        <line x1="135" y1="260" x2="225" y2="260" stroke="#F43F5E" strokeWidth="5" />
        <circle cx="135" cy="260" r="10" fill="#F43F5E" />
        <circle cx="225" cy="260" r="10" fill="#F43F5E" />
      </g>
      
      {/* 2. EID Typography */}
      <g transform="translate(460, 0)">
        {/* Outlined glowing effect text */}
        <text 
          x="0" 
          y="260" 
          fontFamily="'Inter', 'Space Grotesk', system-ui, sans-serif" 
          fontSize="240" 
          fontWeight="900" 
          fill="none" 
          stroke="#E9D5FF" 
          strokeWidth="20"
          letterSpacing="24"
        >
          EID
        </text>
        <text 
          x="0" 
          y="260" 
          fontFamily="'Inter', 'Space Grotesk', system-ui, sans-serif" 
          fontSize="240" 
          fontWeight="900" 
          fill="#FAF5FF" 
          stroke="#7C3AED" 
          strokeWidth="8"
          letterSpacing="24"
        >
          EID
        </text>
      </g>
      
      {/* 3. Horizontal Lines */}
      <line 
        x1="40" 
        y1="360" 
        x2="960" 
        y2="360" 
        stroke="#7C3AED" 
        strokeWidth="6" 
      />
      <line 
        x1="40" 
        y1="450" 
        x2="960" 
        y2="450" 
        stroke="#7C3AED" 
        strokeWidth="4" 
      />
      
      {/* 4. Text: EMERGING INFECTIOUS DISEASE (EID) GROUP */}
      <text 
        x="500" 
        y="420" 
        fontFamily="'Inter', 'Space Grotesk', system-ui, sans-serif" 
        fontSize="32" 
        fontWeight="800" 
        fill="#000000" 
        textAnchor="middle" 
        letterSpacing="6"
      >
        EMERGING INFECTIOUS DISEASE (EID) GROUP
      </text>
    </svg>
  );
}

export function UnifiedLogo({ 
  className = "h-12", 
  style, 
  customLogoUrl 
}: { 
  className?: string; 
  style?: React.CSSProperties; 
  customLogoUrl?: string;
}) {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [customLogoUrl]);

  if (customLogoUrl && !hasError) {
    return (
      <img 
        src={customLogoUrl} 
        className={`${className} shrink-0 object-contain`} 
        style={style} 
        alt="EID Logo" 
        referrerPolicy="no-referrer"
        onError={() => {
          setHasError(true);
        }}
      />
    );
  }

  return <EidLogo className={className} style={style} />;
}

export function ReviewAidLogo({ className = "h-12", style }: { className?: string; style?: React.CSSProperties }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 500 500" 
      className={className} 
      style={style}
    >
      {/* Speech bubble outline */}
      <path 
        d="M 143 180 A 110 110 0 1 1 180 292 L 150 318 L 172 278 A 110 110 0 0 1 143 230" 
        fill="none" 
        stroke="#6001D2" 
        strokeWidth="14" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />

      {/* Checkmark inside */}
      <path 
        d="M 255 205 L 295 245 L 375 165" 
        fill="none" 
        stroke="#FF6C00" 
        strokeWidth="16" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />

      {/* Top Circuit Line */}
      <path 
        d="M 115 155 L 180 155 L 205 130 L 235 130" 
        fill="none" 
        stroke="#FF6C00" 
        strokeWidth="10" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />
      <circle cx="115" cy="155" r="10" fill="#FF6C00" />
      <circle cx="235" cy="130" r="10" fill="#FF6C00" />

      {/* Middle Circuit Line */}
      <path 
        d="M 130 195 L 210 195" 
        fill="none" 
        stroke="#FF6C00" 
        strokeWidth="10" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />
      <circle cx="130" cy="195" r="10" fill="#FF6C00" />
      <circle cx="210" cy="195" r="10" fill="#FF6C00" />

      {/* Bottom Circuit Line */}
      <path 
        d="M 155 235 L 180 235 L 200 255 L 235 255" 
        fill="none" 
        stroke="#FF6C00" 
        strokeWidth="10" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />
      <circle cx="155" cy="235" r="10" fill="#FF6C00" />
      <circle cx="235" cy="255" r="10" fill="#FF6C00" />

      {/* Logo Typography "ReviewAID" */}
      <text 
        x="250" 
        y="385" 
        textAnchor="middle" 
        fontFamily="'Inter', 'Space Grotesk', system-ui, sans-serif" 
        fontSize="72" 
        fontWeight="900" 
        letterSpacing="-1"
      >
        <tspan fill="#6001D2">Review</tspan>
        <tspan fill="#FF6C00">AID</tspan>
      </text>

      {/* Divider line */}
      <line x1="60" y1="415" x2="440" y2="415" stroke="#000000" strokeWidth="2" />

      {/* Title "Emerging Infectious Disease (EID) Group" */}
      <text 
        x="250" 
        y="445" 
        textAnchor="middle" 
        fontFamily="'Inter', 'Space Grotesk', system-ui, sans-serif" 
        fontSize="19" 
        fill="#000000" 
        fontWeight="700" 
        letterSpacing="1"
      >
        Emerging Infectious Disease (EID) Group
      </text>
    </svg>
  );
}

const DATABASE_REGISTRY: Record<string, { name: string; key: 'wos' | 'scopus' | 'ncbi' | 'scholar' | 'cochrane' | 'embase' | 'ieee' | 'cinahl' | 'psycinfo' | 'eric' | 'sciencedirect' | 'wiley' }> = {
  wos: { name: 'Web of Science (WOS)', key: 'wos' },
  scopus: { name: 'Scopus', key: 'scopus' },
  ncbi: { name: 'PubMed / NCBI', key: 'ncbi' },
  scholar: { name: 'Google Scholar', key: 'scholar' },
  cochrane: { name: 'Cochrane Library', key: 'cochrane' },
  embase: { name: 'Embase', key: 'embase' },
  ieee: { name: 'IEEE Xplore', key: 'ieee' },
  cinahl: { name: 'CINAHL', key: 'cinahl' },
  psycinfo: { name: 'PsycINFO', key: 'psycinfo' },
  eric: { name: 'ERIC (Education)', key: 'eric' },
  sciencedirect: { name: 'ScienceDirect (Elsevier)', key: 'sciencedirect' },
  wiley: { name: 'Wiley Online Library', key: 'wiley' }
};

export default function App() {
  const [fileNames, setFileNames] = useState({ 
    wos: '', 
    scopus: '', 
    ncbi: '', 
    scholar: '', 
    cochrane: '', 
    embase: '', 
    ieee: '', 
    cinahl: '',
    psycinfo: '',
    eric: '',
    sciencedirect: '',
    wiley: ''
  });
  const [prismaTheme, setPrismaTheme] = useState<'gradient' | 'grayscale' | 'bw' | 'elsevier' | 'springer' | 'nature' | 'ieee' | 'wiley' | 'plos'>('gradient');
  const getSafeCustomKey = () => {
    try {
      const k = localStorage.getItem("user_gemini_api_key") || "";
      if (k) (window as any).__user_gemini_api_key = k;
      return k;
    } catch {
      return (window as any).__user_gemini_api_key || "";
    }
  };

  const getSafeCustomLogo = () => {
    try {
      const l = localStorage.getItem("app_custom_logo") || "";
      if (l) (window as any).__app_custom_logo = l;
      return l;
    } catch {
      return (window as any).__app_custom_logo || "";
    }
  };

  const [hasCustomKey, setHasCustomKey] = useState(!!getSafeCustomKey());
  const [customLogo, setCustomLogo] = useState<string>(getSafeCustomLogo());
  
  const [showManualScan, setShowManualScan] = useState(false);
  
  const [visibleDatabases, setVisibleDatabases] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("app_visible_databases");
      return saved ? JSON.parse(saved) : ['wos', 'scopus', 'ncbi'];
    } catch {
      return ['wos', 'scopus', 'ncbi'];
    }
  });

  const updateVisibleDatabases = (dbs: string[]) => {
    setVisibleDatabases(dbs);
    try {
      localStorage.setItem("app_visible_databases", JSON.stringify(dbs));
    } catch {}
  };

  const [showKeyModal, setShowKeyModal] = useState(false);
  const [inputKey, setInputKey] = useState("");

  const handleGeminiKeyPrompt = () => {
    let existing = "";
    try {
      existing = localStorage.getItem("user_gemini_api_key") || "";
    } catch {
      existing = (window as any).__user_gemini_api_key || "";
    }
    setInputKey(existing);
    setShowKeyModal(true);
  };

  useEffect(() => {
    initLogic();
    (window as any).prismaTheme = prismaTheme;
    (window as any).onPrismaThemeLoaded = (theme: 'gradient' | 'grayscale' | 'bw' | 'elsevier' | 'springer' | 'nature' | 'ieee' | 'wiley' | 'plos') => {
      setPrismaTheme(theme);
    };
    
    // Auto-search for logo inside working folder if no manual custom logo in localStorage
    try {
      const savedLogo = localStorage.getItem("app_custom_logo") || "";
      if (!savedLogo) {
        fetch("/api/detected-logo")
          .then(res => res.json())
          .then(data => {
            if (data.found && data.url) {
              setCustomLogo(data.url);
            }
          })
          .catch(err => console.warn("Failed to seek automatic logo", err));
      }
    } catch (e) {
      // In sandbox mode or storage restricted
    }
    
    // Unified reset listener from logic.ts
    const handleGlobalReset = () => {
      setFileNames({ 
        wos: '', 
        scopus: '', 
        ncbi: '', 
        scholar: '', 
        cochrane: '', 
        embase: '', 
        ieee: '', 
        cinahl: '',
        psycinfo: '',
        eric: '',
        sciencedirect: '',
        wiley: ''
      });
      setPrismaTheme('gradient');
      updateVisibleDatabases(['wos', 'scopus', 'ncbi']);
    };
    window.addEventListener('app:reset', handleGlobalReset);
    return () => {
      window.removeEventListener('app:reset', handleGlobalReset);
      delete (window as any).onPrismaThemeLoaded;
    };
  }, [visibleDatabases]);

  // Synchronize visible databases with loaded state files or global data
  useEffect(() => {
    const handleSync = () => {
      const activeIds: string[] = [];
      if (window.rawData) {
        Object.keys(window.rawData).forEach(dbKey => {
          if (Array.isArray(window.rawData[dbKey]) && window.rawData[dbKey].length > 0) {
            if (!activeIds.includes(dbKey)) {
              activeIds.push(dbKey);
            }
          }
        });
      }
      if (activeIds.length > 0) {
        setVisibleDatabases(prev => {
          const union = Array.from(new Set([...prev, ...activeIds]));
          if (union.length !== prev.length) {
            return union;
          }
          return prev;
        });
      }
    };
    
    const timer = setTimeout(handleSync, 500);
    const interval = setInterval(handleSync, 2000);
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, []);

  const handlePrismaThemeChange = (theme: 'gradient' | 'grayscale' | 'bw' | 'elsevier' | 'springer' | 'nature' | 'ieee' | 'wiley' | 'plos') => {
    setPrismaTheme(theme);
    (window as any).prismaTheme = theme;
    if (typeof (window as any).updatePrismaFigure === 'function') {
      setTimeout(() => {
        (window as any).updatePrismaFigure();
      }, 50);
    }
  };

  const handleFileUpload = (db: 'wos' | 'scopus' | 'ncbi' | 'scholar' | 'cochrane' | 'embase' | 'ieee' | 'cinahl' | 'psycinfo' | 'eric' | 'sciencedirect' | 'wiley', e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileNames(prev => ({ ...prev, [db]: file.name }));
      (window as any).loadCSV(db);
    }
  };

  const triggerUpload = (db: string) => {
    document.getElementById(db + 'File')?.click();
  };

  const handleReset = () => {
    (window as any).resetProject();
  };

  return (
    <div className="container-custom">
      <div className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-[1100]">
        <div className="flex items-center gap-4">
          <UnifiedLogo customLogoUrl={customLogo} className="h-12 md:h-14 w-auto" />
          <div className="flex flex-col">
            <span className="font-extrabold text-lg tracking-tight text-slate-900 flex items-center gap-2">
              <span className="px-2 py-0.5 bg-purple-100 text-purple-800 rounded text-xs font-bold uppercase tracking-wider">EID Group</span>
              ReviewAID <span className="text-slate-400 font-normal text-sm ml-2">V 1.0.0</span>
            </span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button 
            className={`btn shadow-sm font-semibold flex items-center gap-1.5 transition-all cursor-pointer border ${
              hasCustomKey 
                ? 'bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100' 
                : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100'
            }`} 
            onClick={handleGeminiKeyPrompt}
            title={hasCustomKey ? "Change or clear your custom Gemini API key" : "Set custom Gemini API key"}
          >
            🔑 {hasCustomKey ? "Gemini Key: Active" : "Gemini Key"}
          </button>
          <button className="btn btn-success shadow-sm" onClick={() => (window as any).saveWork()}>💾 Save Work</button>
          <button className="btn btn-warning shadow-sm" onClick={() => document.getElementById('uploadWorkInput')?.click()}>📂 Upload Work</button>
          <button className="btn bg-slate-200 text-slate-600 hover:bg-red-600 hover:text-white shadow-sm" onClick={handleReset}>🔄 Reset</button>
          <input type="file" id="uploadWorkInput" style={{ display: 'none' }} onChange={(e) => (window as any).loadWork(e)} />
        </div>
      </div>

      <div className="tabs">
        <button className="tab-link active" onClick={(e) => window.openTab(e, 'home')}>🏠 Home</button>
        <button className="tab-link" onClick={(e) => window.openTab(e, 'assistant')}>📁 CSV FILE UPLOAD</button>
        <button className="tab-link" onClick={(e) => window.openTab(e, 'methods')}>🔍 REFERENCES FILTERING</button>
        <button className="tab-link" onClick={(e) => window.openTab(e, 'figure')}>📊 PRISMA</button>
      </div>

      <div className="px-8 pt-1 pb-8" onClick={() => (window as any).hideCitationMenu()}>
        <div id="citationContextMenu" style={{ display: 'none', position: 'absolute', zIndex: 1100, background: 'white', borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', overflow: 'hidden' }}>
          <div className="menu-header" style={{ padding: '8px 12px', fontSize: '10px', background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>Cite Article</div>
          <ul className="list-none m-0 p-0 max-h-60 overflow-y-auto w-64"></ul>
        </div>
        <input type="hidden" id="globalTitle" defaultValue="Environmental Sustainability in Smart Cities" />


      <div id="home" className="tab-content active">
        <div className="flex flex-col items-center justify-center pt-0 pb-14 px-10 text-center max-w-5xl mx-auto bg-white rounded-3xl border border-slate-200/80 shadow-xl -mt-12 mb-10">
          <div className="relative flex flex-col items-center gap-0 pt-0 pb-2">
            <div className="flex items-center justify-center transition-all duration-300">
              <UnifiedLogo 
                customLogoUrl={customLogo} 
                style={{ height: '416px', width: 'auto', maxWidth: '100%', objectFit: 'contain' }}
                className="transition-all duration-200"
              />
            </div>
            <div className="flex items-center justify-center transition-all duration-300">
              <ReviewAidLogo 
                style={{ height: '832px', width: 'auto', maxWidth: '100%', objectFit: 'contain', marginTop: '-220px', marginBottom: '-90px' }}
                className="transition-all duration-200"
              />
            </div>
          </div>
          <div className="w-32 h-1.5 bg-indigo-600 rounded-full mt-0 mb-2 shadow-sm"></div>
          
          <div className="max-w-2xl px-6 py-6 md:py-8 md:px-10 border-2 border-slate-200/90 bg-gradient-to-br from-white to-slate-50/40 rounded-3xl shadow-[5px_5px_0px_0px_rgba(79,70,229,0.15)] mt-1 mb-10 transition-all hover:shadow-[7px_7px_0px_0px_rgba(79,70,229,0.2)] text-left md:text-center">
            <p className="text-base md:text-lg text-slate-700 leading-relaxed font-semibold">
              Welcome to the official systematic literature review workspace for the <span className="text-indigo-600 font-extrabold">Emerging Infectious Disease (EID) Group</span>. 
              This integrated workstation helps researchers streamline screening, filter multiple journal databases, 
              and compile PRISMA-compliant flow diagrams for academic publication.
            </p>
          </div>
          
          <button 
            type="button"
            className="btn btn-primary px-10 py-5 text-lg font-extrabold transition-all shadow-md rounded-xl hover:scale-[1.02] transform"
            onClick={(e) => window.openTab(e, 'methods')}
          >
            🚀 Let's Get Started
          </button>
        </div>
      </div>

      <div id="assistant" className="tab-content">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5 mb-6">
          <div>
            <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
              📁 CSV File Upload
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-2xl text-justify">
              Upload bibliographic search results in standard CSV format. We have pre-configured **Web of Science (WOS)**, **Scopus**, and **PubMed/NCBI** as default repository selections for your review. You can select and include other academic databases from the dropdown on the right, and remove them at any point.
            </p>
          </div>
          
          <div className="flex items-center gap-2 self-start md:self-auto bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-widest">➕ Add Database:</span>
            <select
              id="addDbDropdown"
              value=""
              onChange={(e) => {
                const val = e.target.value;
                if (val && !visibleDatabases.includes(val)) {
                  updateVisibleDatabases([...visibleDatabases, val]);
                }
                e.target.value = "";
              }}
              className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-bold text-slate-700 cursor-pointer"
            >
              <option value="">-- Choose Option --</option>
              {Object.entries(DATABASE_REGISTRY)
                .filter(([key]) => !visibleDatabases.includes(key))
                .map(([key, config]) => (
                  <option key={key} value={key}>{config.name}</option>
                ))
              }
            </select>
          </div>
        </div>

        <div className="section-box" style={{ display: 'none' }}>
          <button className="btn btn-primary" onClick={() => window.genSearchPrompt()}>Generate search string</button>
          <div id="searchPromptBox" className="ai-prompt-box" style={{ display: 'none' }}></div>
          <button id="copyPromptBtn" className="btn btn-success" style={{ display: 'none' }}>Copy Prompt</button>
        </div>

        <div className="section-box" style={{ display: 'none' }}>
          <h3>2. Paste Gemini Search Result</h3>
          <p className="text-sm text-slate-500 mb-4">Paste the keywords and search strings returned by Gemini here. This information will feed directly into the Materials & Methods synthesis prompt.</p>
          <div 
            contentEditable="true"
            id="assistantGeminiSearchResultPaste"
            className="result-input-area min-h-[150px] max-h-[300px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-indigo-300"
            data-placeholder="Paste the keywords and search strings from Gemini here..."
          ></div>
        </div>

        <div className="section-box">
          <h3 className="text-lg font-bold text-slate-900 mb-3">Upload Search Results (CSV)</h3>
          <div className="upload-grid">
            {visibleDatabases.map((dbId) => {
              const config = DATABASE_REGISTRY[dbId];
              if (!config) return null;
              const isFileLoaded = !!fileNames[config.key];
              const isDefault = ['wos', 'scopus', 'ncbi'].includes(dbId);

              return (
                <div 
                  key={dbId} 
                  className={`upload-box relative group transition-all hover:border-indigo-300 ${isFileLoaded ? 'has-file' : ''}`} 
                  onClick={() => triggerUpload(config.key)}
                >
                  {/* Remove Option for Databases (including WOS, Scopus, PubMed) */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation(); // Prevent opening the file upload dialog
                      setFileNames(prev => ({ ...prev, [config.key]: '' }));
                      if (window.rawData && window.rawData[config.key]) {
                        window.rawData[config.key] = [];
                      }
                      if (window.temporaryFilteredLists && window.temporaryFilteredLists[config.key]) {
                        window.temporaryFilteredLists[config.key] = [];
                      }
                      const countBadge = document.getElementById(`${config.key}Count`);
                      if (countBadge) {
                        countBadge.innerText = '0';
                      }
                      const resultBadge = document.getElementById(`res${config.key.charAt(0).toUpperCase() + config.key.slice(1)}`);
                      if (resultBadge) {
                        resultBadge.innerText = '0';
                      }
                      const next = visibleDatabases.filter(id => id !== dbId);
                      updateVisibleDatabases(next);
                    }}
                    className="absolute top-2 right-2 bg-slate-100 hover:bg-red-50 hover:text-red-600 text-slate-400 rounded-full h-6 w-6 flex items-center justify-center transition-all opacity-70 group-hover:opacity-100 shadow-sm z-10 font-bold"
                    title="Remove database"
                  >
                    ✕
                  </button>

                  <div className="icon">{isFileLoaded ? '✅' : '📁'}</div>
                  <div className="db-name font-bold text-slate-800">{config.name}</div>
                  {isFileLoaded ? (
                    <div className="file-name text-xs text-indigo-600 bg-indigo-50/50 px-2 py-1 rounded border border-indigo-100 max-w-full truncate">{fileNames[config.key]}</div>
                  ) : (
                    <div className="hint text-xs text-slate-400">Click to upload CSV</div>
                  )}
                  <div className="mt-2 text-xs font-semibold text-slate-500">
                    <span id={`${config.key}Count`} className="badge">0</span> records
                  </div>
                  <input 
                    type="file" 
                    id={`${config.key}File`} 
                    style={{ display: 'none' }} 
                    accept=".csv" 
                    onChange={(e) => handleFileUpload(config.key, e)} 
                  />
                </div>
              );
            })}
          </div>
        </div>

        <div className="section-box border-l-4 border-l-blue-500 bg-blue-50/30" style={{ display: 'none' }}>
          <h3 className="text-blue-600">Quick Audit</h3>
          <p className="text-xs text-slate-500 mb-4">Run a diagnostic check on your current SLR progress and data integrity.</p>
          <button className="btn bg-blue-600 text-white hover:bg-blue-700 w-full shadow-sm" onClick={() => window.runHealthCheck()}>📈 Run Project Audit</button>
        </div>
      </div>

      <div id="intro" className="tab-content">
        <h2>Introduction</h2>
        <div className="mb-4">
          <label className="block text-xs font-bold text-slate-400 uppercase mb-1 tracking-wider">Generated Prompt for Gemini</label>
          <div className="ai-prompt-box mt-0" id="introPromptText" data-description="Insert the generated prompt to gemini"></div>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase mb-1 tracking-wider">Gemini Results Input</label>
          <div 
            id="finalIntroEdit" 
            contentEditable="true"
            className="result-input-area min-h-[250px] max-h-[500px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
            data-placeholder="Please insert the generated results from gemini into this box"
          ></div>
        </div>

        <div className="section-box mt-8 border-l-4 border-l-emerald-500 bg-emerald-50/10">
          <h3 className="text-emerald-800 mb-2">3. Refined Introduction & References</h3>
          <p className="text-xs text-slate-500 mb-4">Click below to auto-split the Gemini Results into a polished Introduction and a separate References bibliography.</p>
          <button className="btn bg-emerald-600 text-white hover:bg-emerald-700 w-full shadow-sm mb-4" id="btnRefineIntro" onClick={() => (window as any).refineIntroduction()}>✨ Refined Introduction</button>
          
          <div id="refineIntroLoading" style={{ display: 'none' }} className="flex items-center gap-2 text-sm text-emerald-600 font-medium mb-4">
            <span className="animate-pulse">🔄 Refining and splitting introduction parts... please wait...</span>
          </div>

          <div className="grid grid-cols-1 gap-6 mt-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Research Questions</label>
              <div 
                id="refinedResearchQuestions" 
                contentEditable="true"
                className="result-input-area min-h-[100px] max-h-[250px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                data-placeholder="Explicit research questions will appear here..."
              ></div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Review Objectives</label>
              <div 
                id="refinedObjectives" 
                contentEditable="true"
                className="result-input-area min-h-[100px] max-h-[250px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                data-placeholder="Targeted review objectives will appear here..."
              ></div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Introduction</label>
              <div 
                id="refinedIntro" 
                contentEditable="true"
                className="result-input-area min-h-[250px] max-h-[500px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                data-placeholder="Split introduction paragraph text will appear here..."
              ></div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">references</label>
              <div 
                id="refinedIntroRefs" 
                contentEditable="true"
                className="result-input-area min-h-[150px] max-h-[300px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                data-placeholder="Bibliography/references list will appear here..."
              ></div>
              <button 
                className="btn btn-info w-full mt-2 text-xs py-2 px-4 rounded-lg font-bold shadow-sm flex items-center justify-center gap-2"
                onClick={() => window.syncAndArrangeReferences('refinedIntroRefs')}
              >
                📚 Sort in APA Style & Add to App Bibliography
              </button>
            </div>
          </div>
        </div>
      </div>

      <div id="methods" className="tab-content">
        <h2 className="text-2xl font-black text-slate-900 mb-6">References Filtering</h2>

        <div className="section-box">
          <h3 className="text-lg font-bold text-slate-950">1. SCREENING & CRITERIA</h3>
          <p className="text-sm text-slate-500 mb-4 text-justify">
            Configure your eligibility criteria for the screening phase. This stage allows you to define publication timelines and language preferences to filter out-of-scope papers. You can either utilize AI-powered automated category detection to scan the literature pool, or activate the manual options panel to speculatively check off document types and filter using specific search terms.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="theme-box">
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Timeline & Language</label>
              <div className="flex items-center gap-2 mb-4">
                <input type="number" id="startYear" defaultValue="2010" className="w-24" />
                <span className="text-slate-400">to</span>
                <input type="number" id="endYear" defaultValue="2024" className="w-24" />
              </div>
              <label className="flex items-center gap-2 mb-2 cursor-pointer">
                <input type="checkbox" id="incEnglish" />
                <span className="text-sm text-slate-700">English Language Only</span>
              </label>
              <input type="text" id="excLanguage" placeholder="Include specific languages..." className="mt-2 w-full" />
            </div>
            
            <div className="theme-box flex flex-col justify-between">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Select Filtering Approach</label>
                <p className="text-xs text-slate-500 mb-4 text-justify">
                  Choose between triggering the automated semantic categorization scans over your bibliographies or displaying the manual criteria controls.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <button 
                  type="button"
                  className="btn btn-warning flex-1 py-3 font-semibold text-sm shadow-sm flex items-center justify-center gap-1.5" 
                  onClick={() => (window as any).generateSmartExclusionLists()}
                >
                  <span>⚡</span> AI Smart Scan
                </button>
                <button 
                  type="button"
                  className={`btn flex-1 py-3 font-semibold text-sm shadow-sm flex items-center justify-center gap-1.5 border transition-all ${showManualScan ? 'bg-indigo-600 border-indigo-600 text-white hover:bg-indigo-700' : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'}`}
                  onClick={() => setShowManualScan(!showManualScan)}
                >
                  <span>🛠️</span> Manual Scan {showManualScan ? '(Active)' : ''}
                </button>
              </div>
            </div>
          </div>

          {/* Under manual scan button option, show/hide the DOCUMENT EXCLUSION and KEYWORD FILTERING sections */}
          <div className={`${showManualScan ? 'block' : 'hidden'} transition-all duration-300 bg-slate-50/50 rounded-2xl border border-slate-200/80 p-5 mt-4 mb-6 space-y-6`}>
            <div className="flex items-center gap-1.5 border-b border-slate-200/80 pb-2">
              <span className="text-sm">⚙️</span>
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-0">Manual Screening Panel</h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-3">Document Exclusion Categories (Unselected by default)</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exBooks" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Books / Chapters</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exConf" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Conference Papers</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exReview" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Review Articles</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exEditorial" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Editorials / Letters</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="incRCT" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">RCT Studies Only</span>
                  </label>
                  
                  {/* Additional categories under manual scan */}
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exPreprints" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Preprints / Working Papers</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exTheses" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Theses & Dissertations</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exGrey" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Grey Literature & Reports</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exPatents" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Patents / Standards</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exAnimal" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Animal & In-vitro Trials</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exCaseStudy" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Case Series & Reports</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors">
                    <input type="checkbox" id="exOpinion" className="rounded text-indigo-600 focus:ring-indigo-500" />
                    <span className="text-xs font-semibold text-slate-600">Opinions & Commentaries</span>
                  </label>
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-3">Keyword & Geographic Filtering</label>
                <div className="space-y-3">
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] font-bold text-slate-500 uppercase">Exclude Specific Words / Terms</span>
                    <div className="grid grid-cols-2 gap-2">
                      <input type="text" id="exKw1" placeholder="Exclude Keyword 1" className="mb-0" />
                      <input type="text" id="exKw2" placeholder="Exclude Keyword 2" className="mb-0" />
                    </div>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] font-bold text-slate-500 uppercase">Geographical Location Limit</span>
                    <input type="text" id="incCountries" placeholder="Limit to Countries..." className="mb-0 w-full" />
                  </div>
                  
                  {/* Additional keyword/subject options */}
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] font-bold text-slate-500 uppercase">Excluded Academic Subjects</span>
                    <input type="text" id="exSubjects" placeholder="e.g. Chemistry, Physics, Metallurgy..." className="mb-0 w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div id="suggestedCategoriesContainer" style={{ display: 'none' }}>
            <textarea id="suggestedCategoriesTextArea" style={{ display: 'none' }} readOnly></textarea>
            <div id="categoriesToScreenResultPaste" style={{ display: 'none' }}></div>
          </div>

          <div id="exclusionContainer" style={{ display: 'none' }} className="mt-6">
            <p className="text-xs text-slate-400 mb-2 font-bold uppercase tracking-widest text-justify">Select categories to exclude from the reference pool</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div id="designExGrid" className="exclusion-category-box"></div>
              <div id="popExGrid" className="exclusion-category-box"></div>
              <div id="intExGrid" className="exclusion-category-box"></div>
              <div id="outExGrid" className="exclusion-category-box"></div>
              <div id="geoExGrid" className="exclusion-category-box"></div>
              <div id="kwExGrid" className="exclusion-category-box"></div>
            </div>
          </div>

          <div className="mt-8">
            <button className="btn btn-primary w-full py-4 font-bold tracking-wide shadow-sm" onClick={() => window.runScreening()}>Apply Screening Filters</button>
          </div>

          <div id="screeningStats" className="stats-grid grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-4" style={{ display: 'none' }}>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">WOS</span><span id="resWos" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">Scopus</span><span id="resScopus" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">NCBI</span><span id="resNcbi" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">Scholar</span><span id="resScholar" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">Cochrane</span><span id="resCochrane" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">Embase</span><span id="resEmbase" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">IEEE</span><span id="resIeee" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">CINAHL</span><span id="resCinahl" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">PsycINFO</span><span id="resPsycinfo" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">ERIC</span><span id="resEric" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">SciDirect</span><span id="resSciencedirect" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div className="text-center"><span className="block text-xs font-bold text-slate-400 uppercase">Wiley</span><span id="resWiley" className="text-2xl font-bold text-indigo-600">0</span></div>
          </div>
        </div>

        <div id="deduplicationSection" className="section-box border-2 border-indigo-50" style={{ display: 'none' }}>
          <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
            <h3 className="text-lg font-bold text-slate-950">2. COMBINED & DEDUPLICATE RESULTS</h3>
            <button className="btn btn-primary" onClick={() => window.combineAndDeduplicate()}>Combine All Sources</button>
          </div>
          <p className="text-sm text-slate-500 mb-4 text-justify">
            Consolidate bibliographic records across all your loaded search engines into a singular unified registry. Our deduplication engine automatically cross-references metadata parameters like title, DOI, authors, and year to eliminate overlapping outputs and report accurate database yields.
          </p>
          <div className="bg-slate-50 p-4 rounded-lg flex gap-8">
            <div><span className="text-slate-400 text-xs font-bold uppercase block">Unique Studies</span><span id="resTotal" className="text-2xl font-bold text-indigo-600">0</span></div>
            <div><span className="text-slate-400 text-xs font-bold uppercase block">Duplicates Removed</span><span id="dupCount" className="text-2xl font-bold text-slate-500">0</span></div>
            <div id="aiExStatBox" style={{ display: 'none' }}><span className="text-slate-400 text-xs font-bold uppercase block">AI Category Exclusions</span><span id="aiExCountDisplay" className="text-2xl font-bold text-red-500">0</span></div>
          </div>
          <div id="exclusionReasons" className="exclusion-list mt-4" style={{display: 'none'}}>
            <label className="block text-xs font-bold uppercase mb-2">Exclusion Summary</label>
            <ul id="exclusionListUl" className="space-y-1 opacity-80"></ul>
          </div>
        </div>

        <div id="manualSelectionSection" className="section-box" style={{ display: 'none' }}>
            <h3 className="text-lg font-bold text-slate-950">3. MANUAL SELECTION PHASE</h3>
            <p className="text-sm text-slate-500 mb-4 text-justify">Evaluate your selected references' study designs and summarize their key findings. You can auto-generate this analysis using the built-in Gemini API, or generate a manual copy-paste prompt.</p>
            <div className="flex flex-wrap gap-3 mb-4 items-center">
                <button id="btnAutoAnalyzeManual" className="btn bg-indigo-600 text-white hover:bg-indigo-700 shadow-md font-bold transition-all transform hover:scale-[1.01]" onClick={() => (window as any).autoAnalyzeManualSelection()}>
                  ⚡ Auto-Analyze & Finalize via Gemini
                </button>
                <button className="btn btn-primary" onClick={() => (window as any).genManualSelectionPrompt()}>
                  🛠️ Generate Manual Prompt
                </button>
                <button className="btn bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 font-bold shadow-md transition-all flex items-center gap-1 active:scale-95 cursor-pointer" onClick={() => (window as any).resetManualSelectionTable()} title="Clear generated/pasted summary table, study designs, and key findings">
                  🔄 Reset Table
                </button>
            </div>
            
            {/* Elegant Progress Bar Container */}
            <div id="geminiProgressBarContainer" className="w-full bg-slate-50 rounded-lg p-3 border border-slate-200 mb-4 shadow-sm" style={{ display: 'none' }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-indigo-700 flex items-center gap-1.5 animate-pulse" id="geminiProgressText">
                  <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
                  Analyzing references with Gemini...
                </span>
                <span className="text-xs font-mono font-bold text-indigo-700" id="geminiProgressPercent">0%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden shadow-inner">
                <div id="geminiProgressBar" className="bg-gradient-to-r from-indigo-500 to-indigo-600 h-2.5 rounded-full transition-all duration-300 ease-out" style={{ width: '0%' }}></div>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 italic">Auto-analysis connects directly to Gemini to automatically populate study designs & findings across your selection and transitions to the final manual selection pool.</p>
            <div id="manualOutputSection" style={{ display: 'none' }} className="mt-4 border-t border-slate-100 pt-4">
                <div className="ai-prompt-box" id="manualPromptBox"></div>
                
                <div className="mt-4 mb-2 flex items-center justify-between border-b border-slate-100 pb-2">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Gemini Result Input</label>
                        <p className="text-[10px] text-slate-400 italic">Please paste the summary table result from Gemini into the box below (ensure it includes the study type columns).</p>
                    </div>
                    {/* Toggle Show/Hide Button */}
                    <button 
                        id="btnToggleGeminiResultInput" 
                        type="button" 
                        className="btn py-1 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-300 rounded shadow-sm transition-all flex items-center gap-1 active:scale-95 cursor-pointer"
                        style={{ display: 'none' }}
                        onClick={() => (window as any).toggleGeminiResultInput()}
                    >
                        👁️ Show
                    </button>
                </div>
                
                <div contentEditable="true" id="manualTablePaste" className="result-input-area min-h-[200px] max-h-[500px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300" data-placeholder="Paste the table from Gemini here..."></div>
                
                <div id="manualSelectionTableContainer" className="mt-4 border border-slate-200 rounded-lg overflow-hidden bg-white" style={{ display: 'none', maxHeight: '400px', overflowY: 'auto' }}></div>
 
                <button className="btn btn-success mt-4 w-full" onClick={() => (window as any).parseManualTable()}>Finalize Selected References</button>
            </div>
        </div>

        <div id="finalRefsSection" className="section-box border-2 border-green-50" style={{ display: 'none' }}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                <h3 className="text-lg font-bold text-slate-950">4. MANUAL SELECTION</h3>
                <div className="flex items-center gap-3">
                    <div className="flex rounded-md shadow-sm border border-slate-300 overflow-hidden bg-white">
                      <button className="px-3 py-1 text-xs font-bold text-slate-700 bg-slate-50 hover:bg-slate-100 border-r border-slate-300 flex items-center gap-1 transition-colors" onClick={() => (window as any).undoFinalActive()} title="Undo manual reference exclusion">
                         ↩️ Undo
                      </button>
                      <button className="px-3 py-1 text-xs font-bold text-slate-700 bg-slate-50 hover:bg-slate-100 flex items-center gap-1 transition-colors" onClick={() => (window as any).redoFinalActive()} title="Redo manual reference exclusion">
                         ↪️ Redo
                      </button>
                    </div>
                    <div className="flex gap-2">
                        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-md text-xs font-bold">Included: <span id="finalManualIncluded">0</span></span>
                        <span className="bg-red-100 text-red-700 px-3 py-1 rounded-md text-xs font-bold">Excluded: <span id="finalManualExcluded">0</span></span>
                    </div>
                </div>
            </div>
            <p className="text-xs text-slate-500 mb-4 font-sans text-justify">Manual selection at this stage should be based on abstract and full article evaluations. Unticking references below will temporarily exclude them from eligibility. Feel free to use the Undo and Redo buttons above to instantly reverse actions and bring back references into your selection pool.</p>
            <div id="finalRefsList" className="border border-slate-200 rounded-lg max-h-96 overflow-y-auto"></div>
            
            <div className="mt-4 pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-50/50 p-3 rounded-lg border border-slate-150">
                <div className="flex flex-col gap-0.5">
                    <span className="text-xs font-bold text-slate-700">Export Final References</span>
                    <span className="text-[10px] text-slate-500">Download all currently selected/included references formatted in APA Style list.</span>
                </div>
                <button 
                    onClick={() => (window as any).exportSelectedReferencesToWord()} 
                    className="btn px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md rounded-lg flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                    title="Export selected references to a Word (.doc) document in APA format with interactive save prompt"
                >
                    📥 Export Selected References to Word (.doc)
                </button>
            </div>
        </div>

        <div id="methodElaborationSection" style={{ display: 'none' }}>
          <div id="methodsPromptBox" style={{ display: 'none' }}></div>
          <button id="copyMethodsPromptBtn" style={{ display: 'none' }}></button>
          <div id="methodsElaborationInput" style={{ display: 'none' }}></div>
          <div id="detected-refs-tab3" style={{ display: 'none' }} className="hidden">
            <div id="detected-refs-tab3-list" style={{ display: 'none' }}></div>
          </div>
        </div>
      </div>

      <div id="results" className="tab-content">
        <h2>Thematic Results Analysis</h2>
        <div className="section-box">
            <h3>1. AI Theme Generation</h3>
            <p className="text-sm text-slate-500 mb-4">Click to generate a command that helps Gemini categorize your references into 5 distinct themes.</p>
            <button className="btn btn-primary" onClick={() => (window as any).generateThemes()}>Create Themes Prompt</button>
            <div id="themeSuggestionPromptBox" className="ai-prompt-box" style={{display: 'none'}}></div>
        </div>
        
        <div className="section-box">
            <h3>2. Populate Themes & Generate Specific Prompts</h3>
            <p className="text-sm text-slate-500 mb-2">Paste the theme list generated by Gemini below.</p>
            <div 
                contentEditable="true"
                id="geminiResultsInput" 
                className="result-input-area mb-4 min-h-[150px] max-h-[300px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                data-placeholder="Paste response here (Theme 1 (Name): Name...)"
            ></div>
            <button className="btn btn-success w-full" onClick={() => (window as any).parseAndDistributeThemes()}>Generate Theme's Prompt</button>
            <div id="detected-refs-tab2" className="mt-4 p-3 bg-blue-50/50 rounded border border-blue-100 hidden">
                <label className="block text-[10px] font-bold text-blue-400 uppercase tracking-widest mb-1">Detected References In Text</label>
                <div id="detected-refs-tab2-list" className="text-xs text-blue-800 space-y-1"></div>
            </div>
        </div>

        <div id="geminiResultsSection" style={{display: 'none'}} className="mt-8">
            <h3 className="mb-4">3. Theme-Specific Prompts</h3>
            <p className="text-xs text-slate-500 mb-6">Use these prompts in Gemini to analyze each individual theme.</p>
            
            <div className="grid grid-cols-1 gap-6">
                {[1,2,3,4,5].map(i => (
                    <div key={i} className="theme-box border-l-4 border-l-indigo-400">
                        <div className="flex items-center justify-between mb-2">
                           <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest">Theme {i} Prompt</label>
                           <span id={`dispName${i}`} className="font-bold text-indigo-600 text-sm"></span>
                        </div>
                        <div id={`themePrompt${i}`} className="ai-prompt-box text-xs bg-slate-50 p-3 rounded" style={{ whiteSpace: 'pre-wrap' }}></div>
                        <button className="btn btn-sm btn-success mt-2" onClick={() => (window as any).copyThemePrompt(i)}>Copy Theme {i} Prompt</button>
                    </div>
                ))}
            </div>

            <div className="mt-12 bg-indigo-50/30 p-8 rounded-xl border border-indigo-100">
                <h3 className="text-indigo-800 mb-2">4. Paste Theme Summary Results</h3>
                <p className="text-sm text-indigo-600/70 mb-6">Paste the generated results from Gemini for each theme analysis below.</p>
                <div className="grid grid-cols-1 gap-6">
                    {[1,2,3,4,5].map(i => (
                        <div key={i}>
                            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Theme {i} Summary Result</label>
                            <div 
                                contentEditable="true" 
                                id={`themeSummary${i}`} 
                                className="result-input-area min-h-[200px] max-h-[500px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                                data-placeholder={`Paste Gemini summary for Theme ${i} here...`}
                            ></div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="mt-8 bg-emerald-50/30 p-8 rounded-xl border border-emerald-100">
                <h3 className="text-emerald-800 mb-2">5. Compiled Results</h3>
                <p className="text-sm text-emerald-600/70 mb-6">Compile all theme summary results from Section 4 into a unified narrative results set and separate consolidated references box.</p>
                <button 
                    className="btn bg-emerald-600 text-white hover:bg-emerald-700 w-full shadow-sm mb-6" 
                    id="btnCompileResults" 
                    onClick={() => (window as any).compileResults()}
                >
                    ✨ Compile All Themes
                </button>

                <div className="grid grid-cols-1 gap-6 mt-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Results Narrative</label>
                        <div 
                            contentEditable="true" 
                            id="compiledResultsNarrative" 
                            className="result-input-area min-h-[250px] max-h-[500px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                            data-placeholder="Consolidated thematic results narrative will appear here..."
                        ></div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-400 uppercase mb-2">References</label>
                        <div 
                            contentEditable="true" 
                            id="compiledResultsReferences" 
                            className="result-input-area min-h-[150px] max-h-[300px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                            data-placeholder="Consolidated references list will appear here..."
                        ></div>
                        <button 
                            className="btn btn-info w-full mt-2 text-xs py-2 px-4 rounded-lg font-bold shadow-sm flex items-center justify-center gap-2"
                            onClick={() => window.syncAndArrangeReferences('compiledResultsReferences')}
                        >
                            📚 Sort in APA Style & Add to App Bibliography
                        </button>
                    </div>
                </div>
            </div>
        </div>
      </div>

      <div id="summary" className="tab-content">
        <h2>Summary Table (Overall)</h2>
        <div className="section-box mb-6">
            <h3>Matrix Generator</h3>
            <p className="text-sm text-slate-500 mb-4">Synthesize similarities and differences across identified themes.</p>
            <button className="btn btn-primary" onClick={() => (window as any).generateSummaryMatrixPrompt()}>Generate Matrix Prompt</button>
            <div id="matrixPromptBox" className="ai-prompt-box" style={{display: 'none'}}></div>
            <div 
                contentEditable="true" 
                id="summaryMatrixTable" 
                className="result-input-area min-h-[300px] max-h-[600px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300 mt-4"
                data-placeholder="Paste synthesized matrix here..."
            ></div>
        </div>

        <h2>Summary Table (Theme-based)</h2>
        <div className="section-box">
            <h3>Summary Table (Theme-based)</h3>
            <p className="text-sm text-slate-500 mb-4">Analyze and organize your references dynamically segmented by each of the five selected themes.</p>
            <button className="btn btn-primary" onClick={() => (window as any).generateThemeBasedSummaryMatrixPrompt()}>Generate Matrix Prompt</button>
            <div id="themeBasedMatrixPromptBox" className="ai-prompt-box text-xs bg-slate-50 p-4 rounded border border-slate-200 mt-4 font-mono whitespace-pre-wrap" style={{display: 'none'}}></div>
            <div 
                contentEditable="true" 
                id="themeBasedMatrixTable" 
                className="result-input-area min-h-[300px] max-h-[600px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300 mt-4"
                data-placeholder="Paste theme-based summary table here..."
            ></div>
        </div>
      </div>

      <div id="discussion" className="tab-content">
        <h2>Discussion & Analysis</h2>
        <div className="section-box">
            <h3>1. Discussion Command Generator</h3>
            <p className="text-sm text-slate-500 mb-4">Generate comprehensive discussion prompts based on the themed results from stage 4.</p>
            <button className="btn btn-primary w-full" onClick={() => window.genMasterDiscussion()}>Create Sectional Discussion Prompts</button>
            <div id="discPromptContainer" className="mt-6 space-y-6" style={{display: 'none'}}>
                {[1,2,3,4,5].map(i => (
                    <div key={i} className="theme-box border-l-4 border-l-orange-400">
                        <div className="flex items-center justify-between mb-2">
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest">Theme {i} Discussion Prompt</label>
                            <button className="btn btn-sm btn-success" onClick={() => (window as any).copyDiscThemePrompt(i)}>Copy Prompt</button>
                        </div>
                        <div id={`discThemePrompt${i}`} className="ai-prompt-box text-xs bg-slate-50 p-3 rounded" style={{ whiteSpace: 'pre-wrap' }}></div>
                    </div>
                ))}
            </div>
        </div>

        <div id="discResultsPasteSection" className="section-box bg-orange-50/20 border-2 border-orange-100 mt-8" style={{display: 'none'}}>
            <h3 className="text-orange-800 mb-2">2. Paste Sectional Discussion Results</h3>
            <p className="text-sm text-orange-600/70 mb-6">Paste the generated discussion content from Gemini for each theme below.</p>
            <div className="grid grid-cols-1 gap-6">
                {[1,2,3,4,5].map(i => (
                    <div key={i}>
                        <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Theme {i} Discussion Analysis</label>
                        <div 
                            contentEditable="true" 
                            id={`discThemeSummary${i}`} 
                            className="result-input-area min-h-[250px] max-h-[500px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                            data-placeholder={`Paste Gemini discussion analysis for Theme ${i} here...`}
                        ></div>
                    </div>
                ))}
            </div>
            <div id="detected-refs-tab6" className="mt-4 p-3 bg-blue-50/50 rounded border border-blue-100 hidden">
                <label className="block text-[10px] font-bold text-blue-400 uppercase tracking-widest mb-1">Detected References In Text</label>
                <div id="detected-refs-tab6-list" className="text-xs text-blue-800 space-y-1"></div>
            </div>
        </div>

        <div className="section-box mt-8 border-l-4 border-l-orange-500 bg-orange-50/10">
            <h3>3. Review & Refine Final Discussion</h3>
            <p className="text-xs text-slate-400 mb-6">Extract and synthesize sectional discussion analyses from Themes 1-5. You can also paste your Gemini result or edit text directly in the boxes below.</p>
            
            <div className="mb-6 bg-white p-4 rounded-lg border border-orange-200">
                <span className="block text-xs font-bold text-orange-700 uppercase tracking-wider mb-1">Synthesizer & Splitter</span>
                <p className="text-slate-500 text-[11px] mb-3">Extract data from Theme 1, Theme 2, Theme 3, Theme 4, and Theme 5 Discussion Analyses, compiling narrative text in one box and references/bibliography in another box.</p>
                <button className="btn bg-orange-600 text-white hover:bg-orange-700 w-full shadow-sm text-xs py-2 px-3 rounded font-semibold transition" id="btnSynthesizeDisc" onClick={() => (window as any).autoSynthesizeDiscussion()}>✨ Generate</button>
                <div id="synthesizeDiscLoading" style={{ display: 'none' }} className="flex items-center gap-2 text-xs text-orange-600 font-medium mt-2">
                  <span className="animate-pulse">🔄 Synthesizing Themes 1-5 discussion analyses and compiling bibliographic references... please wait...</span>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-6 mt-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Discussion</label>
                <div 
                  id="finalDiscEdit" 
                  contentEditable="true"
                  className="result-input-area min-h-[400px] max-h-[600px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-white focus:outline-none focus:border-blue-300"
                  onContextMenu={(e) => { e.preventDefault(); (window as any).showCitationMenu(e.pageX, e.pageY); }} 
                  data-placeholder="Paste your Gemini discussion output here, or click 'Generate' to synthesis Theme 1-5 narratives..."
                ></div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">references</label>
                <div 
                  id="finalDiscRefs" 
                  contentEditable="true"
                  className="result-input-area min-h-[150px] max-h-[300px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-white focus:outline-none focus:border-blue-300"
                  data-placeholder="Paste references/bibliography here, or click 'Generate' to automatically compile themes references list..."
                ></div>
                <button 
                  className="btn btn-info w-full mt-2 text-xs py-2 px-4 rounded-lg font-bold shadow-sm flex items-center justify-center gap-2"
                  onClick={() => window.syncAndArrangeReferences('finalDiscRefs')}
                >
                  📚 Sort in APA Style & Add to App Bibliography
                </button>
              </div>
            </div>
        </div>
      </div>

      <div id="conclusion" className="tab-content">
        <h2>Conclusion & Future Work</h2>
        <div className="section-box">
            <h3>1. Conclusion Assistant</h3>
            <p className="text-sm text-slate-500 mb-4">Generate a comprehensive summary of your findings based on the sectional discussion analysis.</p>
            <button className="btn btn-primary w-full" onClick={() => (window as any).genConclusionPrompt()}>Generate Prompt For Conclusion</button>
            <div id="conclusionPromptBox" className="ai-prompt-box mt-4" style={{ display: 'none' }}></div>
            <button id="copyConclusionBtn" className="btn btn-success btn-sm mt-2" style={{ display: 'none' }} onClick={() => (window as any).copyConclusionPrompt()}>Copy Conclusion Prompt</button>
        </div>

        <div className="section-box mt-8">
            <h3>2. Paste Generated Conclusion</h3>
            <p className="text-sm text-slate-500 mb-4">Paste the final summary/conclusion generated by the AI here.</p>
            <div 
              id="conclusionTextArea" 
              contentEditable="true"
              className="result-input-area min-h-[400px] max-h-[700px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
              data-placeholder="Paste the generated conclusion here..."
            ></div>
        </div>
      </div>

      <div id="workflow" className="tab-content">
        <h2>Systematic Workflow</h2>
        <div className="section-box">
            <h3>Procedural Summary</h3>
            <div className="flow-step">1. Identification: Found <span id="flowIdentified" className="text-indigo-600 font-bold">0</span> records across 3 databases.</div>
            <div className="flow-arrow">↓</div>
            <div className="flow-step">2. Screening: Filtered by year, type, and AI categories. <span id="flowScreened" className="text-indigo-600 font-bold">0</span> remained.</div>
            <div className="flow-arrow">↓</div>
            <div className="flow-step">3. Eligibility: Deduplicated to <span id="flowDeduplicated" className="text-indigo-600 font-bold">0</span> unique items.</div>
            <div className="flow-arrow">↓</div>
            <div className="flow-step">4. Inclusion: Final synthesis of <span id="flowFinal" className="text-green-600 font-bold">0</span> articles.</div>
        </div>
      </div>

      <div id="paperdraft" className="tab-content">
        <h2>Academic Manuscript Builder</h2>
        <button className="btn btn-warning w-full mb-6 py-3 font-bold shadow-md" onClick={() => window.syncPaperDraft()}>🔄 Sync With Tabs</button>
        <div className="draft-layout">
          <div className="draft-main space-y-6">
            <div className="section-box">
                <h3 className="mb-4">Manuscript Authorship</h3>
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">Formatted Authors & Affiliations</label>
                    <button className="btn btn-primary btn-sm px-4" onClick={() => (window as any).generateAuthorAffiliations()}>✨ GENERATE</button>
                  </div>
                  <div 
                    id="draft-formatted-authors" 
                    contentEditable="true"
                    className="min-h-[120px] text-sm font-sans bg-white border border-slate-200 rounded p-4 whitespace-pre-wrap focus:outline-none focus:border-blue-300 text-center"
                    data-placeholder="Click GENERATE to format based on inputs below..."
                  ></div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="theme-box">
                      <h3 className="mb-4">Authors</h3>
                      <div id="authorsContainer" className="space-y-2 mb-4"></div>
                      <button className="btn btn-warning btn-sm" onClick={() => window.addAuthorRow()}>+ Add Author</button>
                  </div>
                  <div className="theme-box">
                      <h3 className="mb-4">Affiliations</h3>
                      <div id="affilsContainer" className="space-y-2 mb-4"></div>
                      <button className="btn btn-warning btn-sm" onClick={() => window.addAffiliationRow()}>+ Add Affiliation</button>
                  </div>
                </div>
            </div>

            <div className="section-box">
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">1. Introduction</label>
                <div 
                    id="draft-intro" 
                    contentEditable="true"
                    className="result-input-area min-h-[300px] max-h-[600px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                    onFocus={() => window.setActiveTextarea('draft-intro')}
                ></div>
            </div>

            <div className="section-box">
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">2. Materials & Methods</label>
                <div 
                    id="draft-methods" 
                    contentEditable="true"
                    className="result-input-area min-h-[300px] max-h-[600px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                    onFocus={() => window.setActiveTextarea('draft-methods')}
                ></div>
            </div>

            <div className="section-box">
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">3. Results (Summary Table)</label>
                <div 
                    contentEditable="true" 
                    id="draft-summary-matrix" 
                    className="result-input-area min-h-[300px] max-h-[600px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                    onFocus={() => window.setActiveTextarea('draft-summary-matrix')}
                ></div>
            </div>

            <div className="section-box">
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">4. Results</label>
                <div 
                    contentEditable="true" 
                    id="draft-results" 
                    className="result-input-area min-h-[400px] max-h-[800px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                    onFocus={() => window.setActiveTextarea('draft-results')}
                ></div>
            </div>

            <div className="section-box">
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">5. Discussion</label>
                <div 
                    contentEditable="true" 
                    id="draft-discussion" 
                    className="result-input-area min-h-[400px] max-h-[800px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                    onFocus={() => window.setActiveTextarea('draft-discussion')}
                ></div>
            </div>

            <div className="section-box">
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">6. Conclusion</label>
                <div 
                    id="draft-conclusion" 
                    contentEditable="true"
                    className="result-input-area min-h-[200px] max-h-[500px] overflow-y-auto border-dashed border-2 p-4 font-mono text-xs whitespace-pre-wrap rounded-lg bg-slate-50 focus:outline-none focus:border-blue-300"
                    onFocus={() => window.setActiveTextarea('draft-conclusion')}
                ></div>
            </div>

            <div className="section-box border-2 border-indigo-100">
                <div className="flex items-center justify-between mb-4">
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-widest">References (APA)</label>
                  <button className="btn btn-primary btn-sm" onClick={() => window.updateReferenceList()}>Refresh References</button>
                </div>
                <div id="used-references-list" className="space-y-4 text-sm text-slate-600 bg-slate-50 p-4 rounded-lg border border-slate-200">
                  <p className="italic text-slate-400">No citations added yet.</p>
                </div>
                <textarea id="draftReferences" className="hidden"></textarea>
            </div>

            <button className="btn btn-primary w-full py-4 text-lg shadow-lg" onClick={() => (window as any).compileFinalManuscript()}>🚀 Compile Final Manuscript (.txt)</button>
          </div>

          <div className="ref-sidebar">
            <h3 className="flex items-center justify-between">
              <span>References</span>
              <span id="ref-sidebar-count" className="badge">0</span>
            </h3>
            <p className="text-[10px] text-slate-400 mb-4 uppercase font-bold">Select text in a box and click to cite</p>
            <div id="ref-sidebar-list" className="ref-sidebar-list">
              {/* Populated by logic.ts */}
              <div className="p-4 text-center text-slate-400 text-xs italic">
                Upload and screen data to see references here.
              </div>
            </div>
          </div>
        </div>
      </div>

      <div id="abstract" className="tab-content">
        <h2>Abstract Generation</h2>
        <div className="section-box">
            <h3>AI Abstract Tool</h3>
            <p className="text-sm text-slate-500 mb-4">Generates a structured abstract (Objective, Methods, Results, Conclusion).</p>
            <button className="btn btn-primary" onClick={() => (window as any).genAbstractPromptDetailed()}>Create Abstract Prompt</button>
            <div id="abstractPromptBox" className="ai-prompt-box" style={{display: 'none'}}></div>
            <div 
              id="finalAbstractEdit" 
              contentEditable="true"
              className="min-h-[300px] mt-4 p-4 border border-slate-200 rounded-lg bg-white overflow-y-auto whitespace-pre-wrap focus:outline-none focus:border-blue-300"
              data-placeholder="Paste final abstract here..."
            ></div>
        </div>
      </div>

      <div id="final" className="tab-content">
        <h2>Final Manuscript Preview</h2>
        <div className="section-box">
            <div className="flex items-center justify-between mb-4">
                <h3>Submission Ready Text</h3>
                <div className="flex gap-2">
                    <button className="btn btn-primary shadow-md" onClick={() => (window as any).compileFinalManuscript()}>🚀 Compile Manuscript</button>
                    <button className="btn btn-info shadow-md" onClick={() => (window as any).downloadManuscript()}>📥 Download Doc</button>
                </div>
            </div>
            <div 
              id="fullManuscriptPreview" 
              className="min-h-[600px] bg-white border border-slate-200 rounded-lg p-10 font-serif leading-relaxed shadow-inner overflow-y-auto"
              contentEditable="true"
            ></div>
            <button className="btn btn-success w-full mt-4 py-3 font-bold text-lg" onClick={() => (window as any).copyFullManuscript()}>Copy Formatted Manuscript</button>
            <textarea id="fullManuscriptText" className="hidden"></textarea>
        </div>
      </div>

      <div id="cover" className="tab-content">
        <h2>Journal Cover Letter</h2>
        <div className="section-box">
            <h3>Letter Generator</h3>
            <p className="text-sm text-slate-500 mb-4">Creates a professional cover letter for your target journal.</p>
            <input type="text" id="targetJournal" className="mb-4" placeholder="Target Journal Name (e.g., Nature Sustainability)" />
            <button className="btn btn-primary" onClick={() => (window as any).genCoverLetterPrompt()}>Create Cover Letter Prompt</button>
            <div id="coverPromptBox" className="ai-prompt-box" style={{display: 'none'}}></div>
            <textarea id="finalCoverLetter" className="min-h-[400px] mt-4" placeholder="Paste generated letter here..."></textarea>
        </div>
      </div>

      <div id="figure" className="tab-content">
        <h2>PRISMA 2020 Flow Diagram</h2>

        <div className="bg-slate-50 border border-slate-200 p-5 rounded-xl mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-slate-800 mb-1 flex items-center gap-1.5">
              <span>🎚️ Diagram Design Palette</span>
              <span className="badge bg-indigo-100 text-indigo-700 text-[10px] px-1.5 py-0.5 rounded font-extrabold uppercase">PRISMA 2020 compliant</span>
            </h3>
            <p className="text-xs text-slate-500 p-0 m-0">Choose the optimal visual aesthetic for your academic manuscript submission, from colorful gradients to black & white line-art.</p>
          </div>
          <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-sm self-start md:self-auto max-w-full">
            <select 
              id="prismaThemeDropdown"
              value={prismaTheme}
              onChange={(e) => handlePrismaThemeChange(e.target.value as any)}
              className="w-full md:w-64 px-3 py-2 bg-white border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm font-semibold text-slate-700 cursor-pointer"
            >
              <option value="gradient">🌈 Vibrant Gradient</option>
              <option value="grayscale">🌑 Academic Grayscale</option>
              <option value="bw">🔲 Pure B&W Line-art</option>
              <option value="elsevier">📘 Elsevier Blue</option>
              <option value="springer">☘️ Springer Emerald</option>
              <option value="nature">🌹 Nature Crimson</option>
              <option value="ieee">📡 IEEE Teal</option>
              <option value="wiley">🍇 Wiley Purple</option>
              <option value="plos">🌊 PLOS Cyan</option>
            </select>
          </div>
        </div>
        
        <div className={`prisma-grid bg-white p-8 rounded-xl border border-slate-200 prisma-theme-${prismaTheme}`}>
            {/* Legend - Moved to bottom right corner of grid (Row 7, Col 4/5) */}
            <div className="legend-container">
                <div className="text-sm font-black uppercase tracking-widest border-b-2 border-black mb-1 pb-1">Legend</div>
                <div className="legend-item">
                    <div className="legend-color bg-indigo-500 legend-color-ident"></div>
                    <span>Identification Group</span>
                </div>
                <div className="legend-item">
                    <div className="legend-color bg-pink-500 legend-color-screen"></div>
                    <span>Screening Group</span>
                </div>
                <div className="legend-item">
                    <div className="legend-color bg-yellow-500 legend-color-elig"></div>
                    <span>Eligibility Group</span>
                </div>
                <div className="legend-item">
                    <div className="legend-color bg-green-500 legend-color-incl"></div>
                    <span>Included Studies</span>
                </div>
                <div className="legend-item">
                    <div className="legend-color bg-slate-800 legend-color-main"></div>
                    <span>Main Process Boxes</span>
                </div>
                <div className="legend-item">
                    <div className="legend-color bg-red-500 legend-color-ex"></div>
                    <span>Excluded / Cross Arrows</span>
                </div>
            </div>

            {/* Phase Separators (Colored) */}
            <div className="prisma-group-border border-indigo-500" style={{ gridRow: '2' }}></div>
            <div className="prisma-group-border border-pink-500" style={{ gridRow: '4' }}></div>
            <div className="prisma-group-border border-yellow-500" style={{ gridRow: '6' }}></div>

            {/* Stage 1: Identification */}
            <div className="phase-box phase-ident" style={{ gridRow: '1 / 3' }}>Identification</div>
            <div id="fig-ident" className="main-box" style={{ gridRow: '1', gridColumn: '3' }}>Identification</div>

            {/* Transition 1 -> 2 with Exclusion */}
            <div className="v-arrow" style={{ gridRow: '2', gridColumn: '3' }}>
              <div className="v-arrow-line"></div>
              <div className="v-arrow-head"></div>
              <div className="h-line branch-line"></div>
            </div>
            <div className="h-arrow" style={{ gridRow: '2', gridColumn: '4' }}></div>
            <div id="fig-ex-dup" className="ex-box" style={{ gridRow: '2', gridColumn: '5' }}>Duplicates removed</div>

            {/* Stage 2: Screening */}
            <div className="phase-box phase-screen" style={{ gridRow: '3 / 5' }}>Screening</div>
            <div id="fig-screen" className="main-box" style={{ gridRow: '3', gridColumn: '3' }}>Screening</div>

            {/* Transition 2 -> 3 with Exclusion */}
            <div className="v-arrow" style={{ gridRow: '4', gridColumn: '3' }}>
              <div className="v-arrow-line"></div>
              <div className="v-arrow-head"></div>
              <div className="h-line branch-line"></div>
            </div>
            <div className="h-arrow" style={{ gridRow: '4', gridColumn: '4' }}></div>
            <div id="fig-ex-screen" className="ex-box" style={{ gridRow: '4', gridColumn: '5' }}>Excluded by filters</div>

            {/* Stage 3: Eligibility */}
            <div className="phase-box phase-elig" style={{ gridRow: '5 / 7' }}>Eligibility</div>
            <div id="fig-elig" className="main-box" style={{ gridRow: '5', gridColumn: '3' }}>Eligibility</div>

            {/* Transition 3 -> 4 with Exclusion */}
            <div className="v-arrow" style={{ gridRow: '6', gridColumn: '3' }}>
              <div className="v-arrow-line"></div>
              <div className="v-arrow-head"></div>
              <div className="h-line branch-line"></div>
            </div>
            <div className="h-arrow" style={{ gridRow: '6', gridColumn: '4' }}></div>
            <div id="fig-ex-manual" className="ex-box" style={{ gridRow: '6', gridColumn: '5' }}>Excluded manually</div>

            {/* Stage 4: Included */}
            <div className="phase-box phase-incl" style={{ gridRow: '7 / 9' }}>Included</div>
            <div id="fig-final" className="main-box final-box" style={{ gridRow: '7', gridColumn: '3' }}>Included</div>
        </div>
      </div>
      </div>
      <footer className="h-10 bg-white border-t border-slate-200 px-8 flex items-center justify-between text-[10px] text-slate-400 uppercase tracking-widest mt-auto">
        <div className="flex gap-6">
          <span>ReviewAID</span>
          <span>Mode: Desktop Standalone</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          <span>Environment Optimized</span>
        </div>
      </footer>

      {showKeyModal && (
        <div 
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 animate-fade-in"
          onClick={() => setShowKeyModal(false)}
        >
          <div 
            className="bg-white rounded-xl shadow-xl border border-slate-200 p-6 w-full max-w-md animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-700 text-lg font-bold">
                🔑
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-base">Configure Gemini API Key</h3>
                <p className="text-xs text-slate-500">Provide your Google Gemini API key to run AI features directly.</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Your Gemini API Key</label>
                <input
                  type="password"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono text-slate-900 placeholder:text-slate-300"
                  placeholder="AIzaSy..."
                  value={inputKey}
                  onChange={(e) => setInputKey(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      const trimmed = inputKey.trim();
                      if (trimmed) {
                        try {
                          localStorage.setItem("user_gemini_api_key", trimmed);
                        } catch (err) {
                          console.warn("Storage write blocked inside sandbox", err);
                        }
                        (window as any).__user_gemini_api_key = trimmed;
                        setHasCustomKey(true);
                      } else {
                        try {
                          localStorage.removeItem("user_gemini_api_key");
                        } catch {}
                        delete (window as any).__user_gemini_api_key;
                        setHasCustomKey(false);
                      }
                      setShowKeyModal(false);
                    }
                  }}
                />
                <p className="text-[10px] text-slate-405 mt-1.5 leading-relaxed">
                  Get your key from <a href="https://aistudio.google.com/" target="_blank" rel="noopener noreferrer" className="text-purple-600 hover:underline">Google AI Studio</a>. Your key is stored locally in your browser memory and only sent directly to Google's official Gemini API endpoint.
                </p>
              </div>
              
              <div className="flex items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  className="px-3 py-1.5 text-xs font-semibold text-red-650 hover:text-red-750 bg-red-50 hover:bg-red-100 border border-red-150 rounded-lg cursor-pointer transition-colors"
                  onClick={() => {
                    try {
                      localStorage.removeItem("user_gemini_api_key");
                    } catch {}
                    delete (window as any).__user_gemini_api_key;
                    setInputKey("");
                    setHasCustomKey(false);
                    setShowKeyModal(false);
                  }}
                >
                  Clear Key
                </button>
                
                <div className="flex gap-2">
                  <button
                    type="button"
                    className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-750 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg cursor-pointer transition-colors"
                    onClick={() => setShowKeyModal(false)}
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 border border-transparent rounded-lg cursor-pointer transition-colors shadow-sm"
                    onClick={() => {
                      const trimmed = inputKey.trim();
                      if (trimmed) {
                        try {
                          localStorage.setItem("user_gemini_api_key", trimmed);
                        } catch (err) {
                          console.warn("Storage write blocked inside sandbox", err);
                        }
                        (window as any).__user_gemini_api_key = trimmed;
                        setHasCustomKey(true);
                      } else {
                        try {
                          localStorage.removeItem("user_gemini_api_key");
                        } catch {}
                        delete (window as any).__user_gemini_api_key;
                        setHasCustomKey(false);
                      }
                      setShowKeyModal(false);
                    }}
                  >
                    Save Key
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
