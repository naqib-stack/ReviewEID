

declare global {
  interface Window {
    rawData: any;
    temporaryFilteredLists: any;
    filteredList: any[];
    assignments: any[][];
    totalInitial: number;
    globalExCounts: any;
    affiliationsData: string[];
    authorsData: any[];
    aiExclusions: any;
    callGemini: (prompt: string) => Promise<string>;
    autoGenerateIntro: () => Promise<void>;
    autoAnalyzeManualSelection: () => Promise<void>;
    toggleGeminiResultInput: () => void;
    openTab: (evt: any, tabName: string) => void;
    syncAll: () => void;
    loadCSV: (db: string) => void;
    runScreening: () => void;
    autoRunFilters: () => void;
    combineAndDeduplicate: () => void;
    toggleManualInclusion: (idx: number) => void;
    toggleFinalInclusion: (idx: number) => void;
    renderFinalReferencePool: () => void;
    renderManualSelectionTable: (indices: number[]) => void;
    toggleFinalInclusionFromSelection: (idx: number) => void;
    syncManualPaste: () => void;
    parseManualTable: () => void;
    resetManualSelectionTable: () => void;
    renderReferenceLists: () => void;
    updateFinalCounts: () => void;
    updatePrismaFigure: () => void;
    generateThemes: () => void;
    parseAndDistributeThemes: () => void;
    generateThematicTable: () => void;
    generateSeparatedThematicTables: () => void;
    genMasterDiscussion: () => void;
    showCitationMenu: (x: number, y: number) => void;
    hideCitationMenu: () => void;
    insertTextAtCursor: (el: HTMLElement, text: string) => void;
    genSearchPrompt: () => void;
    addAuthorRow: () => void;
    renderAuthors: () => void;
    toggleAuthorAffil: (authIdx: number, affIdx: number) => void;
    addAffiliationRow: () => void;
    renderAffiliations: () => void;
    generateAuthorAffiliations: () => void;
    compileFinalManuscript: () => void;
    genManualSelectionPrompt: () => void;
    generateSummaryMatrixPrompt: () => void;
    genAbstractPromptDetailed: () => void;
    genCoverLetterPrompt: () => void;
    copyFullManuscript: () => void;
    downloadManuscript: () => void;
    syncPaperDraft: (silent?: boolean) => void;
    saveWork: () => Promise<void>;
    loadWork: (event: any) => void;
    toggleProjectMode: () => void;
    runHealthCheck: () => void;
    setActiveTextarea: (id: string) => void;
    renderReferenceSidebar: () => void;
    citeReference: (refId: string) => void;
    updateReferenceList: () => void;
    resetProject: () => boolean;
    genMethodsPrompt: () => void;
    refineIntroduction: () => Promise<void>;
    autoSynthesizeDiscussion: () => Promise<void>;
    refineDiscussion: () => Promise<void>;
    compileResults: () => void;
    syncAndArrangeReferences: (boxId: string) => void;
  }
}

export function initLogic() {
  window.rawData = { wos: [], scopus: [], ncbi: [], scholar: [], cochrane: [], embase: [], ieee: [], cinahl: [], psycinfo: [], eric: [], sciencedirect: [], wiley: [] };
  window.temporaryFilteredLists = { wos: [], scopus: [], ncbi: [], scholar: [], cochrane: [], embase: [], ieee: [], cinahl: [], psycinfo: [], eric: [], sciencedirect: [], wiley: [] };
  window.filteredList = [];
  window.assignments = [[], [], [], [], []];
  window.totalInitial = 0;
  window.globalExCounts = { year: 0, lang: 0, docType: 0, rct: 0, keyword: 0, dup: 0 };
  window.affiliationsData = [""];
  window.authorsData = [{ name: "", affilLink: "", isCorresponding: false, email: "" }];
  window.finalActiveHistory = [];
  window.finalActiveHistoryIndex = -1;

  function cleanStringForMatch(str: string): string {
    return str.toLowerCase().replace(/[^a-z0-9]/g, '').trim();
  }

  function findExistingReferenceIndex(parsedTitle: string): number {
    const cleanParsed = cleanStringForMatch(parsedTitle);
    if (!cleanParsed) return -1;
    
    return window.filteredList.findIndex(item => {
      const cleanDbTitle = cleanStringForMatch(item.data.title || "");
      if (!cleanDbTitle) return false;
      return cleanDbTitle === cleanParsed || cleanDbTitle.includes(cleanParsed) || cleanParsed.includes(cleanDbTitle);
    });
  }

  window.formatReferenceAPA = function(item: any, isHtml: boolean = false): string {
    if (!item || !item.data) return "";
    
    let authors = (item.data.authors || "Unknown").trim();
    // Trim trailing dot unless it's a standard capital letter initial (e.g., "A.")
    if (authors.endsWith('.')) {
      if (!authors.match(/[A-Z]\.$/)) {
        authors = authors.slice(0, -1).trim();
      }
    }

    let year = (item.data.year || "n.d.").trim();
    year = year.replace(/[\(\)]/g, '').trim();

    let title = (item.data.title || "Untitled").trim();
    title = title.replace(/\.+$/, "").trim();

    let journal = (item.data.journal || "").trim();
    journal = journal.replace(/\.+$/, "").trim();

    if (journal) {
      const journalFormatted = isHtml ? `<em>${journal}</em>` : journal;
      return `${authors} (${year}). ${title}. ${journalFormatted}.`;
    } else {
      return `${authors} (${year}). ${title}.`;
    }
  };

  function parseApaReference(rawRefLine: string) {
    let text = rawRefLine.trim();
    // Remove leading numbers, brackets like [1], 1., etc.
    text = text.replace(/^\[?\d+\]?\.?\s*/, '').trim();
    if (!text) return null;

    let authors = "Unknown";
    let year = "n.d.";
    let title = text;
    let journal = "";

    const yearRegex = /\((\d{4})[a-z]?\)/;
    const yearMatch = text.match(yearRegex);
    
    if (yearMatch) {
      year = yearMatch[1];
      const indexOfYear = text.indexOf(yearMatch[0]);
      
      const authorPart = text.substring(0, indexOfYear).trim();
      if (authorPart) {
        authors = authorPart.replace(/,\s*$/, '').replace(/\.\s*$/, '').trim();
      }
      
      const afterYear = text.substring(indexOfYear + yearMatch[0].length).trim();
      if (afterYear) {
        let remaining = afterYear.replace(/^[\s\.\,]+/, '').trim();
        const parts = remaining.split(/\.\s+/);
        if (parts.length > 0) {
          title = parts[0].trim();
          if (!title.endsWith('.')) title += '.';
          if (parts.length > 1) {
            journal = parts.slice(1).join('. ').trim();
          }
        } else {
          title = remaining;
        }
      }
    } else {
      const anyYearRegex = /\b(19\d{2}|20\d{2})\b/;
      const anyYearMatch = text.match(anyYearRegex);
      if (anyYearMatch) {
        year = anyYearMatch[1];
      }
      title = text;
    }

    title = title.replace(/^[\s\.\,\-\:]+/, '').trim();
    if (journal) {
      journal = journal.replace(/^[\s\.\,\-\:]+/, '').trim();
    }

    return {
      raw: rawRefLine.trim(),
      authors,
      year,
      title,
      journal: journal || "Academic Source"
    };
  }

  window.syncAndArrangeReferences = function(boxId: string) {
    const box = document.getElementById(boxId);
    if (!box) return;

    // Get text properly whether it's a div or textarea
    const rawText = box.tagName === 'TEXTAREA' ? (box as HTMLTextAreaElement).value.trim() : (box as HTMLElement).innerText.trim();
    if (!rawText) return;

    const lines = rawText.split(/\r?\n/).map(l => l.trim()).filter(l => {
      if (!l) return false;
      const lower = l.toLowerCase();
      if (lower === 'references' || lower === 'bibliography' || lower === 'reference list' || lower === 'sources') return false;
      return true;
    });

    const parsedRefs = lines.map(line => parseApaReference(line)).filter(r => r !== null) as Array<NonNullable<ReturnType<typeof parseApaReference>>>;

    if (parsedRefs.length === 0) return;

    // Sort alphabetically
    parsedRefs.sort((a, b) => {
      const authA = a.authors.toLowerCase();
      const authB = b.authors.toLowerCase();
      if (authA !== authB) return authA.localeCompare(authB);
      
      const yA = a.year.toLowerCase();
      const yB = b.year.toLowerCase();
      if (yA !== yB) return yA.localeCompare(yB);
      
      return a.title.toLowerCase().localeCompare(b.title.toLowerCase());
    });

    // Format beautifully as nice APA strings
    const formattedLines = parsedRefs.map(ref => {
      return window.formatReferenceAPA({ data: ref }, false);
    });

    const finalVal = formattedLines.join("\n\n");
    if (box.tagName === 'TEXTAREA') {
      (box as HTMLTextAreaElement).value = finalVal;
    } else {
      box.innerText = finalVal;
    }

    let updatedAny = false;
    if (!(window as any).usedReferences) {
      (window as any).usedReferences = new Set<number>();
    }

    parsedRefs.forEach(ref => {
      const existingIdx = findExistingReferenceIndex(ref.title);
      if (existingIdx > -1) {
        window.filteredList[existingIdx].active = true;
        window.filteredList[existingIdx].finalActive = true;
        (window as any).usedReferences.add(existingIdx);
        updatedAny = true;
      } else {
        const newIndex = window.filteredList.length;
        window.filteredList.push({
          data: {
            title: ref.title.replace(/\.$/, ''),
            authors: ref.authors,
            year: ref.year,
            journal: ref.journal.replace(/\.$/, '')
          },
          active: true,
          finalActive: true,
          manualDesign: 'Extracted',
          aiCategories: []
        });
        (window as any).usedReferences.add(newIndex);
        updatedAny = true;
      }
    });

    if (updatedAny) {
      window.updateReferenceList();
      window.renderFinalReferencePool();
      window.updateFinalCounts();
      window.renderReferenceSidebar();
    }
  };

  window.callGemini = async function(promptText: string) {
    let customKey = "";
    try {
      customKey = localStorage.getItem('user_gemini_api_key') || '';
    } catch {
      // ignore security blocks
    }
    if (!customKey && (window as any).__user_gemini_api_key) {
      customKey = (window as any).__user_gemini_api_key;
    }

    // Direct Google Gemini REST API execution if user provides a custom key.
    // This provides robust client-side execution on offline, Windows, or compiled standalone Electron apps.
    if (customKey && customKey.trim()) {
      try {
        console.log("Detecting custom Gemini API Key. Triggering direct client-to-Google Cloud API request.");
        const cleanKey = customKey.trim();
        const directUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${cleanKey}`;
        const response = await fetch(directUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: promptText
                  }
                ]
              }
            ]
          }),
        });

        if (!response.ok) {
          const errObj = await response.json().catch(() => ({}));
          const errMsg = errObj.error?.message || response.statusText || "Direct API call failed";
          throw new Error(errMsg);
        }

        const data = await response.json();
        const textOut = data.candidates?.[0]?.content?.parts?.[0]?.text;
        if (textOut) {
          return textOut;
        }
        throw new Error("No text content returned in candidates from direct Gemini call");
      } catch (directErr: any) {
        console.error("Direct Google Gemini REST API call failed:", directErr);
        // Fall back to server endpoints below
      }
    }

    // fallback to normal/system server endpoint
    try {
      const response = await fetch('/api/gemini', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gemini-API-Key': customKey || '',
        },
        body: JSON.stringify({ prompt: promptText }),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || "API call failed");
      }
      const data = await response.json();
      return data.text || "";
    } catch (e: any) {
      console.warn("Real Gemini API call failed, falling back to manual prompt:", e);
      const response = prompt("PROMPT SENT TO GEMINI:\n\n" + promptText.substring(0, 300) + "...\n\nPLEASE PASTE GEMINI RESULT HERE:\n\n(Error detail: " + (e.message || e) + ")");
      return response || "";
    }
  };

  window.toggleGeminiResultInput = function() {
    const pasteArea = document.getElementById('manualTablePaste');
    const toggleBtn = document.getElementById('btnToggleGeminiResultInput');
    if (pasteArea && toggleBtn) {
      if (pasteArea.style.display === 'none') {
        pasteArea.style.display = 'block';
        toggleBtn.innerHTML = '👁️ Hide';
      } else {
        pasteArea.style.display = 'none';
        toggleBtn.innerHTML = '👁️ Show';
      }
    }
  };

  window.autoAnalyzeManualSelection = async function() {
    const btn = document.getElementById('btnAutoAnalyzeManual') as HTMLButtonElement;
    const initialText = btn ? btn.innerHTML : "⚡ Auto-Analyze & Finalize Selection";
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<span class="inline-flex items-center gap-2">🔄 Analyzing references via Gemini...</span>`;
    }

    // Progress Bar Elements
    const progressBarContainer = document.getElementById('geminiProgressBarContainer');
    const progressBar = document.getElementById('geminiProgressBar');
    const progressPercent = document.getElementById('geminiProgressPercent');
    const progressText = document.getElementById('geminiProgressText');

    let progressInterval: any;

    if (progressBarContainer && progressBar) {
      progressBarContainer.style.display = 'block';
      progressBar.style.width = '0%';
      if (progressPercent) progressPercent.innerText = '0%';
      if (progressText) progressText.innerText = 'Analyzing references with Gemini...';
      
      let progress = 0;
      progressInterval = setInterval(() => {
        if (progress < 95) {
          progress += Math.floor(Math.random() * 6) + 2; // Increment by 2-7%
          if (progress > 95) progress = 95;
          progressBar.style.width = `${progress}%`;
          if (progressPercent) progressPercent.innerText = `${progress}%`;
          
          if (progressText) {
            if (progress < 30) {
              progressText.innerText = 'Analyzing references with Gemini...';
            } else if (progress < 60) {
              progressText.innerText = 'Extracting study designs and methodologies...';
            } else if (progress < 85) {
              progressText.innerText = 'Summarizing key findings and outcomes...';
            } else {
              progressText.innerText = 'Generating tabular format...';
            }
          }
        }
      }, 300);
    }

    try {
      let dataStr = "";
      let count = 0;
      window.filteredList.forEach((f, idx) => {
        if (!f.active) return;
        count++;
        const a = f.data;
        dataStr += `\n[ID: ${idx + 1}] Author: ${a['authors'] || 'N/A'}, Year: ${a['year'] || 'N/A'}, Title: ${a['title'] || 'N/A'}`;
        if (a['abstract']) {
          const abstract = a['abstract'].length > 800 ? a['abstract'].substring(0, 800) + "..." : a['abstract'];
          dataStr += `, Abstract: ${abstract}`;
        }
        dataStr += `\n`;
      });

      if (count === 0) {
        alert("No references are currently selected for screening. Please load search result CSV files first and ensure they are active.");
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = initialText;
        }
        if (progressBarContainer) progressBarContainer.style.display = 'none';
        if (progressInterval) clearInterval(progressInterval);
        return;
      }

      const prompt = `You are an expert systematic literature review analysis assistant.
I have a list of ${count} research articles that have passed our initial database filtration screening.
Your task is to analyze these papers' titles (and abstracts, where provided) to:
1. Determine or identify their precise Study Design/Type (e.g., Randomized Controlled Trial, Cohort Study, Surveys/Questionnaire, Qualitative interviews, Systematic Review, Cross-sectional Study, etc.).
2. Summarize their Key Findings/Outcomes concisely in 1-2 powerful academic sentences.

IMPORTANT RULES:
- Please evaluate each paper individually based strictly on the provided Title/Abstract.
- You MUST return the output EXACTLY as a single Markdown Table with these four columns:
ID | Reference | Study Type/Design | Key Findings

- Do NOT include any intro paragraphs, pleasantries, apologies, markdown backticks, or extra text outside of the table itself! Start wrapping directly with the table header.
- Ensure the ID column matches the specified ID number (e.g., 1, 2, 3...) exactly.
- Keep the "Reference" column as Short "Author & Year" (e.g., Smith et al., 2020).

Here are the selected references to evaluate:
${dataStr}`;

      const resultText = await window.callGemini(prompt);
      if (!resultText) {
        throw new Error("No response received from Gemini.");
      }

      // Finish progress bar animation beautifully
      if (progressInterval) clearInterval(progressInterval);
      if (progressBar) progressBar.style.width = '100%';
      if (progressPercent) progressPercent.innerText = '100%';
      if (progressText) progressText.innerText = 'Analysis complete!';

      // Clean the returned markdown slightly (ensure no code block markers at start/end)
      let cleanText = resultText.trim();
      if (cleanText.startsWith("```markdown")) {
        cleanText = cleanText.substring(11).trim();
      }
      if (cleanText.startsWith("```")) {
        cleanText = cleanText.substring(3).trim();
      }
      if (cleanText.endsWith("```")) {
        cleanText = cleanText.substring(0, cleanText.length - 3).trim();
      }

      // Paste it into manualTablePaste
      const pasteArea = document.getElementById('manualTablePaste');
      if (pasteArea) {
        pasteArea.innerText = cleanText;
        // BY DEFAULT HIDE IT as requested: "by default set it to hide"
        pasteArea.style.display = 'none';
      }

      // Show the Toggle Show/Hide Button as requested: "If user select..., add Hide/Show button"
      const toggleBtn = document.getElementById('btnToggleGeminiResultInput');
      if (toggleBtn) {
        toggleBtn.style.display = 'block';
        toggleBtn.innerHTML = '👁️ Show';
      }

      // Parse the table to populate the manual selection state
      (window as any).parseManualTable();

      // Ensure the manual output section (including the "Finalize Selected References" button) is shown
      const outSec = document.getElementById('manualOutputSection');
      if (outSec) {
        outSec.style.display = 'block';
      }

      // Ensure final section is shown
      const finalSec = document.getElementById('finalRefsSection');
      if (finalSec) {
        finalSec.style.display = 'block';
        finalSec.scrollIntoView({ behavior: 'smooth' });
      }

    } catch (err: any) {
      console.error("Auto-analysis error:", err);
      alert("Failed to auto-analyze selection: " + (err.message || err));
    } finally {
      if (progressInterval) clearInterval(progressInterval);
      setTimeout(() => {
        if (progressBarContainer) progressBarContainer.style.display = 'none';
      }, 1000);
      
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = initialText;
      }
    }
  };

  window.autoGenerateIntro = async function() {
    window.syncAll();
    const promptText = (document.getElementById('introPromptText') as HTMLElement).innerText;
    const result = await window.callGemini(promptText);
    if (result) {
        const el = document.getElementById('finalIntroEdit');
        if (el) {
            if (el.tagName === 'TEXTAREA') (el as HTMLTextAreaElement).value = result;
            else (el as HTMLElement).innerText = result;
        }
    }
  };

  function splitTextByReferences(text: string): { introduction: string; references: string } {
    const lines = text.split(/\r?\n/);
    let splitIndex = -1;
    
    // Robust pattern checking: line starting with potential whitespace, markdown headers like # or **,
    // then the keyword, then ending with optional colons, asterisks, spaces, or **
    const refHeaderRegex = /^\s*(?:#+|\*+)?\s*(?:REFERENCES|REFERENCE|REFERENECES|REFERECES|BIBLIOGRAPHY|BIBLIOGRAPHIES)\s*(?::|\*)*\s*$/i;
    
    for (let i = 0; i < lines.length; i++) {
      const trimmedLine = lines[i].trim();
      if (refHeaderRegex.test(trimmedLine)) {
        splitIndex = i;
        break;
      }
    }
    
    // Fallback 1: check if line starts with the keyword followed by a space or end of line
    if (splitIndex === -1) {
      const fallbackRegex = /^\s*(?:#+|\*+)?\s*(REFERENCES|REFERENCE|REFERENECES|REFERECES|BIBLIOGRAPHY|BIBLIOGRAPHIES)\b/i;
      for (let i = 0; i < lines.length; i++) {
        if (fallbackRegex.test(lines[i].trim())) {
          splitIndex = i;
          break;
        }
      }
    }
    
    // Fallback 2: search for the word as a whole word anywhere in the text
    if (splitIndex === -1) {
      const wordRegex = /\b(REFERENCES|REFERENCE|REFERENECES|REFERECES|BIBLIOGRAPHY|BIBLIOGRAPHIES)\b/i;
      const match = text.match(wordRegex);
      if (match && match.index !== undefined) {
        const index = match.index;
        return {
          introduction: text.substring(0, index).trim(),
          references: text.substring(index).trim()
        };
      }
    }
    
    if (splitIndex !== -1) {
      const introPart = lines.slice(0, splitIndex).join('\n').trim();
      // Keep everything from splitIndex onwards (the references part)
      const refPart = lines.slice(splitIndex).join('\n').trim();
      return {
        introduction: introPart,
        references: refPart
      };
    }
    
    return {
      introduction: text.trim(),
      references: ''
    };
  }

  function parseIntroSections(text: string): { questions: string; objectives: string; introduction: string } {
    let questions = "";
    let objectives = "";
    let introduction = text;

    const questionRegexes = [
      /(?:^|\n)\s*(?:#+|\*+|-)?\s*1\b[^\n]*research[^\n]*/i,
      /(?:^|\n)\s*(?:#+|\*+|-)?\s*1\.\s*(?:list\s*the\s*most\s*probable\s*explicit\s*)?research\s*questions?/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*explicit\s*research\s*questions?\s*:?/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*research\s*questions?\s*:?/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*1\.\s*/i
    ];

    const objectiveRegexes = [
      /(?:^|\n)\s*(?:#+|\*+|-)?\s*2\b[^\n]*(?:objective|targeted)[^\n]*/i,
      /(?:^|\n)\s*(?:#+|\*+|-)?\s*2\.\s*(?:list\s*the\s*most\s*probable\s*targeted\s*)?(?:review\s*)?objectives?/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*targeted\s*review\s*objectives?\s*:?/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*review\s*objectives?\s*:?/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*objectives?\s*:?/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*2\.\s*/i
    ];

    const introRegexes = [
      /(?:^|\n)\s*(?:#+|\*+|-)?\s*3\b[^\n]*(?:introduction|comprehensive)[^\n]*/i,
      /(?:^|\n)\s*(?:#+|\*+|-)?\s*3\.\s*(?:write\s*a\s*comprehensive\s*)?introduction/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*comprehensive\s*introduction\s*:?/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*3\.\s*/i,
      /(?:^|\n)\s*(?:#+|\*+)?\s*introduction\s*:?/i
    ];

    let qIdx = -1;
    let qMatchLen = 0;
    for (const rx of questionRegexes) {
      const match = text.match(rx);
      if (match && match.index !== undefined) {
        qIdx = match.index;
        qMatchLen = match[0].length;
        break;
      }
    }

    let objIdx = -1;
    let objMatchLen = 0;
    for (const rx of objectiveRegexes) {
      const match = text.match(rx);
      if (match && match.index !== undefined) {
        if (qIdx === -1 || match.index > qIdx) {
          objIdx = match.index;
          objMatchLen = match[0].length;
          break;
        }
      }
    }

    let introIdx = -1;
    let introMatchLen = 0;
    for (const rx of introRegexes) {
      const match = text.match(rx);
      if (match && match.index !== undefined) {
        const minIdx = objIdx !== -1 ? objIdx : qIdx;
        if (minIdx === -1 || match.index > minIdx) {
          introIdx = match.index;
          introMatchLen = match[0].length;
          break;
        }
      }
    }

    if (qIdx !== -1 && objIdx !== -1 && introIdx !== -1) {
      questions = text.substring(qIdx + qMatchLen, objIdx).trim();
      objectives = text.substring(objIdx + objMatchLen, introIdx).trim();
      introduction = text.substring(introIdx + introMatchLen).trim();
    } else if (qIdx !== -1 && objIdx !== -1) {
      questions = text.substring(qIdx + qMatchLen, objIdx).trim();
      objectives = text.substring(objIdx + objMatchLen).trim();
      introduction = "";
    } else if (objIdx !== -1 && introIdx !== -1) {
      questions = "";
      objectives = text.substring(objIdx + objMatchLen, introIdx).trim();
      introduction = text.substring(introIdx + introMatchLen).trim();
    } else if (qIdx !== -1 && introIdx !== -1) {
      questions = text.substring(qIdx + qMatchLen, introIdx).trim();
      objectives = "";
      introduction = text.substring(introIdx + introMatchLen).trim();
    } else if (introIdx !== -1) {
      const beforeText = text.substring(0, introIdx).trim();
      introduction = text.substring(introIdx + introMatchLen).trim();
      
      let subObjIdx = -1;
      let subObjMatchLen = 0;
      for (const rx of objectiveRegexes) {
        const match = beforeText.match(rx);
        if (match && match.index !== undefined) {
          subObjIdx = match.index;
          subObjMatchLen = match[0].length;
          break;
        }
      }
      
      if (subObjIdx !== -1) {
        let beforeBefore = beforeText.substring(0, subObjIdx).trim();
        for (const rx of questionRegexes) {
          const match = beforeBefore.match(rx);
          if (match && match.index !== undefined && match.index === 0) {
            beforeBefore = beforeBefore.substring(match[0].length).trim();
            break;
          }
        }
        questions = beforeBefore;
        objectives = beforeText.substring(subObjIdx + subObjMatchLen).trim();
      } else {
        let beforeBefore = beforeText;
        for (const rx of questionRegexes) {
          const match = beforeBefore.match(rx);
          if (match && match.index !== undefined && match.index === 0) {
            beforeBefore = beforeBefore.substring(match[0].length).trim();
            break;
          }
        }
        questions = beforeBefore;
      }
    } else {
      const fallbackIdx1 = text.indexOf("1.");
      const fallbackIdx2 = text.indexOf("2.");
      const fallbackIdx3 = text.indexOf("3.");
      if (fallbackIdx1 !== -1 && fallbackIdx2 !== -1 && fallbackIdx3 !== -1 && fallbackIdx1 < fallbackIdx2 && fallbackIdx2 < fallbackIdx3) {
        questions = text.substring(fallbackIdx1 + 2, fallbackIdx2).trim();
        objectives = text.substring(fallbackIdx2 + 2, fallbackIdx3).trim();
        introduction = text.substring(fallbackIdx3 + 2).trim();
      } else {
        const lines = text.split(/\r?\n/);
        let currentSection: 'questions' | 'objectives' | 'introduction' = 'introduction';
        const qLines: string[] = [];
        const oLines: string[] = [];
        const iLines: string[] = [];

        for (const line of lines) {
          const lLower = line.toLowerCase();
          if (lLower.includes("research question") || /^\s*1\.\s+/i.test(line)) {
            currentSection = 'questions';
            if (lLower.trim() === "research questions" || lLower.trim() === "1. research questions" || lLower.trim() === "explicit research questions") continue;
          } else if (lLower.includes("review objective") || lLower.includes("targeted objective") || /^\s*2\.\s+/i.test(line)) {
            currentSection = 'objectives';
            if (lLower.trim() === "review objectives" || lLower.trim() === "2. review objectives" || lLower.trim() === "targeted review objectives") continue;
          } else if (lLower.includes("introduction") || /^\s*3\.\s+/i.test(line)) {
            currentSection = 'introduction';
            if (lLower.trim() === "introduction" || lLower.trim() === "3. introduction" || lLower.trim() === "comprehensive introduction") continue;
          }

          if (currentSection === 'questions') qLines.push(line);
          else if (currentSection === 'objectives') oLines.push(line);
          else iLines.push(line);
        }
        questions = qLines.join('\n').trim();
        objectives = oLines.join('\n').trim();
        introduction = iLines.join('\n').trim();
      }
    }

    const cleanLeadingTitle = (str: string, word: string) => {
      let cleaned = str.trim();
      const prefixRegex = new RegExp(`^\\s*(?:#+|\\*+|-|\\d+\\.)?\\s*(?:list\\s*the\\s*most\\s*probable\\s*explicit\\s*|list\\s*the\\s*most\\s*probable\\s*targeted\\s*|write\\s*a\\s*comprehensive\\s*)?${word}s?\\b\\s*(?::|-|\\*)*\\s*`, 'i');
      cleaned = cleaned.replace(prefixRegex, '').trim();
      return cleaned;
    };

    questions = cleanLeadingTitle(questions, "research question");
    objectives = cleanLeadingTitle(objectives, "objective");
    introduction = cleanLeadingTitle(introduction, "introduction");

    return { questions, objectives, introduction };
  }

  window.refineIntroduction = async function() {
    const finalIntroEdit = document.getElementById('finalIntroEdit');
    if (!finalIntroEdit) return;
    
    const text = (finalIntroEdit as HTMLElement).innerText.trim();
    if (!text) {
      alert("Please paste or generate the Gemini Results Input first.");
      return;
    }

    const btn = document.getElementById('btnRefineIntro');
    const loading = document.getElementById('refineIntroLoading');
    if (btn) (btn as HTMLButtonElement).disabled = true;
    if (loading) loading.style.display = 'flex';

    try {
      const result = splitTextByReferences(text);
      const parsed = parseIntroSections(result.introduction);

      const qBox = document.getElementById('refinedResearchQuestions');
      if (qBox) {
        qBox.innerText = parsed.questions || "";
        qBox.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const objBox = document.getElementById('refinedObjectives');
      if (objBox) {
        objBox.innerText = parsed.objectives || "";
        objBox.dispatchEvent(new Event('input', { bubbles: true }));
      }
      
      const introBox = document.getElementById('refinedIntro');
      if (introBox) {
        introBox.innerText = parsed.introduction || "";
        introBox.dispatchEvent(new Event('input', { bubbles: true }));
      }
      
      const refsBox = document.getElementById('refinedIntroRefs');
      if (refsBox) {
        refsBox.innerText = result.references || "";
        // Automatically arrange and sync the references
        window.syncAndArrangeReferences('refinedIntroRefs');
      }
      
      if (typeof (window as any).addReferencesFromText === 'function') {
        (window as any).addReferencesFromText(result.introduction, 'tab2');
      }
      if (typeof window.syncPaperDraft === 'function') {
        window.syncPaperDraft(true);
      }
    } catch (err: any) {
      console.error(err);
      alert("Error refining introduction: " + err.message);
    } finally {
      if (btn) (btn as HTMLButtonElement).disabled = false;
      if (loading) loading.style.display = 'none';
    }
  };

  window.autoSynthesizeDiscussion = async function() {
    const themes = [];
    for (let i = 1; i <= 5; i++) {
      const themeBox = document.getElementById(`discThemeSummary${i}`);
      const themeText = themeBox ? (themeBox as HTMLElement).innerText.trim() : "";
      const themeName = document.getElementById(`dispName${i}`)?.innerText || `Theme ${i}`;
      if (themeText) {
        themes.push({ id: i, name: themeName, text: themeText });
      }
    }

    if (themes.length === 0) {
      alert("Please paste or generate Sectional Discussion Results for Theme 1-5 first.");
      return;
    }

    const btn = document.getElementById('btnSynthesizeDisc');
    const loading = document.getElementById('synthesizeDiscLoading');
    if (btn) (btn as HTMLButtonElement).disabled = true;
    if (loading) loading.style.display = 'flex';

    try {
      let compiledNarrative = "4.0 Discussion\n\n";
      let compiledReferences = "";

      for (const theme of themes) {
        const splitResult = splitTextByReferences(theme.text);
        
        if (compiledNarrative !== "4.0 Discussion\n\n") {
          compiledNarrative += "\n\n";
        }
        compiledNarrative += `### ${theme.name.toUpperCase()}\n${splitResult.introduction}`;
        
        if (splitResult.references) {
          if (compiledReferences) {
            compiledReferences += "\n\n";
          }
          compiledReferences += splitResult.references;
        }
      }

      const discBox = document.getElementById('finalDiscEdit');
      if (discBox) {
        discBox.innerText = compiledNarrative;
      }
      
      const refsBox = document.getElementById('finalDiscRefs');
      if (refsBox) {
        refsBox.innerText = compiledReferences;
        window.syncAndArrangeReferences('finalDiscRefs');
      }

      if (discBox) {
        discBox.dispatchEvent(new Event('input', { bubbles: true }));
      }

      if (typeof (window as any).addReferencesFromText === 'function') {
        (window as any).addReferencesFromText(compiledNarrative, 'tab6');
      }
      if (typeof window.syncPaperDraft === 'function') {
        window.syncPaperDraft(true);
      }
    } catch (err: any) {
      console.error(err);
      alert("Error synthesizing discussion: " + err.message);
    } finally {
      if (btn) (btn as HTMLButtonElement).disabled = false;
      if (loading) loading.style.display = 'none';
    }
  };

  window.refineDiscussion = async function() {
    const rawDiscInput = document.getElementById('rawGeminiDiscussionInput');
    if (!rawDiscInput) return;

    const text = (rawDiscInput as HTMLElement).innerText.trim();
    if (!text) {
      alert("Please paste or insert Gemini combined discussion output into the Gemini Results Input box first.");
      return;
    }

    const btn = document.getElementById('btnRefineDiscussion');
    const loading = document.getElementById('refineDiscussionLoading');
    if (btn) (btn as HTMLButtonElement).disabled = true;
    if (loading) loading.style.display = 'flex';

    try {
      const result = splitTextByReferences(text);
      
      let finalIntro = result.introduction || "";
      if (!/^\s*4\.0\s+discussion/i.test(finalIntro)) {
        finalIntro = "4.0 Discussion\n\n" + finalIntro;
      }

      const discBox = document.getElementById('finalDiscEdit');
      if (discBox) {
        discBox.innerText = finalIntro;
      }

      const refsBox = document.getElementById('finalDiscRefs');
      if (refsBox) {
        refsBox.innerText = result.references || "";
        window.syncAndArrangeReferences('finalDiscRefs');
      }

      if (discBox) {
        discBox.dispatchEvent(new Event('input', { bubbles: true }));
      }

      if (typeof (window as any).addReferencesFromText === 'function') {
        (window as any).addReferencesFromText(finalIntro, 'tab6');
      }
      if (typeof window.syncPaperDraft === 'function') {
        window.syncPaperDraft(true);
      }
    } catch (err: any) {
      console.error(err);
      alert("Error splitting discussion: " + err.message);
    } finally {
      if (btn) (btn as HTMLButtonElement).disabled = false;
      if (loading) loading.style.display = 'none';
    }
  };

  window.compileResults = function() {
    let themesFound = 0;
    const themeNarratives: string[] = [];
    const uniqueRefLines = new Map<string, string>();

    for (let i = 1; i <= 5; i++) {
      const themeBox = document.getElementById(`themeSummary${i}`);
      const themeText = themeBox ? (themeBox as HTMLElement).innerText.trim() : "";
      
      if (themeText) {
        themesFound++;
        const splitResult = splitTextByReferences(themeText);
        
        // Split introduction by lines, clean up, and join with exactly one empty line (\n\n)
        const cleanedIntro = splitResult.introduction
          .split(/\r?\n/)
          .map(line => line.trim())
          .filter(line => line.length > 0)
          .join("\n\n");
          
        if (cleanedIntro) {
          themeNarratives.push(cleanedIntro);
        }

        // Gather unique references by cleaning leading numberings/brackets
        if (splitResult.references) {
          const refLines = splitResult.references.split(/\r?\n/).map(l => l.trim()).filter(l => {
            if (!l) return false;
            const lower = l.toLowerCase();
            if (lower === 'references' || lower === 'bibliography' || lower === 'reference list' || lower === 'sources') return false;
            return true;
          });
          refLines.forEach(line => {
            const cleanKey = line.replace(/^\[?\d+\]?\.?\s*/, '').toLowerCase().trim();
            if (cleanKey && !uniqueRefLines.has(cleanKey)) {
              uniqueRefLines.set(cleanKey, line);
            }
          });
        }
      }
    }

    if (themesFound === 0) {
      alert("Please paste or generate Section 4: Theme Summary Results first.");
      return;
    }

    const compiledNarrative = "3.0. RESULTS\n\n" + themeNarratives.join("\n\n");
    const compiledReferences = Array.from(uniqueRefLines.values()).join("\n\n");

    const compiledBox = document.getElementById('compiledResultsNarrative');
    if (compiledBox) {
      compiledBox.innerText = compiledNarrative;
      compiledBox.dispatchEvent(new Event('input', { bubbles: true }));
    }

    const refsBox = document.getElementById('compiledResultsReferences');
    if (refsBox) {
      refsBox.innerText = compiledReferences;
      window.syncAndArrangeReferences('compiledResultsReferences');
    }

    if (typeof window.syncPaperDraft === 'function') {
      window.syncPaperDraft(true);
    }
  };

   window.openTab = function(evt: any, tabName: string) {
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    document.querySelectorAll('.tab-link').forEach(l => l.classList.remove('active'));
    const target = document.getElementById(tabName);
    if (target) target.classList.add('active');
    
    if (evt && evt.currentTarget) {
      evt.currentTarget.classList.add('active');
    } else {
      // Match tab link by index for common cases or just find the one that corresponds to tabName
      const links = document.querySelectorAll('.tab-link');
      if (tabName === 'home' && links[0]) links[0].classList.add('active');
      else if (tabName === 'assistant' && links[1]) links[1].classList.add('active');
      else if (tabName === 'methods' && links[2]) links[2].classList.add('active');
      else if (tabName === 'figure' && links[3]) links[3].classList.add('active');
    }

    window.syncAll();
    if (tabName === 'figure') window.updatePrismaFigure();
  };

  window.syncAll = function() {
    const titleVal = (document.getElementById('globalTitle') as HTMLInputElement)?.value || "Environmental Sustainability in Smart Cities";
    const box = document.getElementById('introPromptText');
    if (box) {
      box.innerText = `I am an academician, I am writing a high-impact article with the title “ ${titleVal} “. 

1.List the most probable explicit research questions. Make sure there is a space after the list separating from the next text.

2.List the most probable targeted review objectives. Make sure there is a space after the list separating from the next text.

3.Write a comprehensive introduction. Give into 3 paragraph and limit words to 800-1000 ONLY. Each paragraph must have at least THREE (3) references related to it. Please combine. Do not add subtitles for each paragraph. Please Include reference author name also in text. Introduce spacing to separate the introduction from the list of references. The list of references must be at the last paragraph only in APA style.`;
    }
  };

  window.loadCSV = function(db: string) {
    const file = (document.getElementById(db + 'File') as HTMLInputElement).files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const lines = e.target.result.split('\n');
      const headers = lines[0].toLowerCase().split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/).map((h: string) => h.replace(/"/g, '').trim());
      window.rawData[db] = lines.slice(1).map(line => {
        const values = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
        let obj: any = {};
        headers.forEach((h: string, i: number) => {
          let val = values[i] ? values[i].replace(/"/g, '').trim() : "";
          obj[h] = val;
          if (h === 'article title' || h === 'title') obj['title'] = val;
          if (h === 'publication year' || h === 'year') obj['year'] = val;
          if (h === 'document type') obj['document type'] = val;
          if (h === 'abstract' || h === 'abs') obj['abstract'] = val;
          if (h === 'author keywords' || h === 'keywords' || h === 'index keywords' || h === 'author_keywords' || h === 'key words') obj['keywords'] = (obj['keywords'] || "") + " " + val;
          if (h === 'authors' || h === 'author' || h === 'au') obj['authors'] = val;
        });
        return obj;
      }).filter(r => Object.keys(r).length > 2);
      const countEl = document.getElementById(db + 'Count');
      if (countEl) countEl.innerText = window.rawData[db].length;
      window.totalInitial = Object.keys(window.rawData).reduce((sum, key) => sum + (window.rawData[key]?.length || 0), 0);
      const identEl = document.getElementById('flowIdentified');
      if (identEl) identEl.innerText = window.totalInitial.toString();
    };
    reader.readAsText(file);
  };

  window.runScreening = function() {
    const startY = parseInt((document.getElementById('startYear') as HTMLInputElement).value) || 0;
    const endY = parseInt((document.getElementById('endYear') as HTMLInputElement).value) || 2025;
    const incEnglish = (document.getElementById('incEnglish') as HTMLInputElement)?.checked || false;
    const exBooks = (document.getElementById('exBooks') as HTMLInputElement)?.checked || false;
    const exConf = (document.getElementById('exConf') as HTMLInputElement)?.checked || false;
    const exReview = (document.getElementById('exReview') as HTMLInputElement)?.checked || false;
    const exEditorial = (document.getElementById('exEditorial') as HTMLInputElement)?.checked || false;
    const incRCT = (document.getElementById('incRCT') as HTMLInputElement)?.checked || false;

    window.temporaryFilteredLists = { wos: [], scopus: [], ncbi: [], scholar: [], cochrane: [], embase: [], ieee: [], cinahl: [], psycinfo: [], eric: [], sciencedirect: [], wiley: [] };
    window.globalExCounts = { year: 0, lang: 0, docType: 0, rct: 0, keyword: 0, dup: 0 };

    Object.keys(window.rawData).forEach(db => {
      if (!window.rawData[db]) return;
      window.rawData[db].forEach((rec: any) => {
        const year = parseInt(rec['year'] || 0);
        const docType = (rec['document type'] || "").toLowerCase();
        
        if (year < startY || year > endY) { window.globalExCounts.year++; return; }
        if (exBooks && (docType.includes('book') || docType.includes('chapter'))) { window.globalExCounts.docType++; return; }
        if (exConf && docType.includes('conference')) { window.globalExCounts.docType++; return; }
        if (exReview && docType.includes('review')) { window.globalExCounts.docType++; return; }
        if (exEditorial && (docType.includes('editorial') || docType.includes('letter'))) { window.globalExCounts.docType++; return; }
        
        if (!window.temporaryFilteredLists[db]) {
          window.temporaryFilteredLists[db] = [];
        }
        window.temporaryFilteredLists[db].push(rec);
      });
    });

    Object.keys(window.temporaryFilteredLists).forEach(db => {
      const dbId = 'res' + db.charAt(0).toUpperCase() + db.slice(1);
      const resEl = document.getElementById(dbId) as HTMLElement;
      if (resEl) {
        resEl.innerText = window.temporaryFilteredLists[db].length.toString();
      }
    });
    (document.getElementById('screeningStats') as HTMLElement).style.display = 'grid';
    (document.getElementById('deduplicationSection') as HTMLElement).style.display = 'block';
  };

  window.autoRunFilters = function() {
    (document.getElementById('startYear') as HTMLInputElement).value = "2015";
    (document.getElementById('exBooks') as HTMLInputElement).checked = true;
    (document.getElementById('exConf') as HTMLInputElement).checked = true;
    (document.getElementById('exReview') as HTMLInputElement).checked = true;
    window.runScreening();
    alert("Filters auto-optimized to recent years and standard exclusions applied.");
  };

  window.combineAndDeduplicate = function() {
    const seen = new Set();
    window.filteredList = [];
    let dups = 0;
    let aiExCount = 0;
    const { designs, populations, interventions, outcomes, geo, kw } = window.aiExclusions;

    // Define expanded standard categories for thorough detection
    const allDesigns = [
      "Randomized Controlled Trial", "RCT", "Case Study", "Systematic Review", "Meta-Analysis", 
      "Cohort Study", "Survey", "Questionnaire", "Qualitative", "Quantitative", 
      "Experimental", "Cross-sectional", "Longitudinal", "Exploratory", "Descriptive",
      "Correlational", "Quasi-experimental", "Phenomenological", "Grounded Theory",
      "Pilot Study", "Feasibility Study", "Cohort Analysis", "Case-control", 
      "Observational", "Literature Review", "Action Research", "Interviews", 
      "Focus Groups", "Ethnography", "Scoping Review", "Narrative Review", 
      "Delphi Study", "Expert Opinion", "Clinical Trial", "Pre-test Post-test", 
      "Controlled Before-and-After", "Ecological Study", "Cross-over Trial", 
      "Series of Cases", "Report of Cases", "Perspective", "Commentary", "Editorial",
      "Retrospective", "Prospective", "In vitro", "In vivo", "Animal Study", 
      "Modelling", "Simulation", "Technical Report", "White Paper", "Guidelines", "Standards"
    ];
    const allPops = [
      "Adults", "Pediatric", "Elderly", "Patients", "Students", "Professionals", 
      "General Population", "Children", "Adolescents", "Consumers", "Citizens", 
      "Policy Makers", "Employees", "Stakeholders", "Undergraduates", "Graduates",
      "Teachers", "Clinicians", "Nurses", "Women", "Men", "Marginalized",
      "Rural", "Urban", "Infants", "Toddlers", "Refugees", "Migrants",
      "Caregivers", "Healthcare Workers", "Doctors", "Physicians", "Pharmacists",
      "Veterans", "Ethnic Minorities", "Indigenous", "Low-income", "Disabled",
      "Control group", "Placebo", "Comparison group", "Trial participants", "Volunteers"
    ];
    const allInts = [
      "Digital Technology", "Smart City", "Smart Tech", "Internet of Things", "IoT", 
      "Artificial Intelligence", "AI", "Machine Learning", "Blockchain", 
      "Clinical Intervention", "Medical", "Surgery", "Therapy", "Vaccination",
      "Policy Intervention", "Governance", "Educational Program", "Curriculum",
      "Environmental Policy", "Sustainable Development", "Renewable Energy", 
      "Mobility", "Infrastructure", "Algorithm", "Software", "Framework",
      "Telehealth", "Telemedicine", "mHealth", "Mobile App", "Wearable",
      "Remote Monitoring", "Decision Support System", "EHR", "Electronic Health Record",
      "Robotics", "Automation", "Virtual Reality", "VR", "Augmented Reality", "AR"
    ];
    const allOuts = [
      "Health/Well-being", "Financial/Cost", "Policy Impact", "User Acceptance", 
      "Sustainability", "System Performance", "Efficiency", "Reliability", 
      "Safety", "Quality of Life", "Economic Growth", "Environmental Impact",
      "Effectiveness", "Engagement", "Behavioral Change", "Satisfaction",
      "Accuracy", "Energy Consumption", "CO2 Emission", "Productivity"
    ];
    const allGeos = [
      "Global South", "Europe", "North America", "Asia", "Africa", "South America", 
      "Developing Nations", "China", "USA", "India", "Middle East", "Southeast Asia",
      "Latin America", "United Kingdom", "Canada", "Australia", "OECD", "BRICS",
      "Pacific", "Mediterranean", "Sub-Saharan Africa", "Nordic", "Scandinavian"
    ];

    Object.keys(window.temporaryFilteredLists).forEach(db => {
      window.temporaryFilteredLists[db].forEach((rec: any) => {
        const title = (rec['title'] || "").toLowerCase().trim();
        const text = ((rec.title || "") + " " + (rec.abstract || "") + " " + (rec.keywords || "")).toLowerCase();
        
        const checkMatch = (str: string, cat: string) => {
          if (cat.length <= 3) {
            const upCat = cat.toUpperCase();
            // Use word boundary for short abbreviations
            const regex = new RegExp(`\\b${cat.toLowerCase()}\\b`, 'i');
            return regex.test(str);
          }
          return str.includes(cat.toLowerCase());
        };

        // Detect categories for this specific item
        const itemCategories: string[] = [];
        allDesigns.forEach(d => { if (checkMatch(text, d)) itemCategories.push(d); });
        allPops.forEach(p => { if (checkMatch(text, p)) itemCategories.push(p); });
        allInts.forEach(i => { if (checkMatch(text, i)) itemCategories.push(i); });
        allOuts.forEach(o => { if (checkMatch(text, o)) itemCategories.push(o); });
        allGeos.forEach(g => { if (checkMatch(text, g)) itemCategories.push(g); });

        let isAiExcluded = false;
        designs.forEach(d => { if (checkMatch(text, d)) isAiExcluded = true; });
        populations.forEach(p => { if (checkMatch(text, p)) isAiExcluded = true; });
        interventions.forEach(i => { if (checkMatch(text, i)) isAiExcluded = true; });
        outcomes.forEach(o => { if (checkMatch(text, o)) isAiExcluded = true; });
        geo.forEach(g => { if (checkMatch(text, g)) isAiExcluded = true; });
        kw.forEach(k => { if (checkMatch(text, k)) isAiExcluded = true; });

        const cleanTitle = cleanStringForMatch(rec['title'] || "");

        if (isAiExcluded) {
          aiExCount++;
          return;
        }

        if (cleanTitle && seen.has(cleanTitle)) {
          dups++;
        } else if (cleanTitle) {
          seen.add(cleanTitle);
          window.filteredList.push({ data: rec, active: true, finalActive: true, manualDesign: null, aiCategories: itemCategories });
        }
      });
    });
    window.globalExCounts.dup = dups;
    window.globalExCounts.aiEx = aiExCount;

    (document.getElementById('resTotal') as HTMLElement).innerText = window.filteredList.length.toString();
    (document.getElementById('dupCount') as HTMLElement).innerText = dups.toString();
    
    const aiStat = document.getElementById('aiExCountDisplay');
    if (aiStat) {
      aiStat.innerText = aiExCount.toString();
      (document.getElementById('aiExStatBox') as HTMLElement).style.display = aiExCount > 0 ? 'block' : 'none';
    }

    window.renderReferenceLists();
    window.updateFinalCounts();
  };

  window.toggleManualInclusion = function(index: number) {
    if (window.filteredList[index]) {
      window.filteredList[index].active = !window.filteredList[index].active;
      window.renderReferenceLists();
      window.updateFinalCounts();
    }
  };

  window.saveFinalActiveHistoryState = function() {
    if (!window.filteredList) return;
    const currentState = window.filteredList.map(f => !!f.finalActive);
    
    if (window.finalActiveHistoryIndex < window.finalActiveHistory.length - 1) {
      window.finalActiveHistory = window.finalActiveHistory.slice(0, window.finalActiveHistoryIndex + 1);
    }
    
    window.finalActiveHistory.push(currentState);
    window.finalActiveHistoryIndex = window.finalActiveHistory.length - 1;
  };

  window.undoFinalActive = function() {
    if (window.finalActiveHistory.length === 0 || window.finalActiveHistoryIndex <= 0) {
      alert("Nothing to undo!");
      return;
    }
    window.finalActiveHistoryIndex--;
    const prevState = window.finalActiveHistory[window.finalActiveHistoryIndex];
    prevState.forEach((val, idx) => {
      if (window.filteredList[idx]) {
        window.filteredList[idx].finalActive = val;
      }
    });
    window.renderFinalReferencePool();
    window.updateFinalCounts();
    window.updatePrismaFigure();
    
    const container = document.getElementById('manualSelectionTableContainer');
    if (container && container.style.display !== 'none') {
      (window as any).syncManualPaste();
    }
  };

  window.redoFinalActive = function() {
    if (window.finalActiveHistory.length === 0 || window.finalActiveHistoryIndex >= window.finalActiveHistory.length - 1) {
      alert("Nothing to redo!");
      return;
    }
    window.finalActiveHistoryIndex++;
    const nextState = window.finalActiveHistory[window.finalActiveHistoryIndex];
    nextState.forEach((val, idx) => {
      if (window.filteredList[idx]) {
        window.filteredList[idx].finalActive = val;
      }
    });
    window.renderFinalReferencePool();
    window.updateFinalCounts();
    window.updatePrismaFigure();
    
    const container = document.getElementById('manualSelectionTableContainer');
    if (container && container.style.display !== 'none') {
      (window as any).syncManualPaste();
    }
  };

  window.toggleFinalInclusion = function(index: number) {
    if (window.filteredList[index]) {
      if (window.finalActiveHistory.length === 0) {
        const initialState = window.filteredList.map(f => !!f.finalActive);
        window.finalActiveHistory.push(initialState);
        window.finalActiveHistoryIndex = 0;
      }
      
      window.filteredList[index].finalActive = !window.filteredList[index].finalActive;
      window.saveFinalActiveHistoryState();
      window.renderFinalReferencePool();
      window.updateFinalCounts();
    }
  };

  window.renderFinalReferencePool = function() {
    const listDiv = document.getElementById('finalRefsList');
    if (!listDiv) return;
    listDiv.innerHTML = '';
    
    const items = window.filteredList.filter(f => f.active && f.finalActive);
    if (items.length === 0) {
      listDiv.innerHTML = '<div class="p-8 text-center text-slate-400 italic">No references finalized.</div>';
      return;
    }

    const table = document.createElement('table');
    table.className = 'w-full text-xs text-left border-collapse';
    table.innerHTML = `
      <thead>
        <tr class="bg-slate-50 text-slate-500 uppercase font-bold border-b border-slate-200">
          <th class="p-3 border-r border-slate-200 w-10">Sel</th>
          <th class="p-3 border-r border-slate-200 w-12">ID</th>
          <th class="p-3 border-r border-slate-200">Reference Details</th>
          <th class="p-3 border-r border-slate-200 w-1/4">Study Design</th>
          <th class="p-3 w-1/3">Key Findings</th>
        </tr>
      </thead>
      <tbody></tbody>
    `;
    const tbody = table.querySelector('tbody')!;

    items.forEach((item) => {
      const globalIndex = window.filteredList.indexOf(item);
      const tr = document.createElement('tr');
      tr.className = `border-b border-slate-100 hover:bg-slate-50`;
      
      const detectedDesigns = item.aiCategories && item.aiCategories.length > 0 
        ? item.aiCategories.filter((c: string) => 
            ["Randomized", "RCT", "Case Study", "Review", "Meta-Analysis", "Cohort", "Survey", "Qualitative", "Quantitative", "Experimental", "Cross-sectional", "Longitudinal", "Cohort Analysis", "Observational"].some(keyword => c.includes(keyword))
          ).join(', ')
        : '';
        
      const displayDesign = item.manualDesign || detectedDesigns || '—';
      const displayFindings = item.manualFindings || (item.data.abstract ? '(Abstract Available - Run Manual Selection for Synthesis)' : '—');

      tr.innerHTML = `
        <td class="p-3 text-center border-r border-slate-100">
           <input type="checkbox" class="w-4 h-4 cursor-pointer" ${item.finalActive ? 'checked' : ''} onchange="window.toggleFinalInclusion(${globalIndex})" />
        </td>
        <td class="p-3 text-slate-400 font-mono border-r border-slate-100">${globalIndex + 1}</td>
        <td class="p-3 border-r border-slate-100">
          <div class="font-bold text-slate-700 leading-tight">${item.data.title}</div>
          <div class="text-[10px] text-slate-400 mt-1">${item.data.authors || 'N/A'} (${item.data.year || 'N/A'})</div>
        </td>
        <td class="p-3 border-r border-slate-100 italic text-blue-600 font-medium">${displayDesign}</td>
        <td class="p-3 text-slate-500 leading-relaxed">${displayFindings}</td>
      `;
      tbody.appendChild(tr);
    });
    listDiv.appendChild(table);
  };

  window.renderManualSelectionTable = function(indices: number[]) {
    const container = document.getElementById('manualSelectionTableContainer');
    if (!container) return;
    container.innerHTML = '';
    container.style.display = 'none'; // Always keep hidden as requested

    const table = document.createElement('table');
    table.className = 'w-full text-xs text-left border-collapse';
    table.innerHTML = `
      <thead>
        <tr class="bg-slate-50 text-slate-500 uppercase font-bold border-b border-slate-200">
          <th class="p-3 border-r border-slate-200 w-12">ID</th>
          <th class="p-3 border-r border-slate-200 w-10">Inc</th>
          <th class="p-3 border-r border-slate-200">Reference Details</th>
          <th class="p-3 border-r border-slate-200 w-1/4">Study Design</th>
          <th class="p-3 w-1/4">Key Findings</th>
        </tr>
      </thead>
      <tbody></tbody>
    `;
    const tbody = table.querySelector('tbody')!;

    indices.forEach(idx => {
      const item = window.filteredList[idx];
      if (!item) return;
      const tr = document.createElement('tr');
      tr.className = `border-b border-slate-100 hover:bg-slate-50 ${!item.finalActive ? 'bg-red-50/50' : ''}`;
      
      const displayDesign = item.manualDesign || '—';
      const displayFindings = item.manualFindings || '—';

      tr.innerHTML = `
        <td class="p-3 text-slate-400 font-mono border-r border-slate-100">${idx + 1}</td>
        <td class="p-3 text-center border-r border-slate-100">
           <input type="checkbox" class="w-4 h-4 cursor-pointer" ${item.finalActive ? 'checked' : ''} onchange="window.toggleFinalInclusionFromSelection(${idx})" />
        </td>
        <td class="p-3 border-r border-slate-100">
          <div class="font-bold text-slate-700 leading-tight">${item.data.title}</div>
          <div class="text-[10px] text-slate-400 mt-1">${item.data.authors || 'N/A'} (${item.data.year || 'N/A'})</div>
        </td>
        <td class="p-3 italic text-blue-600 font-medium border-r border-slate-100">${displayDesign}</td>
        <td class="p-3 text-slate-500 line-clamp-2" title="${displayFindings}">${displayFindings}</td>
      `;
      tbody.appendChild(tr);
    });
    container.appendChild(table);
  };

  window.toggleFinalInclusionFromSelection = function(index: number) {
    if (window.filteredList[index]) {
      if (window.finalActiveHistory.length === 0) {
        const initialState = window.filteredList.map(f => !!f.finalActive);
        window.finalActiveHistory.push(initialState);
        window.finalActiveHistoryIndex = 0;
      }
      
      window.filteredList[index].finalActive = !window.filteredList[index].finalActive;
      window.saveFinalActiveHistoryState();
      (window as any).syncManualPaste();
      window.updateFinalCounts();
    }
  };

  window.syncManualPaste = function() {
    const tableArea = document.getElementById('manualTablePaste');
    if (!tableArea) return;
    
    // To ensure innerText works correctly even when the element is hidden (display: 'none'),
    // we temporarily show it, read innerText, and restore its display state.
    const originalDisplay = tableArea.style.display;
    if (originalDisplay === 'none') {
      tableArea.style.display = 'block';
    }
    const text = tableArea.innerText || tableArea.textContent || "";
    if (originalDisplay === 'none') {
      tableArea.style.display = 'none';
    }
    
    // Split into lines and filter out empty ones/formatting lines
    const lines = text.split(/\r?\n/).filter(l => l.trim() !== '' && !l.includes('---'));
    const filtered = window.filteredList; 
    
    const foundIndices: number[] = [];
    lines.forEach(line => {
      // Split by pipe or tab
      const separator = line.includes('|') ? '|' : '\t';
      const parts = line.split(separator).map(p => p.trim()).filter(p => p !== '');
      
      if (parts.length >= 2) {
        // Extract numeric ID only
        const idStr = parts[0].replace(/\D/g, '');
        if (idStr === '') return; // Skip headers or non-data lines
        
        const idx = parseInt(idStr) - 1;
        if (!isNaN(idx) && filtered[idx]) {
          if (!foundIndices.includes(idx)) foundIndices.push(idx);
          
          filtered[idx].finalActive = true; // Automatically mark parsed references as finalActive/included
          
          if (parts.length === 3) {
            const isProbablyRef = /\d{4}/.test(parts[1]) || parts[1].toLowerCase().includes('et al') || parts[1].length > 15;
            if (isProbablyRef) {
              filtered[idx].manualDesign = parts[2];
              filtered[idx].manualFindings = '';
            } else {
              filtered[idx].manualDesign = parts[1];
              filtered[idx].manualFindings = parts[2];
            }
          } else if (parts.length >= 4) {
            filtered[idx].manualDesign = parts[2];
            filtered[idx].manualFindings = parts[3];
          }
        }
      }
    });

    if (foundIndices.length > 0) {
      (window as any).renderManualSelectionTable(foundIndices);
    } else if (text.trim().length > 0) {
      const container = document.getElementById('manualSelectionTableContainer');
      if (container) {
        container.innerHTML = '<div class="p-4 text-center text-red-500 text-xs bg-red-50 rounded border border-red-100">No valid data rows detected. Please ensure the first column contains the numeric ID (e.g. | 1 | ...) mirroring the list provided in the prompt.</div>';
        container.style.display = 'block';
      }
    }

    // Still render the pool (even if hidden) to keep state consistent
    window.renderFinalReferencePool(); 
    window.updateFinalCounts();
  };

  window.parseManualTable = function() {
    const container = document.getElementById('manualSelectionTableContainer');
    const btn = document.querySelector('button[onClick*="parseManualTable"]') as HTMLButtonElement;

    // Run syncManualPaste on every parse click to make sure the latest data from the box is captured
    (window as any).syncManualPaste();

    const finalSec = document.getElementById('finalRefsSection');
    if (finalSec) {
      finalSec.style.display = 'block';
    }
    
    if (container) container.style.display = 'none';
    
    window.finalActiveHistory = [];
    window.finalActiveHistoryIndex = -1;
    window.saveFinalActiveHistoryState();

    window.renderFinalReferencePool();
    window.updateFinalCounts();
    
    if (finalSec) {
      finalSec.scrollIntoView({ behavior: 'smooth' });
    }
    
    const count = window.filteredList.filter(f => f.active && f.finalActive).length;
    if (count === 0) {
      alert("No references are currently selected for inclusion. Use the check boxes inside '5. MANUAL SELECTION' below to include references.");
    }
  };

  window.resetManualSelectionTable = function() {
    window.filteredList.forEach(item => {
      item.manualDesign = null;
      item.manualFindings = null;
      item.finalActive = false; // Untick all selected references
    });

    const pasteArea = document.getElementById('manualTablePaste');
    if (pasteArea) {
      if (pasteArea.tagName === 'TEXTAREA') {
        (pasteArea as HTMLTextAreaElement).value = '';
      } else {
        (pasteArea as HTMLElement).innerText = '';
      }
      pasteArea.style.display = 'block'; // reset to visible for future manual pasting
    }

    const toggleBtn = document.getElementById('btnToggleGeminiResultInput');
    if (toggleBtn) {
      toggleBtn.style.display = 'none'; // hide toggle button by default
      toggleBtn.innerHTML = '👁️ Show';
    }

    const container = document.getElementById('manualSelectionTableContainer');
    if (container) {
      container.innerHTML = '';
      container.style.display = 'none';
    }

    const finalSec = document.getElementById('finalRefsSection');
    if (finalSec) {
      finalSec.style.display = 'none';
    }

    const outSec = document.getElementById('manualOutputSection');
    if (outSec) {
      outSec.style.display = 'none';
    }

    const finalRefsList = document.getElementById('finalRefsList');
    if (finalRefsList) {
      finalRefsList.innerHTML = '<div class="p-8 text-center text-slate-400 italic">No references finalized.</div>';
    }

    window.finalActiveHistory = [];
    window.finalActiveHistoryIndex = -1;
    window.saveFinalActiveHistoryState();

    window.renderFinalReferencePool();
    window.updateFinalCounts();
    window.updatePrismaFigure();
  };

  window.renderReferenceLists = function() {
    const refListUi = document.getElementById('filteredRefsList');
    if (refListUi) {
      refListUi.innerHTML = "";
      window.filteredList.forEach((item, idx) => {
        const d = item.data;
        const cats = (item as any).aiCategories || [];
        if (cats.length > 0) return; // Only list unidentified references

        const div = document.createElement('div');
        div.className = 'ref-check-item block';
        div.innerHTML = `
          <div class="flex gap-3">
            <input type="checkbox" ${item.active ? 'checked' : ''} onchange="window.toggleManualInclusion(${idx})" />
            <div>
              <div class="font-bold text-sm text-slate-800">${d.title}</div>
              <div class="text-[10px] text-slate-400">${d.authors || 'N/A'} (${d.year || 'N/A'})</div>
              ${cats.length > 0 ? `<div class="flex gap-1 mt-1 flex-wrap">${cats.map((c: string) => `<span class="px-1.5 py-0.5 bg-slate-100 text-slate-500 rounded-sm text-[8px] font-bold uppercase border border-slate-200">${c}</span>`).join('')}</div>` : ''}
            </div>
          </div>
        `;
        refListUi.appendChild(div);
      });
      const section = document.getElementById('filteredRefsSection');
      if (section) section.style.display = 'block';
    }
    const manualSec = document.getElementById('manualSelectionSection');
    if (manualSec) manualSec.style.display = 'block';
  };

  window.updateFinalCounts = function() {
    const nIdent = window.totalInitial;
    const nAfterScreen = window.filteredList.length;
    const manualIncl = window.filteredList.filter(f => f.active).length;
    const finalIncl = window.filteredList.filter(f => f.active && f.finalActive).length;
    
    const countEl = document.getElementById('resTotal');
    if (countEl) countEl.innerText = nAfterScreen.toString();
    
    const manualEl = document.getElementById('finalManualIncluded');
    if (manualEl) manualEl.innerText = finalIncl.toString();
    
    const finalEl = document.getElementById('finalManualExcluded');
    if (finalEl) finalEl.innerText = (manualIncl - finalIncl).toString();
    
    window.updatePrismaFigure();
    
    // Update Workflow Tab
    const flowIdent = document.getElementById('flowIdentified');
    const flowScreen = document.getElementById('flowScreened');
    const flowDedup = document.getElementById('flowDeduplicated');
    const flowFinal = document.getElementById('flowFinal');

    if (flowIdent) flowIdent.innerText = nIdent.toString();
    if (flowScreen) flowScreen.innerText = nAfterScreen.toString();
    if (flowDedup) flowDedup.innerText = manualIncl.toString();
    if (flowFinal) flowFinal.innerText = finalIncl.toString();
  };

  window.updatePrismaFigure = function() {
    const nIdent = window.totalInitial || 0;
    const nAfterScreen = window.filteredList.length || 0;
    const nManualIncl = window.filteredList.filter(f => f.active).length || 0;
    const nFinal = window.filteredList.filter(f => f.active && f.finalActive).length || 0;

    const nExScreen = (window.globalExCounts.year + window.globalExCounts.lang + window.globalExCounts.docType + window.globalExCounts.keyword + (window.globalExCounts.aiEx || 0)) || 0;
    const nDups = window.globalExCounts.dup || 0;
    const nManualEx = (nManualIncl - nFinal) || 0;

    const setHtml = (id: string, html: string) => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = html;
    };

    setHtml('fig-ident', `
        <div class="uppercase opacity-50 mb-1">Identification</div>
        <div class="font-bold">n = ${nIdent}</div>
        <div class="mt-1 text-slate-400">Total records from databases</div>
    `);

    setHtml('fig-screen', `
        <div class="uppercase opacity-50 mb-1">Screening</div>
        <div class="font-bold">n = ${nAfterScreen + nExScreen}</div>
        <div class="mt-1 text-slate-400">Records after duplicates removed</div>
    `);

    setHtml('fig-elig', `
        <div class="uppercase opacity-50 mb-1">Eligibility</div>
        <div class="font-bold">n = ${nManualIncl}</div>
        <div class="mt-1 text-slate-400">Full-text articles assessed</div>
    `);

    setHtml('fig-final', `
        <div class="uppercase opacity-50 mb-1">Included</div>
        <div class="font-bold">n = ${nFinal}</div>
        <div class="mt-1 font-normal">Studies included in review</div>
    `);

    setHtml('fig-ex-dup', `
        <div class="font-bold">Duplicate records removed</div>
        <div>n = ${nDups}</div>
    `);

    let activeExclusionsList = "";
    const activeDetails: string[] = [];
    
    // Check timeline bounds
    const startY = (document.getElementById('startYear') as HTMLInputElement)?.value;
    const endY = (document.getElementById('endYear') as HTMLInputElement)?.value;
    if (startY || endY) {
      activeDetails.push(`Timeline (${startY || '2010'}-${endY || '2024'})`);
    }
    
    // Check standard checkmarked exclusions
    const exBooks = (document.getElementById('exBooks') as HTMLInputElement)?.checked;
    const exConf = (document.getElementById('exConf') as HTMLInputElement)?.checked;
    const exReview = (document.getElementById('exReview') as HTMLInputElement)?.checked;
    const exEditorial = (document.getElementById('exEditorial') as HTMLInputElement)?.checked;
    const incEnglish = (document.getElementById('incEnglish') as HTMLInputElement)?.checked;
    const incRCT = (document.getElementById('incRCT') as HTMLInputElement)?.checked;
    
    const typesEx: string[] = [];
    if (exBooks) typesEx.push("Books");
    if (exConf) typesEx.push("Confs");
    if (exReview) typesEx.push("Reviews");
    if (exEditorial) typesEx.push("Editorials");
    if (typesEx.length > 0) {
      activeDetails.push(`Doc types: ${typesEx.join('/')}`);
    }
    if (incRCT) activeDetails.push("Non-RCTs");
    if (incEnglish) activeDetails.push("Non-English");

    // Also custom keywords from textboxes
    const kw1 = (document.getElementById('exKw1') as HTMLInputElement)?.value;
    const kw2 = (document.getElementById('exKw2') as HTMLInputElement)?.value;
    if (kw1) activeDetails.push(`Excluded: "${kw1}"`);
    if (kw2) activeDetails.push(`Excluded: "${kw2}"`);
    
    // Smart AI Category Exclusions
    const { designs, populations, interventions, outcomes, geo, kw } = window.aiExclusions || { designs: [], populations: [], interventions: [], outcomes: [], geo: [], kw: [] };
    const allAiEx = [...designs, ...populations, ...interventions, ...outcomes, ...geo, ...kw];
    if (allAiEx.length > 0) {
      activeDetails.push(`AI Categories: ${allAiEx.join(', ')}`);
    }
    
    const theme = (window as any).prismaTheme || 'gradient';
    
    let containerClass = "ex-details text-[12px] leading-snug mt-2.5 font-normal border-t pt-2 w-full text-left pr-1";
    let strongClass = "uppercase text-[10px] block mb-1 tracking-wider font-bold text-center";
    let listClass = "list-disc list-outside pl-1.5 space-y-1 font-normal";
    
    if (theme === 'grayscale') {
      containerClass += " text-slate-600 border-slate-200";
      strongClass += " text-slate-800";
    } else if (theme === 'bw') {
      containerClass += " text-black border-black/80";
      strongClass += " text-black";
    } else {
      // gradient / default theme
      containerClass += " text-red-700/85 border-red-100";
      strongClass += " text-red-800";
    }

    if (activeDetails.length > 0) {
      activeExclusionsList = `
        <div class="${containerClass}">
          <strong class="${strongClass}">Filtered Criteria:</strong>
          <ul class="${listClass} ml-3 text-[11px] leading-tight text-left">
            ${activeDetails.map(detail => `<li class="text-[11px] leading-tight text-left">${detail}</li>`).join("")}
          </ul>
        </div>
      `;
    } else {
      let noneTextClass = theme === 'grayscale' ? 'text-slate-500' : (theme === 'bw' ? 'text-black' : 'text-slate-500');
      let noneStrongClass = theme === 'grayscale' ? 'text-slate-600' : (theme === 'bw' ? 'text-black' : 'text-slate-600');
      let noneBorderClass = theme === 'grayscale' ? 'border-slate-200' : (theme === 'bw' ? 'border-black/50' : 'border-red-100');
      
      activeExclusionsList = `
        <div class="ex-details text-[11px] leading-snug ${noneTextClass} mt-3 font-normal border-t ${noneBorderClass} pt-2 w-full text-center">
          <strong class="uppercase text-[9px] block mb-0.5 ${noneStrongClass} tracking-wider">Filtered Criteria:</strong>
          None selected
        </div>
      `;
    }

    setHtml('fig-ex-screen', `
        <div class="font-bold">Records excluded</div>
        <div>n = ${nExScreen}</div>
        ${activeExclusionsList}
    `);

    setHtml('fig-ex-manual', `
        <div class="font-bold">Records excluded</div>
        <div>n = ${nManualEx}</div>
        <div class="font-normal leading-tight mt-1">Manual quality assessment</div>
    `);
  };

  window.aiExclusions = { designs: [], populations: [], interventions: [], outcomes: [], geo: [], kw: [] };

  (window as any).generateSmartExclusionLists = function() {
    const container = document.getElementById('exclusionContainer');
    if (container) container.style.display = 'block';
    
    // Scan ALL uploaded references from the Assistant tab
    const pool: any[] = [];
    Object.keys(window.rawData).forEach(key => {
      if (Array.isArray(window.rawData[key])) {
        pool.push(...window.rawData[key]);
      }
    });

    if (pool.length === 0) {
      alert("Please upload at least one CSV file in the 'Assistant' tab first.");
      return;
    }

    const designMap: Record<string, number> = {};
    const popMap: Record<string, number> = {};
    const intMap: Record<string, number> = {};
    const outMap: Record<string, number> = {};

    // Use the comprehensive lists from above (conceptually)
    const allDesigns = [
      "Randomized Controlled Trial", "RCT", "Case Study", "Systematic Review", "Meta-Analysis", 
      "Cohort Study", "Survey", "Questionnaire", "Qualitative", "Quantitative", 
      "Experimental", "Cross-sectional", "Longitudinal", "Exploratory", "Descriptive",
      "Correlational", "Quasi-experimental", "Phenomenological", "Grounded Theory",
      "Pilot Study", "Feasibility Study", "Cohort Analysis", "Case-control", 
      "Observational", "Literature Review", "Action Research", "Interviews", 
      "Focus Groups", "Ethnography", "Scoping Review", "Narrative Review", 
      "Delphi Study", "Expert Opinion", "Clinical Trial", "Pre-test Post-test", 
      "Controlled Before-and-After", "Ecological Study", "Cross-over Trial", 
      "Series of Cases", "Report of Cases", "Perspective", "Commentary", "Editorial",
      "Retrospective", "Prospective", "In vitro", "In vivo", "Animal Study", 
      "Modelling", "Simulation", "Technical Report", "White Paper", "Guidelines", "Standards"
    ];
    const allPops = [
      "Adults", "Pediatric", "Elderly", "Patients", "Students", "Professionals", 
      "General Population", "Children", "Adolescents", "Consumers", "Citizens", 
      "Policy Makers", "Employees", "Stakeholders", "Undergraduates", "Graduates",
      "Teachers", "Clinicians", "Nurses", "Women", "Men", "Marginalized",
      "Rural", "Urban", "Infants", "Toddlers", "Refugees", "Migrants",
      "Caregivers", "Healthcare Workers", "Doctors", "Physicians", "Pharmacists",
      "Veterans", "Ethnic Minorities", "Indigenous", "Low-income", "Disabled",
      "Control group", "Placebo", "Comparison group", "Trial participants", "Volunteers"
    ];
    const allInts = [
      "Digital Technology", "Smart City", "Smart Tech", "Internet of Things", "IoT", 
      "Artificial Intelligence", "AI", "Machine Learning", "Blockchain", 
      "Clinical Intervention", "Medical", "Surgery", "Therapy", "Vaccination",
      "Policy Intervention", "Governance", "Educational Program", "Curriculum",
      "Environmental Policy", "Sustainable Development", "Renewable Energy", 
      "Mobility", "Infrastructure", "Algorithm", "Software", "Framework",
      "Telehealth", "Telemedicine", "mHealth", "Mobile App", "Wearable",
      "Remote Monitoring", "Decision Support System", "EHR", "Electronic Health Record",
      "Robotics", "Automation", "Virtual Reality", "VR", "Augmented Reality", "AR"
    ];
    const allOuts = [
        "Health/Well-being", "Financial/Cost", "Policy Impact", "User Acceptance", 
        "Sustainability", "System Performance", "Efficiency", "Reliability", 
        "Safety", "Quality of Life", "Economic Growth", "Environmental Impact",
        "Effectiveness", "Engagement", "Behavioral Change", "Satisfaction",
        "Accuracy", "Energy Consumption", "CO2 Emission", "Productivity"
    ];

    allDesigns.forEach(d => designMap[d] = 0);
    allPops.forEach(p => popMap[p] = 0);
    allInts.forEach(i => intMap[i] = 0);
    allOuts.forEach(o => outMap[o] = 0);

    const geoMap: Record<string, number> = {
      "Global South": 0, "Europe": 0, "North America": 0, "Asia": 0, "Africa": 0, 
      "Developing Nations": 0, "China": 0, "USA": 0, "United Kingdom": 0, "Middle East": 0,
      "Australia": 0, "Latin America": 0, "Southeast Asia": 0
    };

    // Simple keyword extraction for the rest
    const words: Record<string, number> = {};
    const commonStopwords = new Set(["a", "an", "the", "and", "or", "but", "if", "then", "of", "in", "on", "with", "for", "to", "at", "by", "from", "up", "down", "is", "was", "were", "are", "be", "been", "being", "have", "has", "had", "do", "does", "did", "as", "about", "above", "below", "between", "under", "through", "during", "before", "after", "while", "until", "since", "each", "every", "all", "any", "some", "none", "only", "other", "such", "same", "so", "than", "too", "very", "can", "will", "just", "should", "could", "would", "may", "might", "must", "shall", "ought", "studies", "research", "study", "using", "based", "analysis", "results", "findings", "impact", "effect", "data", "review"]);

    pool.forEach(item => {
        // Raw items from CSV upload do not have .data wrapper yet
        const text = ((item.title || "") + " " + (item.abstract || "") + " " + (item.keywords || "")).toLowerCase();
        
        const checkMatch = (str: string, cat: string) => {
          if (cat.length <= 3) {
            const regex = new RegExp(`\\b${cat.toLowerCase()}\\b`, 'i');
            return regex.test(str);
          }
          return str.includes(cat.toLowerCase());
        };

        Object.keys(designMap).forEach(d => { if (checkMatch(text, d)) designMap[d]++; });
        Object.keys(popMap).forEach(d => { if (checkMatch(text, d)) popMap[d]++; });
        Object.keys(intMap).forEach(d => { if (checkMatch(text, d)) intMap[d]++; });
        Object.keys(outMap).forEach(d => { if (checkMatch(text, d)) outMap[d]++; });
        Object.keys(geoMap).forEach(g => { if (checkMatch(text, g)) geoMap[g]++; });

        // Match Keywords (top frequency)
        const tokens = text.split(/[\s,.\-\(\)]+/);
        tokens.forEach(t => {
            if (t.length > 5 && !commonStopwords.has(t)) {
                words[t] = (words[t] || 0) + 1;
            }
        });
    });

    const topKeywords = Object.entries(words)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 12);

    const renderGrid = (gridId: string, items: [string, number][], group: string, header: string) => {
        const grid = document.getElementById(gridId);
        if (!grid) return;

        // Save scroll position of the kw-grid if it exists
        const oldKwGrid = grid.querySelector('.kw-grid');
        const scrollPos = oldKwGrid ? oldKwGrid.scrollTop : 0;

        grid.innerHTML = `<div class="category-header">${header}</div><div class="kw-grid">` + 
            items.map(([item, count]) => {
                const isSelected = (window.aiExclusions as any)[group].includes(item);
                return `
                    <div class="kw-item cursor-pointer flex items-center hover:bg-slate-100 transition-colors" onclick="window.toggleAiExclusion('${group}', '${item}')">
                        <input type="checkbox" ${isSelected ? 'checked' : ''} style="accent-color: #ef4444;" class="mr-1 cursor-pointer" /> 
                        <span class="${isSelected ? 'text-red-700 font-bold' : 'text-slate-700'}">${item}</span>
                        <span class="text-[9px] text-slate-400 font-bold uppercase ml-1.5 whitespace-nowrap">MATCHES: ${count} REFS</span>
                    </div>
                `;
            }).join('') + '</div>';

        // Restore scroll position
        if (scrollPos > 0) {
            const newKwGrid = grid.querySelector('.kw-grid');
            if (newKwGrid) {
                newKwGrid.scrollTop = scrollPos;
                // Double guarantee: keep scroll position fixed in standard layout ticks
                setTimeout(() => {
                    const el = grid.querySelector('.kw-grid');
                    if (el) el.scrollTop = scrollPos;
                }, 0);
                setTimeout(() => {
                    const el = grid.querySelector('.kw-grid');
                    if (el) el.scrollTop = scrollPos;
                }, 20);
                setTimeout(() => {
                    const el = grid.querySelector('.kw-grid');
                    if (el) el.scrollTop = scrollPos;
                }, 50);
            }
        }
    };

    renderGrid('designExGrid', Object.entries(designMap).filter(e => e[1] > 0), 'designs', 'Study Design / Type');
    renderGrid('popExGrid', Object.entries(popMap).filter(e => e[1] > 0), 'populations', 'Populations');
    renderGrid('intExGrid', Object.entries(intMap).filter(e => e[1] > 0), 'interventions', 'Interventions');
    renderGrid('outExGrid', Object.entries(outMap).filter(e => e[1] > 0), 'outcomes', 'Outcomes');
    renderGrid('geoExGrid', Object.entries(geoMap).filter(e => e[1] > 0), 'geo', 'Regions');
    renderGrid('kwExGrid', topKeywords, 'kw', 'Recurring Keywords');

    // Populate Suggested Categories Text Area dynamically
    const sugContainer = document.getElementById('suggestedCategoriesContainer');
    const sugTextarea = document.getElementById('suggestedCategoriesTextArea') as HTMLTextAreaElement;
    if (sugContainer && sugTextarea) {
      sugContainer.style.display = 'none';

      const matchedCats: string[] = [];
      const detailedLines: string[] = [];

      const designMatched = Object.entries(designMap).filter(e => e[1] > 0);
      if (designMatched.length > 0) {
        matchedCats.push(...designMatched.map(e => e[0]));
        detailedLines.push(`• Study Design / Type: ${designMatched.map(e => `${e[0]} (n = ${e[1]} matches)`).join(', ')}`);
      }

      const popMatched = Object.entries(popMap).filter(e => e[1] > 0);
      if (popMatched.length > 0) {
        matchedCats.push(...popMatched.map(e => e[0]));
        detailedLines.push(`• Populations: ${popMatched.map(e => `${e[0]} (n = ${e[1]} matches)`).join(', ')}`);
      }

      const intMatched = Object.entries(intMap).filter(e => e[1] > 0);
      if (intMatched.length > 0) {
        matchedCats.push(...intMatched.map(e => e[0]));
        detailedLines.push(`• Interventions: ${intMatched.map(e => `${e[0]} (n = ${e[1]} matches)`).join(', ')}`);
      }

      const outMatched = Object.entries(outMap).filter(e => e[1] > 0);
      if (outMatched.length > 0) {
        matchedCats.push(...outMatched.map(e => e[0]));
        detailedLines.push(`• Outcomes: ${outMatched.map(e => `${e[0]} (n = ${e[1]} matches)`).join(', ')}`);
      }

      const geoMatched = Object.entries(geoMap).filter(e => e[1] > 0);
      if (geoMatched.length > 0) {
        matchedCats.push(...geoMatched.map(e => e[0]));
        detailedLines.push(`• Regions: ${geoMatched.map(e => `${e[0]} (n = ${e[1]} matches)`).join(', ')}`);
      }

      const kwMatched = topKeywords.filter(e => e[1] > 0);
      if (kwMatched.length > 0) {
        matchedCats.push(...kwMatched.map(e => e[0]));
        detailedLines.push(`• Recurring Keywords: ${kwMatched.map(e => `${e[0]} (n = ${e[1]} matches)`).join(', ')}`);
      }

      // Format dynamic categories list (Category 1, Category 2, etc.) with reference counts
      let listBlock = "";
      let catIdx = 1;

      const designCount = designMatched.reduce((acc, curr) => acc + curr[1], 0);
      const popCount = popMatched.reduce((acc, curr) => acc + curr[1], 0);
      const intCount = intMatched.reduce((acc, curr) => acc + curr[1], 0);
      const outCount = outMatched.reduce((acc, curr) => acc + curr[1], 0);
      const geoCount = geoMatched.reduce((acc, curr) => acc + curr[1], 0);
      const kwCount = kwMatched.reduce((acc, curr) => acc + curr[1], 0);
      const totalRefsCount = designCount + popCount + intCount + outCount + geoCount + kwCount;

      if (designMatched.length > 0) {
        listBlock += `Category ${catIdx} (Study design/type - ${designCount} refs):\n` + designMatched.map((e, idx) => `${idx + 1}. ${e[0]} (${e[1]} refs)`).join('\n') + `\n\n`;
        catIdx++;
      }
      if (popMatched.length > 0) {
        listBlock += `Category ${catIdx}: Populations (${popCount} refs):\n` + popMatched.map((e, idx) => `${idx + 1}. ${e[0]} (${e[1]} refs)`).join('\n') + `\n\n`;
        catIdx++;
      }
      if (intMatched.length > 0) {
        listBlock += `Category ${catIdx}: Interventions (${intCount} refs):\n` + intMatched.map((e, idx) => `${idx + 1}. ${e[0]} (${e[1]} refs)`).join('\n') + `\n\n`;
        catIdx++;
      }
      if (outMatched.length > 0) {
        listBlock += `Category ${catIdx}: Outcomes (${outCount} refs):\n` + outMatched.map((e, idx) => `${idx + 1}. ${e[0]} (${e[1]} refs)`).join('\n') + `\n\n`;
        catIdx++;
      }
      if (geoMatched.length > 0) {
        listBlock += `Category ${catIdx}: Regions / Geography (${geoCount} refs):\n` + geoMatched.map((e, idx) => `${idx + 1}. ${e[0]} (${e[1]} refs)`).join('\n') + `\n\n`;
        catIdx++;
      }
      if (kwMatched.length > 0) {
        listBlock += `Category ${catIdx}: Recurring Keywords (${kwCount} refs):\n` + kwMatched.map((e, idx) => `${idx + 1}. ${e[0]} (${e[1]} refs)`).join('\n') + `\n\n`;
        catIdx++;
      }

      const titleVal = (document.getElementById('globalTitle') as HTMLInputElement)?.value || "";
      const titleTextStr = titleVal ? `"${titleVal}"` : `"[Insert Review Title]"`;

      const fullPrompt = `I am an academician, and this is the title ${titleTextStr} of my systematic review. Which of the categories listed (${totalRefsCount} refs) below should be excluded and list out the reasons.

${listBlock.trim()}

etc

Reasons

Wrong population: N records
Wrong intervention/exposure: N records
Wrong outcome: N records
Wrong study design: N records
Insufficient data: N records
Full text unavailable: N records`;

      sugTextarea.value = fullPrompt;

      (window as any).suggestedExclusionsListRaw = fullPrompt;
      (window as any).suggestedExclusionsListDetailed = `Suggested Screening Exclusion Categories Report:\n\n` + detailedLines.join("\n");
    }
  };

  (window as any).copySuggestedExclusionsList = function() {
    const text = (window as any).suggestedExclusionsListRaw || "";
    if (text) {
      navigator.clipboard.writeText(text).then(() => {
        alert("Categories to Screen Prompt copied to clipboard!");
      });
    } else {
      alert("No suggested categories generated yet. Run the Smart Scan first.");
    }
  };

  (window as any).copySuggestedExclusionsWithCounts = function() {
    const text = (window as any).suggestedExclusionsListDetailed || "";
    if (text) {
      navigator.clipboard.writeText(text).then(() => {
        alert("Detailed suggested screening categories report copied to clipboard!");
      });
    } else {
      alert("No suggested categories generated yet. Run the Smart Scan first.");
    }
  };

  window.toggleAiExclusion = function(group: string, value: string) {
      const idx = window.aiExclusions[group].indexOf(value);
      if (idx > -1) {
          window.aiExclusions[group].splice(idx, 1);
      } else {
          window.aiExclusions[group].push(value);
      }
      
      // Save scroll positions
      const winScrollY = window.scrollY || document.documentElement.scrollTop;
      const docScrollTop = document.documentElement.scrollTop;
      const bodyScrollTop = document.body.scrollTop;
      const tabContent = document.getElementById('methods');
      const tabScrollTop = tabContent ? tabContent.scrollTop : 0;

      window.generateSmartExclusionLists(); // re-render

      // Dynamically run the filtration in real-time
      const dbDataReady = Object.values(window.temporaryFilteredLists).some(lst => Array.isArray(lst) && lst.length > 0);
      if (dbDataReady) {
          window.combineAndDeduplicate();
          window.updateFinalCounts();
          if (typeof window.updatePrismaFigure === 'function') {
              window.updatePrismaFigure();
          }
      }
      
      // Restore scroll positions
      if (tabContent) {
          tabContent.scrollTop = tabScrollTop;
      }
      window.scrollTo(window.scrollX, winScrollY);
      document.documentElement.scrollTop = docScrollTop;
      document.body.scrollTop = bodyScrollTop;
  };

  window.applyAiExclusions = function() {
      const dbDataReady = Object.values(window.temporaryFilteredLists).some(lst => Array.isArray(lst) && lst.length > 0);
      
      if (!dbDataReady) {
          alert("Please run 'Phase 1: Identification' first.");
          return;
      }

      window.combineAndDeduplicate();
      alert(`AI Category Filter submitted. Check Section 3 for updated results.`);
  };

  window.generateThemes = function() {
    const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
    const finalPool = window.filteredList.filter(f => f.active && f.finalActive);
    
    // Create a numbered list of article titles
    let articlesList = "";
    finalPool.forEach((f, i) => {
        articlesList += `${i + 1}. ${f.data.title}\n`;
    });

    const prompt = `Based on these article titles for the review "${title}". Act as an expert in writing a Systematic Literature Review (SLR). Below is the list of finalized journal article titles. Based on these titles, divide them into five distinct themes.

For each theme, use this EXACT format:

Theme 1 (Name): [Theme Name Here]
Theme 1 (Focus of analysis):[Focus Description Here]
Theme 1 (Article List):[Include the article numbering here, e.g., 1, 4, 7]

Theme 2 (Name): [Theme Name Here]
Theme 2 (Focus of analysis):[Focus Description Here]
Theme 2 (Article List):[Include the article numbering here, e.g., 1, 4, 7]

Theme 3 (Name): [Theme Name Here]
Theme 3 (Focus of analysis):[Focus Description Here]
Theme 3 (Article List):[Include the article numbering here, e.g., 1, 4, 7]

Theme 4 (Name): [Theme Name Here]
Theme 4 (Focus of analysis):[Focus Description Here]
Theme 4 (Article List):[Include the article numbering here, e.g., 1, 4, 7]

Theme 5 (Name): [Theme Name Here]
Theme 5 (Focus of analysis):[Focus Description Here]
Theme 5 (Article List):[Include the article numbering here, e.g., 1, 4, 7]

MANDATORY: Each article must appear in ONLY ONE theme. Every article listed below should be assigned to exactly one category without repetition.

List of finalized journal article titles: 
${articlesList}`;

    const box = document.getElementById('themeSuggestionPromptBox');
    if (box) {
        box.innerText = prompt;
        box.style.display = 'block';
    }
  };

  window.parseAndDistributeThemes = function() {
      const el = document.getElementById('geminiResultsInput');
      const input = el ? (el.tagName === 'TEXTAREA' ? (el as HTMLTextAreaElement).value : (el as HTMLElement).innerText) : "";
      const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
      const finalPool = window.filteredList.filter(f => f.active && f.finalActive);
      
      // Basic regex or string splitting to find names and IDs
      for (let i = 1; i <= 5; i++) {
          const nameRegex = new RegExp(`Theme ${i} \\(Name\\):\\s*(.*)`, 'i');
          const listRegex = new RegExp(`Theme ${i} \\(Article List\\):\\s*(.*)`, 'i');
          
          const nameMatch = input.match(nameRegex);
          const listMatch = input.match(listRegex);
          
          const themeName = nameMatch ? nameMatch[1].trim() : `Theme ${i}`;
          const idsString = listMatch ? listMatch[1].trim() : "";
          
          // Display theme name
          const nameEl = document.getElementById(`dispName${i}`);
          if (nameEl) nameEl.innerText = themeName;
          
          // Parse IDs and get data
          const ids = idsString.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));
          let dataText = "";
          
          ids.forEach(id => {
              const item = finalPool[id - 1];
              if (item) {
                  dataText += `REFERENCE ID ${id}:\nTITLE: ${item.data.title}\nAUTHORS: ${item.data.authors}\nYEAR: ${item.data.year}\nABSTRACT: ${item.data.abstract || 'N/A'}\nKEYWORDS: ${item.data.keywords || 'N/A'}\n\n`;
              }
          });
          
          // Generate the specific prompt for this theme
          const themePrompt = `Analyse the abstracts under the "${themeName}" theme for the paper "${title}". Summarize in a non point form based on findings and discussion. Avoid personal pronouns. Paraphrase for originality. complete the abstract, keywords or any of the information if N/A or missing. Cite properly using APA style and avoid using Reference ID XX. Make sure each reference there is one space before and after the references. Generates a numbering for active themes progressively as: 3.1. Theme 1: [Theme Title], 3.2. Theme 2: [Theme Title], etc. Extracts and maps subtopics underneath as sequentially numbered sub-topics: 3.1.1., 3.1.2., etc.

Data:
${dataText}`;
          
          const promptEl = document.getElementById(`themePrompt${i}`);
          if (promptEl) promptEl.innerText = themePrompt;
      }
      
      const resSec = document.getElementById('geminiResultsSection');
      if (resSec) resSec.style.display = 'block';
  };

  (window as any).copyThemePrompt = function(idx: number) {
      const el = document.getElementById(`themePrompt${idx}`);
      if (el) {
          navigator.clipboard.writeText(el.innerText).then(() => {
              alert(`Theme ${idx} prompt copied to clipboard!`);
          });
      }
  };

  window.generateThematicTable = function() {
    const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
    const active = window.filteredList.filter(f => f.active && f.finalActive);
    const data = active.map((f, i) => `${i+1} | ${f.data.authors || 'N/A'} | ${f.data.title} | ${f.manualDesign || 'Empirical'}`).join('\n');
    const prompt = `Review: ${title}\nGenerate a comprehensive thematic synthesis table for these ${active.length} articles using the structure: \nID | Reference | Key Findings | Methodological Quality | Theoretical Framework\n\n${data}`;
    
    const area = document.createElement('textarea');
    area.value = prompt;
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    document.body.removeChild(area);
    alert("Thematic Synthesis Table Prompt copied to clipboard!");
  };

  window.generateSeparatedThematicTables = function() {
    const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
    let masterPrompt = `I am writing a systematic review titled "${title}". I have categorized my studies into 5 themes. For EACH theme below, generate a separate thematic table summarizing the specific findings of the listed articles.\n\n`;
    
    [1,2,3,4,5].forEach(i => {
        const themeName = document.getElementById(`dispName${i}`)?.innerText || `Theme ${i}`;
        masterPrompt += `--- ${themeName} ---\n(List articles assigned to this theme here)\n\n`;
    });

    const area = document.createElement('textarea');
    area.value = masterPrompt;
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    document.body.removeChild(area);
    alert("Separated thematic table prompts copied to clipboard!");
  };

  window.genMasterDiscussion = function() {
    const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
    const commonInstructions = `DISCUSSION
Based on below data, please make a comprehensive discussion based on the results statement below. You can add facts and references from your own database. If more than one researcher discusses relatively the same issue, compile them together. Each paragraph must have at least THREE (3) references related to it. Please combine. Do not add subtitles for each paragraph. Please Include reference author name also in text. The list of references must be at the last paragraph only. for each reference please make sure there is one empty space before and after the reference. Please analyse all the contents of the documents thoroughly. Your article should avoid using the word 'I', 'you', 'we', 'they', 'us', and 'our'. To minimize the risk of detection by plagiarism software, paraphrase extensively to ensure no sentences share identical phrasing with the original sources. Aim for a factual to avoid overly dramatic language. Ideally, the writing style should resemble that of a non-English native. Your generated content must also pass the Artificial Intelligence detection test. Cite properly using APA style and avoid using Reference ID XX. Generates a numbering for active themes progressively as: 4.1. Theme 1: [Theme Title], 4.2. Theme 2: [Theme Title], etc.`;

    for (let i = 1; i <= 5; i++) {
        const box = document.getElementById(`themeSummary${i}`);
        const themeSummaryData = box ? (box.tagName === 'TEXTAREA' ? (box as HTMLTextAreaElement).value : (box as HTMLElement).innerText) : "";
        const promptEl = document.getElementById(`discThemePrompt${i}`);
        if (promptEl) {
            if (themeSummaryData.trim()) {
                promptEl.innerText = `${commonInstructions}\n\nData (Theme ${i}):\n${themeSummaryData}`;
                (promptEl.parentElement as HTMLElement).style.display = 'block';
            } else {
                promptEl.innerText = "";
                (promptEl.parentElement as HTMLElement).style.display = 'none';
            }
        }
    }

    const container = document.getElementById('discPromptContainer');
    if (container) container.style.display = 'block';
    const pasteSection = document.getElementById('discResultsPasteSection');
    if (pasteSection) pasteSection.style.display = 'block';
  };

  (window as any).copyDiscThemePrompt = function(idx: number) {
      const el = document.getElementById(`discThemePrompt${idx}`);
      if (el) {
          navigator.clipboard.writeText(el.innerText).then(() => {
              alert(`Theme ${idx} discussion prompt copied!`);
          });
      }
  };

  (window as any).genConclusionPrompt = function() {
    const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
    let dataText = "";
    for (let i = 1; i <= 5; i++) {
        const box = document.getElementById(`discThemeSummary${i}`);
        const sectionalDisc = box ? (box.tagName === 'TEXTAREA' ? (box as HTMLTextAreaElement).value : (box as HTMLElement).innerText) : "";
        if (sectionalDisc.trim()) {
            const themeName = document.getElementById(`dispName${i}`)?.innerText || `Theme ${i}`;
            dataText += `--- ${themeName} DISCUSSION ANALYSIS ---\n${sectionalDisc}\n\n`;
        }
    }

    if (!dataText.trim()) {
        alert("Please paste discussion results in Section 2 of the Discussion tab first.");
        return;
    }

    const prompt = `Based on below data, please make a comprehensive summary or conclusion. One paragraph with 100-200 words. Please remove all author, citation and references. Just make a general conclusion. avoid using the word ‘I’, ‘you’, ‘we', ‘they’, 'us', and "our’. To minimize the risk of detection by plagiarism software, paraphrase extensively to ensure no sentences share identical phrasing with the original sources. Aim for a factual to avoid overly dramatic language. Ideally, the writing style should resemble that of a non-English native. Your generated content must also pass the artificial intelligence detection test\n\nData:\n${dataText}`;

    const box = document.getElementById('conclusionPromptBox');
    if (box) {
        box.innerText = prompt;
        box.style.display = 'block';
    }
    const copyBtn = document.getElementById('copyConclusionBtn');
    if (copyBtn) copyBtn.style.display = 'inline-block';
  };

  (window as any).copyConclusionPrompt = function() {
      const el = document.getElementById(`conclusionPromptBox`);
      if (el) {
          navigator.clipboard.writeText(el.innerText).then(() => {
              alert(`Conclusion prompt copied!`);
          });
      }
  };

  window.showCitationMenu = function(x: number, y: number) {
    const menu = document.getElementById('citationContextMenu');
    if (!menu) return;
    menu.style.display = 'block';
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';
    
    // Remember the element that had focus
    const focusedEl = document.activeElement;

    const list = menu.querySelector('ul');
    if (list) {
        list.innerHTML = "";
        window.filteredList.filter(f => f.active && f.finalActive).forEach(f => {
            const li = document.createElement('li');
            li.innerText = `${f.data.authors || 'N/A'} (${f.data.year || 'N/A'})`;
            li.onclick = () => {
                const citation = `(${f.data.authors}, ${f.data.year})`;
                if (focusedEl) {
                    window.insertTextAtCursor(focusedEl as HTMLElement, citation);
                }
                window.hideCitationMenu();
            };
            list.appendChild(li);
        });
    }
  };

  window.hideCitationMenu = function() {
      const menu = document.getElementById('citationContextMenu');
      if (menu) menu.style.display = 'none';
  };

  window.insertTextAtCursor = function(el: HTMLElement, text: string) {
      if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
          const input = el as HTMLTextAreaElement;
          const start = input.selectionStart;
          const end = input.selectionEnd;
          input.value = input.value.substring(0, start) + text + input.value.substring(end);
          input.selectionStart = input.selectionEnd = start + text.length;
          input.focus();
      } else {
          // ContentEditable div
          el.focus();
          const selection = window.getSelection();
          if (selection && selection.rangeCount > 0) {
              const range = selection.getRangeAt(0);
              range.deleteContents();
              const textNode = document.createTextNode(text);
              range.insertNode(textNode);
              range.setStartAfter(textNode);
              range.setEndAfter(textNode);
              selection.removeAllRanges();
              selection.addRange(range);
          } else {
              el.innerText += text;
          }
          // Trigger input event manually for live sync
          el.dispatchEvent(new Event('input', { bubbles: true }));
      }
  };

  window.genSearchPrompt = function() {
    const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
    const promptText = `I am an academician conducting a systematic review titled: "${title}".\nProvide:\n1. 5 keywords.\n2. A separate Scopus search string (TITLE-ABS-KEY).\n3. A separate NCBI/PubMed string ([tiab]).\n4. A separate Web of Science (WoS) string.`;
    const box = document.getElementById('searchPromptBox');
    if (box) {
      box.innerText = promptText;
      box.style.display = 'block';
    }
  };

  window.addAuthorRow = function() {
      window.authorsData.push({ name: "", affilLink: "", isCorresponding: false, email: "" });
      window.renderAuthors();
  };

  (window as any).removeAuthorRow = function(idx: number) {
      if (window.authorsData.length > 1) {
          window.authorsData.splice(idx, 1);
          window.renderAuthors();
      }
  };

  window.renderAuthors = function() {
      const container = document.getElementById('authorsContainer');
      if (!container) return;
      container.innerHTML = "";
      window.authorsData.forEach((auth, idx) => {
          const div = document.createElement('div');
          div.className = 'border border-slate-100 p-4 rounded-lg bg-white space-y-3 mb-3 relative shadow-sm';
          
          // Generate affiliation selection UI
          let affilOptionsHtml = '<div class="flex flex-wrap gap-1 mt-1">';
          window.affiliationsData.forEach((_, affIdx) => {
              const num = affIdx + 1;
              const isSelected = auth.affilLink.split(',').map(s => s.trim()).includes(num.toString());
              affilOptionsHtml += `
                <button 
                  onclick="window.toggleAuthorAffil(${idx}, ${num})"
                  class="w-6 h-6 text-[10px] rounded border flex items-center justify-center transition-colors ${isSelected ? 'bg-blue-500 border-blue-500 text-white font-bold' : 'bg-white border-slate-200 text-slate-400 hover:border-blue-300'}"
                >
                  ${num}
                </button>
              `;
          });
          affilOptionsHtml += '</div>';

          div.innerHTML = `
              <div class="flex items-center gap-3">
                  <div class="w-8 h-8 flex items-center justify-center bg-slate-100 rounded-full text-xs font-bold text-slate-500 shrink-0 shadow-inner">
                    ${idx + 1}
                  </div>
                  <div class="flex-1">
                      <label class="block text-[9px] font-bold text-slate-400 uppercase tracking-tight mb-0.5">Author Name</label>
                      <input type="text" placeholder="First M. Surname" class="w-full text-xs px-2 h-9 border-slate-200" value="${auth.name}" oninput="window.authorsData[${idx}].name = this.value" />
                  </div>
                  <button class="bg-red-50 text-red-400 hover:bg-red-100 h-9 px-3 rounded shrink-0 transition-colors" onclick="window.removeAuthorRow(${idx})">✕</button>
              </div>
              
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pl-11">
                  <div>
                    <label class="block text-[9px] font-bold text-slate-400 uppercase tracking-tight mb-1">Affiliations</label>
                    ${affilOptionsHtml}
                  </div>
                  <div class="flex flex-col gap-2">
                      <label class="flex items-center gap-2 cursor-pointer w-fit mt-1">
                          <input type="checkbox" class="accent-blue-500 w-3 h-3" ${auth.isCorresponding ? 'checked' : ''} onchange="window.authorsData[${idx}].isCorresponding = this.checked; window.renderAuthors();" />
                          <span class="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Corresponding</span>
                      </label>
                      ${auth.isCorresponding ? `
                      <div class="space-y-1">
                        <label class="block text-[9px] font-bold text-blue-400 uppercase tracking-tight">Author Email</label>
                        <input type="email" placeholder="email@address.com" class="w-full text-xs bg-slate-50 border-slate-200 h-8 px-2" value="${auth.email || ''}" oninput="window.authorsData[${idx}].email = this.value" />
                      </div>
                      ` : ''}
                  </div>
              </div>
          `;
          container.appendChild(div);
      });
  };

  (window as any).toggleAuthorAffil = function(authorIdx: number, affilId: number) {
      const auth = window.authorsData[authorIdx];
      let current = auth.affilLink.split(',').map(s => s.trim()).filter(s => s);
      const idStr = affilId.toString();
      
      if (current.includes(idStr)) {
          current = current.filter(s => s !== idStr);
      } else {
          current.push(idStr);
          current.sort((a,b) => parseInt(a) - parseInt(b));
      }
      
      auth.affilLink = current.join(',');
      window.renderAuthors();
  };

  window.addAffiliationRow = function() {
      window.affiliationsData.push("");
      window.renderAffiliations();
      window.renderAuthors();
  };

  (window as any).removeAffiliationRow = function(idx: number) {
      if (window.affiliationsData.length > 1) {
          window.affiliationsData.splice(idx, 1);
          window.renderAffiliations();
          window.renderAuthors();
      }
  };

  window.renderAffiliations = function() {
      const container = document.getElementById('affilsContainer');
      if (!container) return;
      container.innerHTML = "";
      window.affiliationsData.forEach((aff, idx) => {
          const div = document.createElement('div');
          div.className = 'flex gap-2 mb-2 items-center bg-white p-2 border border-slate-50 rounded';
          div.innerHTML = `
              <div class="w-6 h-6 flex items-center justify-center bg-slate-50 rounded-full text-[10px] font-bold text-slate-400 shrink-0">
                  ${idx + 1}
              </div>
              <input type="text" placeholder="Dept, Institution, City, Country" class="flex-1 text-xs px-2 h-8" value="${aff}" oninput="window.affiliationsData[${idx}] = this.value" />
              <button class="bg-red-50 text-red-200 hover:bg-red-100 h-8 px-2 rounded shrink-0" onclick="window.removeAffiliationRow(${idx})">✕</button>
          `;
          container.appendChild(div);
      });
  };

  (window as any).generateAuthorAffiliations = function() {
      const outputBox = document.getElementById('draft-formatted-authors');
      if (!outputBox) return;

      const formattedAuthors = window.authorsData
          .filter(a => a.name.trim() !== "")
          .map((a, i, arr) => {
              const affils = a.affilLink ? a.affilLink.split(',').map(s => s.trim()).filter(s => s).join(',') : "";
              const marker = a.isCorresponding ? "*" : "";
              
              const supContent = `${affils}${affils && marker ? ',' : ''}${marker}`;
              const sup = supContent ? `<sup>${supContent}</sup>` : "";
              
              let joiner = "";
              if (i > 0) {
                  if (i === arr.length - 1) joiner = (arr.length > 2) ? ", and " : " and ";
                  else joiner = ", ";
              }
              
              return `${joiner}${a.name}${sup}`;
          })
          .join("");

      const formattedAffils = window.affiliationsData
          .filter(a => a.trim() !== "")
          .map((a, i) => `<sup>${i + 1}</sup> ${a}`)
          .join("<br>");

      let correspondingInfo = "";
      const correspondents = window.authorsData.filter(a => a.isCorresponding && a.email);
      if (correspondents.length > 0) {
          correspondingInfo = "<br><br>" + correspondents.map(c => `<sup>*</sup>Corresponding author: ${c.email}`).join("<br>");
      }

      outputBox.innerHTML = `${formattedAuthors}<br><br>${formattedAffils}${correspondingInfo}`;
  };

  window.compileFinalManuscript = function() {
      const title = (document.getElementById('globalTitle') as HTMLInputElement).value || "XXXXXXXX";
      
      const getVal = (id: string, isHtml = false) => {
          const el = document.getElementById(id);
          if (!el) return "";
          if (isHtml) return el.innerHTML;
          return el.tagName === 'TEXTAREA' ? (el as HTMLTextAreaElement).value : (el as HTMLElement).innerText;
      };

      const authorAffilHtml = getVal('draft-formatted-authors', true);
      const abstractHtml = getVal('finalAbstractEdit', true);
      const introHtml = getVal('draft-intro', true);
      const methodsHtml = getVal('draft-methods', true);
      const matrixHtml = getVal('draft-summary-matrix', true);
      const resultsHtml = getVal('draft-results', true);
      const discussionHtml = getVal('draft-discussion', true);
      const conclusionHtml = getVal('draft-conclusion', true);
      const references = (document.getElementById('draftReferences') as HTMLTextAreaElement).value;

      // Format references to match APA journal publication style (hanging indents, professional spacing, no grey background)
      const items = references.split(/\n\s*\n/).filter(r => r.trim());
      const referencesHtml = items.length > 0 
          ? items.map(ref => {
              return `<p style="padding-left: 36pt; text-indent: -36pt; margin-top: 0; margin-bottom: 12pt; font-family: 'Times New Roman', Times, serif; font-size: 11pt; line-height: 1.5; text-align: left; background: transparent; color: black; border: none; word-wrap: break-word;">${ref.trim()}</p>`;
            }).join('\n')
          : `<p style="font-family: 'Times New Roman', serif; font-style: italic; color: #64748b;">No references cited yet.</p>`;

      // Construct HTML version
      const htmlContent = `
        <div style="font-family: 'Times New Roman', Times, serif; color: black; line-height: 1.6; max-width: 800px; margin: 0 auto; text-align: left;">
          <h1 style="text-align: center; font-size: 18pt; font-weight: bold; margin-bottom: 24pt;">${title}</h1>
          
          <div style="text-align: center; margin-bottom: 24pt;">
            ${authorAffilHtml}
          </div>

          <div style="margin-bottom: 24pt;">
            <p><strong>ABSTRACT</strong></p>
            <div style="text-align: justify;">${abstractHtml}</div>
          </div>

          <div style="margin-bottom: 12pt;">
            <p><strong>1. INTRODUCTION</strong></p>
            <div style="text-align: justify;">${introHtml}</div>
          </div>

          <div style="margin-bottom: 12pt;">
            <p><strong>2. MATERIALS & METHODS</strong></p>
            <div style="text-align: justify;">${methodsHtml}</div>
          </div>

          <!-- BEAUTIFUL LANDSCAPE VISUAL PREVIEW FOR SUMMARY MATRIX -->
          <div class="landscape-section" style="margin: 24pt 0; padding: 24px; border: 1.5px dashed #8b5cf6; background: #faf5ff; border-radius: 12px; overflow-x: auto; position: relative;">
            <div style="font-family: system-ui, -apple-system, sans-serif; font-size: 8pt; font-weight: bold; background: #8b5cf6; color: white; padding: 4px 10px; border-radius: 6px; position: absolute; top: 12px; right: 12px;" class="landscape-marker">[LANDSCAPE PAGE PREVIEW]</div>
            <p style="margin-top: 0; font-family: 'Times New Roman', serif;"><strong>3. RESULTS (SUMMARY MATRIX)</strong></p>
            <div style="min-width: 900px; padding: 10px 0;">${matrixHtml}</div>
          </div>

          <div style="margin-bottom: 12pt;">
            <p><strong>4. RESULTS</strong></p>
            <div style="text-align: justify;">${resultsHtml}</div>
          </div>

          <div style="margin-bottom: 12pt;">
            <p><strong>5. DISCUSSION</strong></p>
            <div style="text-align: justify;">${discussionHtml}</div>
          </div>

          <div style="margin-bottom: 12pt;">
            <p><strong>6. CONCLUSION</strong></p>
            <div style="text-align: justify;">${conclusionHtml}</div>
          </div>

          <div style="margin-bottom: 12pt; border-top: 1px solid #ddd; padding-top: 24px;">
            <p style="font-size: 12pt; font-weight: bold; margin-bottom: 18pt;">REFERENCES</p>
            <div style="background: transparent; padding: 0;">${referencesHtml}</div>
          </div>
        </div>
      `;

      const preview = document.getElementById('fullManuscriptPreview');
      if (preview) {
        preview.innerHTML = htmlContent;
        preview.scrollTop = 0;
      }

      // Also update the hidden textarea for backup/plain-text use if needed
      const plainText = preview ? (preview as HTMLElement).innerText : "";
      const fullArea = document.getElementById('fullManuscriptText') as HTMLTextAreaElement;
      if (fullArea) fullArea.value = plainText;

      alert("Manuscript compiled successfully! You can find the formatted preview in the 'Compile' tab. Use the Download button to export as Doc.");
  };

  window.downloadManuscript = function() {
      const preview = document.getElementById('fullManuscriptPreview');
      if (!preview || !preview.innerHTML.trim()) {
          alert("Please click 'Compile Manuscript' first.");
          return;
      }

      const title = (document.getElementById('globalTitle') as HTMLInputElement).value || "XXXXXXXX";
      
      const getVal = (id: string, isHtml = false) => {
          const el = document.getElementById(id);
          if (!el) return "";
          if (isHtml) return el.innerHTML;
          return el.tagName === 'TEXTAREA' ? (el as HTMLTextAreaElement).value : (el as HTMLElement).innerText;
      };

      const authorAffilHtml = getVal('draft-formatted-authors', true);
      const abstractHtml = getVal('finalAbstractEdit', true);
      const introHtml = getVal('draft-intro', true);
      const methodsHtml = getVal('draft-methods', true);
      const matrixHtml = getVal('draft-summary-matrix', true);
      const resultsHtml = getVal('draft-results', true);
      const discussionHtml = getVal('draft-discussion', true);
      const conclusionHtml = getVal('draft-conclusion', true);
      const references = (document.getElementById('draftReferences') as HTMLTextAreaElement).value;

      // Format elements as Word list entries with proper hang indent logic
      const items = references.split(/\n\s*\n/).filter(r => r.trim());
      const referencesHtml = items.map(ref => {
          return `<p class="MsoBibliography" style="margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:36.0pt;text-indent:-36.0pt;line-height:150%;font-size:11.0pt;font-family:'Times New Roman',serif;color:black;">${ref.trim()}</p>`;
      }).join('\n');
      
      const wordHtml = `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
        <meta charset='utf-8'>
        <title>Manuscript</title>
        <!--[if gte mso 9]>
        <xml>
          <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>100</w:Zoom>
            <w:DoNotOptimizeForBrowser/>
          </w:WordDocument>
        </xml>
        <![endif]-->
        <style>
          /* Portrait Margins */
          @page Section1 {
              size: 8.5in 11.0in;
              margin: 1.0in 1.0in 1.0in 1.0in;
              mso-header-margin: .5in;
              mso-footer-margin: .5in;
              mso-paper-source: 0;
          }
          div.Section1 {
              page: Section1;
          }
          
          /* Landscape Section Margins & Setup */
          @page Section2 {
              size: 11.0in 8.5in;
              margin: 1.0in 1.0in 1.0in 1.0in;
              mso-header-margin: .5in;
              mso-footer-margin: .5in;
              mso-paper-source: 0;
              mso-page-orientation: landscape;
          }
          div.Section2 {
              page: Section2;
          }

          body { 
              font-family: 'Times New Roman', Times, serif; 
              font-size: 12.0pt;
              line-height: 1.5; 
              color: black;
          }
          
          /* APA Academic Table Guidelines */
          table {
              border-collapse: collapse;
              width: 100%;
              margin-top: 12pt;
              margin-bottom: 24pt;
          }
          tr {
              page-break-inside: avoid;
          }
          th {
              border-top: 1.5pt solid black;
              border-bottom: 1.0pt solid black;
              padding: 8pt;
              font-weight: bold;
              text-align: left;
              font-size: 11.0pt;
              font-family: 'Times New Roman', Times, serif;
              background-color: transparent;
          }
          td {
              border-bottom: 0.5pt solid #7f7f7f;
              padding: 8pt;
              text-align: left;
              font-size: 11.0pt;
              font-family: 'Times New Roman', Times, serif;
          }
          tr:last-child td {
              border-bottom: 1.5pt solid black;
          }
          
          sub, sup { font-size: 75%; line-height: 0; position: relative; vertical-align: baseline; }
          sup { top: -0.5em; }
          sub { bottom: -0.25em; }
          
          h1 { text-align: center; font-size: 18.0pt; font-weight: bold; margin-bottom: 18.0pt; }
          p { margin-bottom: 10.0pt; }
          
          .MsoBibliography {
              margin-left: 36.0pt;
              text-indent: -36.0pt;
              line-height: 150%;
              margin-top: 0cm;
              margin-right: 0cm;
              margin-bottom: 8.0pt;
          }
        </style>
        </head>
        <body>
          
          <!-- SECTION 1: PORTRAIT PARTS -->
          <div class="Section1">
            <h1 style="text-align: center; font-size: 18pt; font-weight: bold; margin-bottom: 24pt;">${title}</h1>
            
            <div style="text-align: center; margin-bottom: 24pt;">
              ${authorAffilHtml}
            </div>

            <div style="margin-bottom: 24pt;">
              <p><strong>ABSTRACT</strong></p>
              <div style="text-align: justify;">${abstractHtml}</div>
            </div>

            <div style="margin-bottom: 12pt;">
              <p><strong>1. INTRODUCTION</strong></p>
              <div style="text-align: justify;">${introHtml}</div>
            </div>

            <div style="margin-bottom: 12pt;">
              <p><strong>2. MATERIALS & METHODS</strong></p>
              <div style="text-align: justify;">${methodsHtml}</div>
            </div>
          </div>

          <!-- BREAK CONVERTS THIS PORTION INTO LANDSCAPE SECTION IN MS WORD -->
          <br clear="all" style="page-break-before:always; mso-break-type:section-break;" />

          <!-- SECTION 2: LANDSCAPE PARTS -->
          <div class="Section2">
            <p><strong>3. RESULTS (SUMMARY MATRIX)</strong></p>
            <div>${matrixHtml}</div>
          </div>

          <!-- BREAK TO GO BACK TO PORTRAIT -->
          <br clear="all" style="page-break-before:always; mso-break-type:section-break;" />

          <!-- SECTION 3: PORTRAIT PARTS (CONTINUED) -->
          <div class="Section1">
            <div style="margin-bottom: 12pt;">
              <p><strong>4. RESULTS</strong></p>
              <div style="text-align: justify;">${resultsHtml}</div>
            </div>

            <div style="margin-bottom: 12pt;">
              <p><strong>5. DISCUSSION</strong></p>
              <div style="text-align: justify;">${discussionHtml}</div>
            </div>

            <div style="margin-bottom: 12pt;">
              <p><strong>6. CONCLUSION</strong></p>
              <div style="text-align: justify;">${conclusionHtml}</div>
            </div>

            <div style="margin-bottom: 12pt; border-top: 1px solid #ddd; padding-top: 24pt;">
              <p style="font-size: 12pt; font-weight: bold; margin-bottom: 18pt;">REFERENCES</p>
              ${referencesHtml}
            </div>
          </div>

        </body>
        </html>
      `;

      const blob = new Blob(['\ufeff', wordHtml], {
          type: 'application/msword'
      });
      
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      // Sanitize name
      const safeTitle = title.replace(/[^a-z0-9]/gi, '_').substring(0, 30);
      link.download = `${safeTitle || "Manuscript"}_Final_Draft.doc`;
      link.click();
  };

  window.exportSelectedReferencesToWord = function() {
      const items = window.filteredList.filter(f => f.active && f.finalActive);
      if (items.length === 0) {
          alert("No references are currently selected for inclusion. Under '4. MANUAL SELECTION', make sure you have checked/finalized some references first.");
          return;
      }

      // Sort alphabetically by APA citation string
      const sortedItems = [...items].sort((a, b) => {
          const refA = window.formatReferenceAPA(a, false).toLowerCase();
          const refB = window.formatReferenceAPA(b, false).toLowerCase();
          return refA.localeCompare(refB);
      });

      const globalTitleEl = document.getElementById('globalTitle') as HTMLInputElement;
      const title = globalTitleEl ? globalTitleEl.value : "Selected";

      const referencesHtml = sortedItems.map((item, i) => {
          const apaHtml = window.formatReferenceAPA(item, true);
          return `<p class="MsoBibliography" style="margin-top:0cm;margin-right:0cm;margin-bottom:12.0pt;margin-left:36.0pt;text-indent:-36.0pt;line-height:150%;font-size:11.0pt;font-family:'Times New Roman',serif;color:black;">${apaHtml}</p>`;
      }).join('\n');

      const wordHtml = `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
        <meta charset='utf-8'>
        <title>Selected References (APA Format)</title>
        <!--[if gte mso 9]>
        <xml>
          <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>100</w:Zoom>
            <w:DoNotOptimizeForBrowser/>
          </w:WordDocument>
        </xml>
        <![endif]-->
        <style>
          @page Section1 {
              size: 8.5in 11.0in;
              margin: 1.0in 1.0in 1.0in 1.0in;
              mso-header-margin: .5in;
              mso-footer-margin: .5in;
              mso-paper-source: 0;
          }
          div.Section1 {
              page: Section1;
          }
          body { 
              font-family: 'Times New Roman', Times, serif; 
              font-size: 11.0pt;
              line-height: 1.5; 
              color: black;
          }
          h1 { text-align: center; font-size: 16.0pt; font-weight: bold; margin-bottom: 24.0pt; }
          .MsoBibliography {
              margin-left: 36.0pt;
              text-indent: -36.0pt;
              line-height: 150%;
              margin-top: 0cm;
              margin-right: 0cm;
              margin-bottom: 12.0pt;
          }
        </style>
        </head>
        <body>
          <div class="Section1">
            <h1>References</h1>
            ${referencesHtml}
          </div>
        </body>
        </html>
      `;

      const blob = new Blob(['\ufeff', wordHtml], {
          type: 'application/msword'
      });
      
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const safeTitle = title.replace(/[^a-z0-9]/gi, '_').substring(0, 30);
      link.download = `${safeTitle || "References"}_Selected_APA_References.doc`;
      link.click();
      URL.revokeObjectURL(url);
  };

  window.genManualSelectionPrompt = function() {
    let dataStr = "";
    let count = 0;
    window.filteredList.forEach((f, idx) => {
      if (!f.active) return;
      count++;
      const a = f.data;
      dataStr += `\n[ID: ${idx + 1}] Author: ${a['authors'] || 'N/A'}, Year: ${a['year'] || 'N/A'}, Title: ${a['title'] || 'N/A'}\n`;
    });
    const box = document.getElementById('manualPromptBox');
    if (box) {
      box.innerText = `Summary table (Just the table) command based on (Please also include type of study for each of the listed references):\n\nI have the following ${count} studies. Please evaluate their findings and identify the study design for each. Return the result in a markdown table with columns: ID, Reference (Author & Year), Study Type/Design, and Key Findings.\n\n${dataStr}`;
      const outSec = document.getElementById('manualOutputSection');
      if (outSec) outSec.style.display = 'block';
    }
  };

  window.generateSummaryMatrixPrompt = function() {
    const active = window.filteredList.filter(f => f.active && f.finalActive);
    
    // Create a detailed list of references with their data
    let dataList = "";
    active.forEach((item, i) => {
        dataList += `REFERENCE ID ${i + 1}:\nTITLE: ${item.data.title}\nAUTHORS: ${item.data.authors}\nYEAR: ${item.data.year}\nABSTRACT: ${item.data.abstract || 'N/A'}\nKEYWORDS: ${item.data.keywords || 'N/A'}\n\n`;
    });

    const prompt = `Act as an expert in writing a Systematic Literature Review (SLR) that follows the PRISMA Statement steps. Below are the 'methods and results section' of an article that needs to be analysed into a summary table. Get the information for references that do not have complete information. Based on all the ‘methods and results’ data (including the newly complete), fill up a summary table consisting of Author's name, type of study, objective, type of intervention, findings, conclusion :

Included References Data:
${dataList}`;

    const box = document.getElementById('matrixPromptBox');
    if (box) {
        box.innerText = prompt;
        box.style.display = 'block';
    }
    
    // Also copy to clipboard for convenience like other table prompts
    navigator.clipboard.writeText(prompt).then(() => {
        alert("Summary Table Prompt copied to clipboard!");
    });
  };

  window.generateThemeBasedSummaryMatrixPrompt = function() {
    const el = document.getElementById('geminiResultsInput');
    const input = el ? (el.tagName === 'TEXTAREA' ? (el as HTMLTextAreaElement).value : (el as HTMLElement).innerText) : "";
    const finalPool = window.filteredList.filter(f => f.active && f.finalActive);
    
    let theme1List = "N/A";
    let theme2List = "N/A";
    let theme3List = "N/A";
    let theme4List = "N/A";
    let theme5List = "N/A";
    
    for (let i = 1; i <= 5; i++) {
        const listRegex = new RegExp(`Theme ${i} \\(Article List\\):\\s*(.*)`, 'i');
        const listMatch = input.match(listRegex);
        const idsString = listMatch ? listMatch[1].trim() : "";
        if (i === 1) theme1List = idsString || "N/A";
        if (i === 2) theme2List = idsString || "N/A";
        if (i === 3) theme3List = idsString || "N/A";
        if (i === 4) theme4List = idsString || "N/A";
        if (i === 5) theme5List = idsString || "N/A";
    }

    // Now format the reference details
    let referenceDetailsText = "";
    const nameMap = new Map<number, string>();
    for (let i = 1; i <= 5; i++) {
        const nameRegex = new RegExp(`Theme ${i} \\(Name\\):\\s*(.*)`, 'i');
        const nameMatch = input.match(nameRegex);
        nameMap.set(i, nameMatch ? nameMatch[1].trim() : `Theme ${i}`);
    }

    for (let i = 1; i <= 5; i++) {
        const listRegex = new RegExp(`Theme ${i} \\(Article List\\):\\s*(.*)`, 'i');
        const listMatch = input.match(listRegex);
        const idsString = listMatch ? listMatch[1].trim() : "";
        const ids = idsString.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));
        
        if (ids.length > 0) {
            referenceDetailsText += `\nPapers under Theme ${i} (${nameMap.get(i)}):\n`;
            ids.forEach(id => {
                const item = finalPool[id - 1];
                if (item) {
                     referenceDetailsText += `REFERENCE ID ${id}:\nTITLE: ${item.data.title}\nAUTHORS: ${item.data.authors}\nYEAR: ${item.data.year}\nABSTRACT: ${item.data.abstract || 'N/A'}\nKEYWORDS: ${item.data.keywords || 'N/A'}\n\n`;
                }
            });
        }
    }

    const prompt = `Act as an expert in writing a Systematic Literature Review (SLR) that follows the PRISMA Statement steps. Below are the 'methods and results section' of an article that needs to be analysed into a summary table. Get the information for references that do not have complete information. Based on all the ‘methods and results’ data (including the newly complete), fill up a summary table consisting of Author's name, type of study, objective, type of intervention, findings and  conclusion. List the references in the table according to the five themes. Please do not change the allocation of the references into the themes. Instead of having the theme into each row just label one row across the columns with "THEME 1: Title of the theme" then list of the references with the information, similarly for the rest of the themes. 

Included Reference Data: Theme 1 (article list): ${theme1List} Theme 2 (article list): ${theme2List} Theme 3 (article list): ${theme3List} Theme 4 (article list): ${theme4List} and Theme 5 (article list): ${theme5List}

Reference Details & Text:
${referenceDetailsText}`;

    const box = document.getElementById('themeBasedMatrixPromptBox');
    if (box) {
        box.innerText = prompt;
        box.style.display = 'block';
    }
    
    // Copy to clipboard
    navigator.clipboard.writeText(prompt).then(() => {
        alert("Theme-based Summary Table Matrix Prompt copied to clipboard!");
    });
  };

  window.genAbstractPromptDetailed = function() {
    const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
    const prompt = `Write a structured academic abstract (250-300 words) for the systematic review titled: "${title}".\nInclude the following sections:\n1. Objective: State the goal.\n2. Methods: SLR following PRISMA guidelines.\n3. Results: Summary of the 5 key themes discovered.\n4. Conclusion: Practical implications.`;
    const box = document.getElementById('abstractPromptBox');
    if (box) {
        box.innerText = prompt;
        box.style.display = 'block';
    }
  };

  window.genCoverLetterPrompt = function() {
    const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
    const journal = (document.getElementById('targetJournal') as HTMLInputElement).value || "[JOURNAL NAME]";
    const prompt = `Write a professional cover letter for a manuscript submission to "${journal}".\nManuscript Title: "${title}"\nHighlight the novelty of the systematic review and why it fits the journal's scope. Use a standard academic cover letter format.`;
    const box = document.getElementById('coverPromptBox');
    if (box) {
        box.innerText = prompt;
        box.style.display = 'block';
    }
  };

  window.copyFullManuscript = function() {
      const el = document.getElementById('fullManuscriptPreview');
      if (!el) return;

      const range = document.createRange();
      range.selectNodeContents(el);
      const selection = window.getSelection();
      if (selection) {
          selection.removeAllRanges();
          selection.addRange(range);
          
          try {
              document.execCommand('copy');
              alert("Formatted manuscript copied to clipboard!");
          } catch (err) {
              alert("Unable to copy formatted text automatically. Please use Ctrl+C.");
          }
          selection.removeAllRanges();
      }
  };

  const stripReferences = (text: string): string => {
    if (!text) return "";
    const refKeywords = ["REFERENCES", "BIBLIOGRAPHY", "REFERENCE LIST", "CITED WORKS", "References", "Bibliography", "Reference List", "Cited Works"];
    for (const kw of refKeywords) {
      // Look for the keyword after a newline or at the start, often followed by a colon or newline
      // Support **References** markdown bolding too
      const regex = new RegExp(`(?:\\n\\n|\\r\\n\\r\\n|\\n|\\r)(?:\\*\\*)?(?:${kw})(?:\\*\\*)?[:\\s\\n\\r][\\s\\S]*$`, 'i');
      const match = text.match(regex);
      if (match) {
        return text.substring(0, match.index).trim();
      }
      // Very strict start-of-string check
      const cleanLower = text.trim().toLowerCase();
      if (cleanLower.startsWith(kw.toLowerCase() + ":") || cleanLower === kw.toLowerCase() || 
          cleanLower.startsWith("**" + kw.toLowerCase() + "**") || cleanLower === "**" + kw.toLowerCase() + "**") {
          return "";
      }
    }
    return text;
  };

  const stripReferencesHtml = (html: string): string => {
    if (!html) return "";
    // Detect keywords in text content first
    const temp = document.createElement('div');
    temp.innerHTML = html;
    const text = temp.innerText;
    
    if (/(?:REFERENCES|BIBLIOGRAPHY|REFERENCE LIST|CITED WORKS)/i.test(text)) {
       // Handle HTML tags and Markdown bold markers if they leaked into the HTML string
       const refRegex = /(?:<p>|<br>|<div>|\n|^)(?:<strong>|<b>|<h3>|<h4>|\*\*)?\s*(?:REFERENCES|BIBLIOGRAPHY|REFERENCE LIST|CITED WORKS)(?:<\/strong>|<\/b>|\*\*)?[\s\S]*$/i;
       const match = html.match(refRegex);
       if (match) {
           return html.substring(0, match.index).trim();
       }
    }
    return html;
  };

  window.syncPaperDraft = function(silent = false) {
    // Synchronize content from various research tabs into the manuscript draft
    
    // 2. Introduction -> draft-intro
    const introBox = document.getElementById('refinedIntro');
    const fallbackBox = document.getElementById('finalIntroEdit');
    
    const draftIntro = document.getElementById('draft-intro');
    if (draftIntro) {
        const introHtml = introBox ? introBox.innerHTML.trim() : "";
        const introText = introBox ? introBox.innerText.trim() : "";

        let compiledIntro = "";
        
        if (introText) {
            compiledIntro = introHtml;
        } else {
            const fallbackVal = fallbackBox ? (fallbackBox.tagName === 'TEXTAREA' ? (fallbackBox as HTMLTextAreaElement).value : fallbackBox.innerHTML) : "";
            compiledIntro = fallbackVal;
        }

        const cleaned = stripReferencesHtml(compiledIntro);
        if (draftIntro.tagName === 'TEXTAREA') (draftIntro as HTMLTextAreaElement).value = cleaned;
        else (draftIntro as HTMLElement).innerHTML = cleaned;
    }

    // 3. Materials & Methods -> draft-methods
    const methodsBox = document.getElementById('methodsElaborationInput');
    const methodsVal = methodsBox ? (methodsBox.tagName === 'TEXTAREA' ? (methodsBox as HTMLTextAreaElement).value : (methodsBox as HTMLElement).innerHTML) : "";
    const draftMethods = document.getElementById('draft-methods');
    if (draftMethods) {
        const cleaned = (methodsBox && methodsBox.tagName === 'TEXTAREA') ? stripReferences(methodsVal) : stripReferencesHtml(methodsVal);
        if (draftMethods.tagName === 'TEXTAREA') (draftMethods as HTMLTextAreaElement).value = cleaned;
        else (draftMethods as HTMLElement).innerHTML = cleaned;
    }

    // 3. Results (Summary Table) -> draft-summary-matrix
    const summaryMatrixBox = document.getElementById('summaryMatrixTable');
    const themeBasedSummaryMatrixBox = document.getElementById('themeBasedMatrixTable');
    const draftSummaryMatrix = document.getElementById('draft-summary-matrix');
    if (draftSummaryMatrix) {
        let compiledMatrixHtml = "";
        
        if (summaryMatrixBox) {
            const val = (summaryMatrixBox.tagName === 'TEXTAREA') ? (summaryMatrixBox as HTMLTextAreaElement).value : (summaryMatrixBox as HTMLElement).innerHTML;
            if (val.trim() && val !== (summaryMatrixBox as HTMLElement).getAttribute('data-placeholder') && val !== "Paste synthesized matrix here...") {
                compiledMatrixHtml += `<h3>Summary Table (Overall)</h3>\n<div>${val}</div>`;
            }
        }
        
        if (themeBasedSummaryMatrixBox) {
            const val = (themeBasedSummaryMatrixBox.tagName === 'TEXTAREA') ? (themeBasedSummaryMatrixBox as HTMLTextAreaElement).value : (themeBasedSummaryMatrixBox as HTMLElement).innerHTML;
            if (val.trim() && val !== (themeBasedSummaryMatrixBox as HTMLElement).getAttribute('data-placeholder') && val !== "Paste theme-based summary table here...") {
                if (compiledMatrixHtml) compiledMatrixHtml += "\n\n<hr class=\"my-4\" />\n\n";
                compiledMatrixHtml += `<h3>Summary Table (Theme-based)</h3>\n<div>${val}</div>`;
            }
        }
        
        // If neither had structured custom content, fallback to raw overall table content if active
        if (!compiledMatrixHtml && summaryMatrixBox) {
            const val = (summaryMatrixBox.tagName === 'TEXTAREA') ? (summaryMatrixBox as HTMLTextAreaElement).value : (summaryMatrixBox as HTMLElement).innerHTML;
            compiledMatrixHtml = val;
        }

        const cleaned = stripReferencesHtml(compiledMatrixHtml);
        if (draftSummaryMatrix.tagName === 'TEXTAREA') {
            (draftSummaryMatrix as HTMLTextAreaElement).value = cleaned;
        } else {
            (draftSummaryMatrix as HTMLElement).innerHTML = cleaned;
        }
    }

    // 4. Results -> draft-results
    let resultsHtml = "";
    const compiledResultsBox = document.getElementById('compiledResultsNarrative');
    const compiledResultsVal = compiledResultsBox ? compiledResultsBox.innerText.trim() : "";
    
    if (compiledResultsVal) {
        const cleanedCompiled = compiledResultsBox ? (compiledResultsBox.tagName === 'TEXTAREA' ? stripReferences(compiledResultsVal) : stripReferencesHtml(compiledResultsBox.innerHTML)) : "";
        resultsHtml = cleanedCompiled;
    } else {
        const resultsIntroBox = document.getElementById('geminiResultsInput');
        const resultsIntro = resultsIntroBox ? (resultsIntroBox.tagName === 'TEXTAREA' ? (resultsIntroBox as HTMLTextAreaElement).value : (resultsIntroBox as HTMLElement).innerHTML) : "";
        const cleanedIntro = (resultsIntroBox && resultsIntroBox.tagName === 'TEXTAREA') ? stripReferences(resultsIntro) : stripReferencesHtml(resultsIntro);
        // Only include intro if it doesn't look like JUST the theme prompt output (which is transient)
        if (cleanedIntro && !cleanedIntro.includes("Theme 1 (Name)")) {
           resultsHtml += `<div class="mb-4">${cleanedIntro}</div>`;
        }

        for (let i = 1; i <= 5; i++) {
            const themeName = document.getElementById(`dispName${i}`)?.innerText || `Theme ${i}`;
            const summaryBox = document.getElementById(`themeSummary${i}`);
            const summary = summaryBox ? (summaryBox as HTMLElement).innerHTML : "";
            const cleanedSummary = stripReferencesHtml(summary);
            if (cleanedSummary && cleanedSummary.trim() !== "" && cleanedSummary !== "<br>") {
                resultsHtml += `<h3 class="mt-4 mb-2 font-bold text-indigo-700">${themeName}</h3><div class="mb-4">${cleanedSummary}</div>`;
            }
        }
    }
    const draftResults = document.getElementById('draft-results');
    if (draftResults) {
        if (draftResults.tagName === 'TEXTAREA') (draftResults as HTMLTextAreaElement).value = resultsHtml;
        else (draftResults as HTMLElement).innerHTML = resultsHtml;
    }

    // 5. Discussion -> draft-discussion
    let discHtml = "";
    const discIntroBox = document.getElementById('finalDiscEdit');
    const discIntro = discIntroBox ? (discIntroBox.tagName === 'TEXTAREA' ? (discIntroBox as HTMLTextAreaElement).value : (discIntroBox as HTMLElement).innerHTML) : "";
    const cleanedDiscIntro = (discIntroBox && discIntroBox.tagName === 'TEXTAREA') ? stripReferences(discIntro) : stripReferencesHtml(discIntro);
    if (cleanedDiscIntro) {
        discHtml += `<div class="mb-4">${cleanedDiscIntro}</div>`;
    }

    // Parse and update bibliographic references from the Discussion tab references box to Tab 9 References section
    if (typeof (window as any).syncAndArrangeReferences === 'function') {
        (window as any).syncAndArrangeReferences('finalDiscRefs');
    }

    const draftDisc = document.getElementById('draft-discussion');
    if (draftDisc) {
        if (draftDisc.tagName === 'TEXTAREA') (draftDisc as HTMLTextAreaElement).value = discHtml;
        else (draftDisc as HTMLElement).innerHTML = discHtml;
    }

    // 6. Conclusion -> draft-conclusion
    const concBox = document.getElementById('conclusionTextArea');
    const concVal = concBox ? (concBox.tagName === 'TEXTAREA' ? (concBox as HTMLTextAreaElement).value : (concBox as HTMLElement).innerHTML) : "";
    const draftConc = document.getElementById('draft-conclusion');
    if (draftConc) {
        const cleaned = (concBox && concBox.tagName === 'TEXTAREA') ? stripReferences(concVal) : stripReferencesHtml(concVal);
        if (draftConc.tagName === 'TEXTAREA') (draftConc as HTMLTextAreaElement).value = cleaned;
        else (draftConc as HTMLElement).innerHTML = cleaned;
    }

    // Sync references list
    const usedRefs = (window as any).usedReferences as Set<number>;
    let refLines: string[] = [];
    const sortedIndices = Array.from(usedRefs)
      .filter(idx => window.filteredList[idx] !== undefined)
      .sort((a, b) => {
        const refA = window.formatReferenceAPA(window.filteredList[a], false).toLowerCase();
        const refB = window.formatReferenceAPA(window.filteredList[b], false).toLowerCase();
        return refA.localeCompare(refB);
      });

    sortedIndices.forEach(idx => {
        const item = window.filteredList[idx];
        if (item) {
            refLines.push(window.formatReferenceAPA(item, false));
        }
    });

    const draftRefs = document.getElementById('draftReferences') as HTMLTextAreaElement;
    if (draftRefs) draftRefs.value = refLines.join('\n\n');
    
    // Refresh visual references list on Draft tab
    window.updateReferenceList();
    
    if (!silent) alert("Synced content from all research tabs into the Academic Manuscript Draft Builder.");
  };

  window.saveWork = async function() {
    const inputIds = [
      'globalTitle', 'targetJournal', 'startYear', 'endYear', 'excLanguage',
      'exKw1', 'exKw2', 'incCountries'
    ];
    const checkboxIds = [
      'incEnglish', 'exBooks', 'exConf', 'exReview', 'exEditorial', 'incRCT'
    ];
    const textareaIds = [
      'finalCoverLetter', 'suggestedCategoriesTextArea', 'draftReferences', 'fullManuscriptText'
    ];
    const contentEditableIds = [
      'methodsElaborationInput', 'geminiResultsInput', 'summaryMatrixTable', 'themeBasedMatrixTable',
      'discThemeSummary1', 'discThemeSummary2', 'discThemeSummary3', 'discThemeSummary4', 'discThemeSummary5',
      'finalDiscEdit', 'finalDiscRefs', 'conclusionTextArea', 'finalAbstractEdit',
      'draft-formatted-authors', 'draft-intro', 'draft-methods', 'draft-summary-matrix',
      'draft-results', 'draft-discussion', 'draft-conclusion', 'fullManuscriptPreview',
      'manualTablePaste', 'assistantGeminiSearchResultPaste', 'categoriesToScreenResultPaste',
      'refinedResearchQuestions', 'refinedObjectives', 'refinedIntro', 'refinedIntroRefs'
    ];
    const containerIds = [
      'screeningStats', 'deduplicationSection', 'exclusionContainer', 'suggestedCategoriesContainer',
      'exclusionReasons', 'filteredRefsSection', 'manualSelectionSection', 'manualOutputSection',
      'manualSelectionTableContainer', 'finalRefsSection', 'methodElaborationSection',
      'geminiResultsSection', 'discPromptContainer', 'discResultsPasteSection',
      'conclusionPromptBox', 'copyConclusionBtn', 'abstractPromptBox', 'coverPromptBox'
    ];

    const inputValues: Record<string, string> = {};
    inputIds.forEach(id => {
      const el = document.getElementById(id) as HTMLInputElement;
      if (el) inputValues[id] = el.value || "";
    });

    const checkboxValues: Record<string, boolean> = {};
    checkboxIds.forEach(id => {
      const el = document.getElementById(id) as HTMLInputElement;
      if (el) checkboxValues[id] = el.checked;
    });

    const textareaValues: Record<string, string> = {};
    textareaIds.forEach(id => {
      const el = document.getElementById(id) as HTMLTextAreaElement;
      if (el) textareaValues[id] = el.value || "";
    });

    const contentEditableHtmls: Record<string, string> = {};
    contentEditableIds.forEach(id => {
      const el = document.getElementById(id);
      if (el) contentEditableHtmls[id] = el.innerHTML || "";
    });

    const displayStates: Record<string, string> = {};
    containerIds.forEach(id => {
      const el = document.getElementById(id);
      if (el) displayStates[id] = el.style.display || "none";
    });

    const state = {
      rawData: window.rawData,
      filteredList: window.filteredList,
      totalInitial: window.totalInitial,
      aiExclusions: window.aiExclusions,
      prismaTheme: (window as any).prismaTheme || 'gradient',
      usedReferences: Array.from((window as any).usedReferences || new Set()),
      authorsData: window.authorsData,
      affiliationsData: window.affiliationsData,
      temporaryFilteredLists: window.temporaryFilteredLists,
      globalExCounts: window.globalExCounts,
      inputValues,
      checkboxValues,
      textareaValues,
      contentEditableHtmls,
      displayStates
    };

    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = "SLR_Workspace.json";
    link.click();
    URL.revokeObjectURL(url);
  };

  window.loadWork = function(event: any) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e: any) => {
      try {
        const state = JSON.parse(e.target.result);
        
        // Restore core data
        window.rawData = state.rawData || { wos: [], scopus: [], ncbi: [], scholar: [], cochrane: [], embase: [], ieee: [], cinahl: [], psycinfo: [], eric: [], sciencedirect: [], wiley: [] };
        window.filteredList = state.filteredList || [];
        window.totalInitial = state.totalInitial || 0;
        window.aiExclusions = state.aiExclusions || { designs: [], populations: [], interventions: [], outcomes: [], geo: [], kw: [] };
        (window as any).usedReferences = new Set(state.usedReferences || []);
        window.authorsData = state.authorsData || [{ name: "", affilLink: "", isCorresponding: false, email: "" }];
        window.affiliationsData = state.affiliationsData || [""];
        window.temporaryFilteredLists = state.temporaryFilteredLists || { wos: [], scopus: [], ncbi: [], scholar: [], cochrane: [], embase: [], ieee: [], cinahl: [], psycinfo: [], eric: [], sciencedirect: [], wiley: [] };
        window.globalExCounts = state.globalExCounts || { year: 0, lang: 0, docType: 0, rct: 0, keyword: 0, dup: 0 };

        const theme = state.prismaTheme || 'gradient';
        (window as any).prismaTheme = theme;
        if (typeof (window as any).onPrismaThemeLoaded === 'function') {
          (window as any).onPrismaThemeLoaded(theme);
        }

        // Restore core values
        if (state.inputValues) {
          Object.entries(state.inputValues).forEach(([id, val]) => {
            const el = document.getElementById(id) as HTMLInputElement;
            if (el) el.value = val as string;
          });
        }

        if (state.checkboxValues) {
          Object.entries(state.checkboxValues).forEach(([id, checked]) => {
            const el = document.getElementById(id) as HTMLInputElement;
            if (el) el.checked = checked as boolean;
          });
        }

        if (state.textareaValues) {
          Object.entries(state.textareaValues).forEach(([id, val]) => {
            const el = document.getElementById(id) as HTMLTextAreaElement;
            if (el) el.value = val as string;
          });
        }

        if (state.contentEditableHtmls) {
          Object.entries(state.contentEditableHtmls).forEach(([id, html]) => {
            const el = document.getElementById(id);
            if (el) el.innerHTML = html as string;
          });
        }

        if (state.displayStates) {
          Object.entries(state.displayStates).forEach(([id, disp]) => {
            const el = document.getElementById(id);
            if (el) el.style.display = disp as string;
          });
        } else {
          // Fallback visibility
          if (window.totalInitial > 0) {
            const stats = document.getElementById('screeningStats');
            if (stats) stats.style.display = 'grid';
            const dedup = document.getElementById('deduplicationSection');
            if (dedup) dedup.style.display = 'block';
          }
        }

        // Sync statistics labels if required
        Object.keys(window.rawData).forEach(db => {
          const countEl = document.getElementById(db + 'Count');
          if (countEl) {
            countEl.innerText = (window.rawData[db] || []).length.toString();
          }
        });

        // Run re-rendering
        window.renderReferenceLists();
        window.renderFinalReferencePool();
        window.updateFinalCounts();
        window.updatePrismaFigure();
        window.renderAuthors();
        window.renderAffiliations();
        
        // Re-generate category checkboxes and values if we have active AI exclusions
        const hasExclusions = Object.values(window.aiExclusions).some((arr: any) => arr.length > 0);
        if (hasExclusions || (document.getElementById('exclusionContainer')?.style.display !== 'none')) {
          window.generateSmartExclusionLists();
        }

        alert("Systematic Review Workspace successfully loaded!");
      } catch (err: any) {
        alert("Error loading SLR Workspace file: " + err.message);
      }
    };
    reader.readAsText(file);
  };

  window.toggleProjectMode = function() {
    const display = document.getElementById('projectModeDisplay');
    const knob = document.getElementById('modeToggleKnob');
    const btn = document.getElementById('modeToggleButton');
    if (!display || !knob || !btn) return;

    const isResearch = display.innerText === "RESEARCH MODE";
    if (isResearch) {
      display.innerText = "WRITING MODE";
      display.classList.remove('text-slate-500');
      display.classList.add('text-indigo-600');
      knob.style.left = '18px';
      btn.classList.remove('bg-slate-300');
      btn.classList.add('bg-indigo-500');
      document.body.style.background = '#f5f3ff'; // Subtle indigo background for writing
    } else {
      display.innerText = "RESEARCH MODE";
      display.classList.remove('text-indigo-600');
      display.classList.add('text-slate-500');
      knob.style.left = '2px';
      btn.classList.remove('bg-indigo-500');
      btn.classList.add('bg-slate-300');
      document.body.style.background = '#f8fafc'; // Back to slate
    }
  };

  window.runHealthCheck = function() {
    const title = (document.getElementById('globalTitle') as HTMLInputElement).value;
    const recordsCount = window.totalInitial || 0;
    const finalCount = window.filteredList ? window.filteredList.filter((f: any) => f.active && f.finalActive).length : 0;
    
    let status = "⚠️ Initial Phase";
    if (recordsCount > 0) status = "🔍 Screening Phase";
    if (finalCount > 0) status = "✍️ Synthesis Phase";

    const report = `
SLR PROJECT AUDIT
-----------------
Project: ${title}
Current Phase: ${status}

STATS:
• Raw Records: ${recordsCount}
• Final Included: ${finalCount}

INTEGRITY CHECK:
${recordsCount === 0 ? "❌ No data uploaded yet." : "✅ Data detected."}
${finalCount === 0 && recordsCount > 0 ? "⚠️ Screening not yet finalized." : ""}
${finalCount > 0 ? "✅ Ready for Manuscript generation." : ""}
    `;
    
    alert(report.trim());
  };

  /** Draft & Citation Enhancement Logic **/
  (window as any).activeDraftTextarea = null;
  (window as any).usedReferences = new Set();

  window.setActiveTextarea = function(id: string) {
    (window as any).activeDraftTextarea = id;
    document.querySelectorAll('.draft-textarea').forEach(el => el.classList.remove('active-textarea'));
    document.getElementById(id)?.classList.add('active-textarea');
  };

  window.renderReferenceSidebar = function() {
    const listDiv = document.getElementById('ref-sidebar-list');
    const countBadge = document.getElementById('ref-sidebar-count');
    if (!listDiv) return;
    
    const pool = window.filteredList.filter(f => f.active && f.finalActive);
    if (countBadge) countBadge.innerText = pool.length.toString();

    if (pool.length === 0) {
      listDiv.innerHTML = '<div class="p-4 text-center text-slate-400 text-xs italic">No finalized references available.</div>';
      return;
    }

    listDiv.innerHTML = "";
    pool.forEach((item, idx) => {
      const globalIdx = window.filteredList.indexOf(item);
      const div = document.createElement('div');
      div.className = 'ref-sidebar-item';
      div.onclick = () => window.citeReference(globalIdx.toString());
      div.innerHTML = `
        <span class="ref-meta">${item.data.authors?.split(',')[0]} ET AL., ${item.data.year}</span>
        <span class="ref-title">${item.data.title}</span>
        <div class="cite-btn">Cite This Article</div>
      `;
      listDiv.appendChild(div);
    });
  };

  window.citeReference = function(refId: string) {
    const idx = parseInt(refId);
    const item = window.filteredList[idx];
    if (!item) return;

    const targetId = (window as any).activeDraftTextarea;
    if (!targetId) {
      alert("Please click inside a writing box (Introduction, Methods, etc.) first to set the focus.");
      return;
    }

    const el = document.getElementById(targetId);
    if (!el) return;

    const author = (item.data.authors || "Unknown").split(',')[0] || "Unknown";
    const year = item.data.year || "n.d.";
    const citation = `(${author}, ${year})`;

    window.insertTextAtCursor(el as HTMLElement, citation);
    (window as any).usedReferences.add(idx);
    window.updateReferenceList();
  };

  window.updateReferenceList = function() {
    const listDiv = document.getElementById('used-references-list');
    if (!listDiv) return;

    const usedIndices = Array.from((window as any).usedReferences as Set<number>).filter(idx => window.filteredList[idx] !== undefined);
    if (usedIndices.length === 0) {
      listDiv.innerHTML = '<p class="italic text-slate-400">No citations added yet.</p>';
      return;
    }

    listDiv.innerHTML = "";
    const sorted = usedIndices.sort((a, b) => {
      const refA = window.formatReferenceAPA(window.filteredList[a], false).toLowerCase();
      const refB = window.formatReferenceAPA(window.filteredList[b], false).toLowerCase();
      return refA.localeCompare(refB);
    });

    sorted.forEach(idx => {
      const item = window.filteredList[idx];
      const p = document.createElement('p');
      p.className = 'mb-4 text-xs font-sans leading-relaxed text-slate-700 p-2 bg-white rounded border border-slate-100 shadow-sm';
      p.innerHTML = window.formatReferenceAPA(item, true);
      listDiv.appendChild(p);
    });

    // Also update the hidden draft references area for compilation
    const draftRefs = document.getElementById('draftReferences') as HTMLTextAreaElement;
    if (draftRefs) {
      draftRefs.value = sorted.map(idx => {
        const item = window.filteredList[idx];
        return window.formatReferenceAPA(item, false);
      }).join('\n\n');
    }
  };

  // Override updateFinalCounts to refresh sidebar
  const oldUpdateFinalCounts = window.updateFinalCounts;
  window.updateFinalCounts = function() {
    oldUpdateFinalCounts();
    window.renderReferenceSidebar();
    
    // Keep methods elaboration section always hidden as requested
    const methSec = document.getElementById('methodElaborationSection');
    if (methSec) methSec.style.display = 'none';
  };

  window.resetProject = function() {
    if (confirm("Are you sure you want to start a new project? All unsaved work will be lost.")) {
      window.rawData = { wos: [], scopus: [], ncbi: [], scholar: [], cochrane: [], embase: [], ieee: [], cinahl: [], psycinfo: [], eric: [], sciencedirect: [], wiley: [] };
      window.temporaryFilteredLists = { wos: [], scopus: [], ncbi: [], scholar: [], cochrane: [], embase: [], ieee: [], cinahl: [], psycinfo: [], eric: [], sciencedirect: [], wiley: [] };
      window.filteredList = [];
      window.assignments = [[], [], [], [], []];
      window.totalInitial = 0;
      window.globalExCounts = { year: 0, lang: 0, docType: 0, rct: 0, keyword: 0, dup: 0 };
      window.affiliationsData = [""];
      window.authorsData = [{ name: "", affilLink: "" }];
      window.finalActiveHistory = [];
      window.finalActiveHistoryIndex = -1;
      window.aiExclusions = { designs: [], populations: [], interventions: [], outcomes: [], geo: [], kw: [] };
      (window as any).usedReferences = new Set();
      
      // Explicitly reset individual database counts
      ['wosCount', 'scopusCount', 'ncbiCount', 'scholarCount', 'cochraneCount', 'embaseCount', 'ieeeCount', 'cinahlCount', 'psycinfoCount', 'ericCount', 'sciencedirectCount', 'wileyCount',
       'resWos', 'resScopus', 'resNcbi', 'resScholar', 'resCochrane', 'resEmbase', 'resIeee', 'resCinahl', 'resPsycinfo', 'resEric', 'resSciencedirect', 'resWiley'].forEach(id => {
          const el = document.getElementById(id);
          if (el) el.innerText = "0";
      });

      // Reset all badges
      document.querySelectorAll('.badge').forEach(el => (el as HTMLElement).innerText = "0");
      
      const resTotal = document.getElementById('resTotal');
      if (resTotal) resTotal.innerText = "0";
      
      const dupCount = document.getElementById('dupCount');
      if (dupCount) dupCount.innerText = "0";

      const manualEx = document.getElementById('finalManualExcluded');
      if (manualEx) manualEx.innerText = "0";

      const manualInc = document.getElementById('finalManualIncluded');
      if (manualInc) manualInc.innerText = "0";
      
      const flowIdent = document.getElementById('flowIdentified');
      const flowScreen = document.getElementById('flowScreened');
      const flowDedup = document.getElementById('flowDeduplicated');
      const flowFinal = document.getElementById('flowFinal');
      if (flowIdent) flowIdent.innerText = "0";
      if (flowScreen) flowScreen.innerText = "0";
      if (flowDedup) flowDedup.innerText = "0";
      if (flowFinal) flowFinal.innerText = "0";

      // Clear all inputs/textareas
      document.querySelectorAll('input[type="text"]').forEach(i => (i as HTMLInputElement).value = "");
      document.querySelector('#globalTitle') && ((document.getElementById('globalTitle') as HTMLInputElement).value = "Environmental Sustainability in Smart Cities");
      
      document.querySelectorAll('input[type="number"]').forEach(i => {
           if (i.id === 'startYear') (i as HTMLInputElement).value = "2010";
           else if (i.id === 'endYear') (i as HTMLInputElement).value = "2024";
           else (i as HTMLInputElement).value = "";
      });
      
      document.querySelectorAll('input[type="checkbox"]').forEach(c => {
          const cb = c as HTMLInputElement;
          const defaults = ['incEnglish', 'exBooks', 'exConf', 'exReview', 'incRCT'];
          cb.checked = defaults.includes(cb.id);
      });

      document.querySelectorAll('textarea').forEach(t => (t as HTMLTextAreaElement).value = "");
      document.querySelectorAll('input[type="file"]').forEach(f => (f as HTMLInputElement).value = "");
      
      // Clear prompt and editable boxes
      document.querySelectorAll('.ai-prompt-box').forEach(el => (el as HTMLElement).innerText = "");
      for (let i = 1; i <= 5; i++) {
          const p = document.getElementById(`themePrompt${i}`);
          if (p) p.innerText = "";
          const s = document.getElementById(`themeSummary${i}`);
          if (s) (s as HTMLTextAreaElement).value = "";
          const n = document.getElementById(`dispName${i}`);
          if (n) n.innerText = "";
          
          // Clear discussion specific fields
          const dp = document.getElementById(`discThemePrompt${i}`);
          if (dp) dp.innerText = "";
          const ds = document.getElementById(`discThemeSummary${i}`);
          if (ds) (ds as HTMLTextAreaElement).value = "";
          
          // Clear conclusion specific fields
          const cp = document.getElementById(`conclusionPromptBox`);
          if (cp) {
              cp.innerText = "";
              cp.style.display = 'none';
          }
          const cb = document.getElementById(`copyConclusionBtn`);
          if (cb) cb.style.display = 'none';
      }
      document.querySelectorAll('.result-input-area').forEach(el => (el as HTMLElement).innerText = "");
      const summaryMatrix = document.getElementById('summaryMatrixTable');
      if (summaryMatrix) (summaryMatrix as HTMLElement).innerText = "";
      const manualPaste = document.getElementById('manualTablePaste');
      if (manualPaste) manualPaste.innerText = "";
      
      // Hide sections
      ['screeningStats', 'deduplicationSection', 'filteredRefsSection', 'manualSelectionSection', 'finalRefsSection', 'exclusionContainer', 'geminiResultsSection', 'manualOutputSection', 'methodsPromptBox', 'searchPromptBox', 'themeSuggestionPromptBox', 'discPromptBox', 'abstractPromptBox', 'coverPromptBox', 'methodElaborationSection', 'aiExStatBox', 'discPromptContainer', 'discResultsPasteSection'].forEach(id => {
          const el = document.getElementById(id);
          if (el) el.style.display = 'none';
      });

      // Clear lists
      ['filteredRefsList', 'finalRefsList', 'ref-sidebar-list', 'used-references-list', 'authorsContainer', 'affilsContainer'].forEach(id => {
          const el = document.getElementById(id);
          if (el) el.innerHTML = "";
      });

      window.renderAuthors();
      window.renderAffiliations();
      window.syncAll();
      window.updateFinalCounts();
      window.updatePrismaFigure();
      
      // Reset tab to home
      window.openTab(null, 'home');
      
      // Remove active states
      document.querySelectorAll('.active-textarea').forEach(el => el.classList.remove('active-textarea'));
      (window as any).activeDraftTextarea = null;

      // Dispatch event for React
      window.dispatchEvent(new CustomEvent('app:reset'));

      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      return true;
    }
    return false;
  };

  window.genMethodsPrompt = function() {
    const titleVal = (document.getElementById('globalTitle') as HTMLInputElement)?.value || "";
    const title = titleVal ? `"${titleVal}"` : `"[Insert Paper Title/Research Topic]"`;
    
    const dbDisplayNames: Record<string, string> = {
      wos: "Web of Science (WoS)",
      scopus: "Scopus",
      ncbi: "NCBI (PubMed)",
      scholar: "Google Scholar",
      cochrane: "Cochrane Library",
      embase: "Embase",
      ieee: "IEEE Xplore",
      cinahl: "CINAHL",
      psycinfo: "PsycINFO",
      eric: "ERIC (Education)",
      sciencedirect: "ScienceDirect (Elsevier)",
      wiley: "Wiley Online Library"
    };

    let nTotalIdent = 0;
    let nTotalScreen = 0;
    const databasesUsed: string[] = [];

    Object.entries(dbDisplayNames).forEach(([key, name]) => {
      const initLen = window.rawData?.[key]?.length || 0;
      const screenLen = window.temporaryFilteredLists?.[key]?.length || 0;
      nTotalIdent += initLen;
      nTotalScreen += screenLen;
      if (initLen > 0) {
        databasesUsed.push(`${name} (${initLen} records identified, ${screenLen} after initial screening)`);
      }
    });

    if (databasesUsed.length === 0) {
      databasesUsed.push("[No databases uploaded yet; please upload database CSVs in Section 1]");
    }

    const startY = (document.getElementById('startYear') as HTMLInputElement)?.value || "2010";
    const endY = (document.getElementById('endYear') as HTMLInputElement)?.value || "2024";
    const incEnglish = (document.getElementById('incEnglish') as HTMLInputElement)?.checked ?? true;

    const nFinalIncl = window.filteredList?.filter(f => f.active && f.finalActive).length || 0;
    const nFinalExcl = (window.filteredList?.filter(f => f.active).length || 0) - nFinalIncl;

    // Exclusion reasons list
    const excList: string[] = [];
    if (incEnglish) excList.push("Non-English publications / publications that were not written in English");
    excList.push(`Published before ${startY} or after ${endY}`);
    
    const formatsExcl: string[] = [];
    if ((document.getElementById('exBooks') as HTMLInputElement)?.checked) formatsExcl.push("books/book chapters");
    if ((document.getElementById('exConf') as HTMLInputElement)?.checked) formatsExcl.push("conference proceedings/papers");
    if ((document.getElementById('exReview') as HTMLInputElement)?.checked) formatsExcl.push("review articles");
    if ((document.getElementById('exEditorial') as HTMLInputElement)?.checked) formatsExcl.push("editorials/letters");
    if (formatsExcl.length > 0) {
      excList.push(`Non-original formats (classified as: ${formatsExcl.join(', ')})`);
    }
    
    if ((document.getElementById('incRCT') as HTMLInputElement)?.checked) {
       excList.push("Non-Randomized Controlled Trial (RCT) designs (limited to RCTs only)");
    }

    // AI Exclusions
    const aiExTypes: string[] = [];
    if (window.aiExclusions?.designs?.length > 0) aiExTypes.push(`irrelevant study designs: ${window.aiExclusions.designs.join(', ')}`);
    if (window.aiExclusions?.populations?.length > 0) aiExTypes.push(`unmatched populations: ${window.aiExclusions.populations.join(', ')}`);
    if (window.aiExclusions?.interventions?.length > 0) aiExTypes.push(`irrelevant interventions/exposures: ${window.aiExclusions.interventions.join(', ')}`);
    if (window.aiExclusions?.outcomes?.length > 0) aiExTypes.push(`non-target outcomes: ${window.aiExclusions.outcomes.join(', ')}`);
    if (window.aiExclusions?.geo?.length > 0) aiExTypes.push(`excluded geographic locations: ${window.aiExclusions.geo.join(', ')}`);
    if (window.aiExclusions?.kw?.length > 0) aiExTypes.push(`unwanted subject keywords: ${window.aiExclusions.kw.join(', ')}`);
    if (aiExTypes.length > 0) {
       excList.push(`AI Smart Scan screening parameter exclusions (${aiExTypes.join('; ')})`);
    }

    const reasonsMarkdown = excList.map((item, idx) => `${idx + 1}. ${item}`).join('\n');

    // Counts
    const nDups = window.globalExCounts.dup || 0;
    const nExScreen = (window.globalExCounts.year + window.globalExCounts.lang + window.globalExCounts.docType + window.globalExCounts.keyword + (window.globalExCounts.aiEx || 0)) || 0;
    const nManualEx = nTotalScreen - nFinalIncl;

    // Fetch tab 1 keywords & search results
    const tab1PasteEl = document.getElementById('assistantGeminiSearchResultPaste');
    const tab1PasteText = tab1PasteEl ? tab1PasteEl.innerText.trim() : "";

    // Fetch tab 3 categories to screen prompt result
    const catPasteEl = document.getElementById('categoriesToScreenResultPaste');
    const catPasteText = catPasteEl ? catPasteEl.innerText.trim() : "";

    // Fetch tab 2 research questions and objectives
    const qBox = document.getElementById('refinedResearchQuestions');
    const qText = qBox ? qBox.innerText.trim() : "";

    const objBox = document.getElementById('refinedObjectives');
    const objText = objBox ? objBox.innerText.trim() : "";

    // Build the Systematic Literature Review Protocol Draft
    const promptText = `You are an expert academic researcher and scientific writer specializing in systematic reviews and PRISMA 2020 reporting standards.

Your task is to write a complete, publication-ready "Materials and Methods" section for a systematic literature review.

Before writing, use the information provided below. If any information is missing, indicate "[Information Required]" rather than inventing details.

Use formal academic language suitable for publication in a peer-reviewed journal.

Structure the Materials and Methods section using the following headings:

2.0. Materials and Methods
2.1.  Systematic Review Design and Protocol
2.2. Information Sources and Search Strategy
2.3. Selection Criteria
2.4. Eligibility Criteria
 2.4.1. Inclusion Criteria
 2.4.2. Exclusion Criteria
2.5. Screening and Eligibility
2.6. Quality Assessment
2.7. Data Extraction
2.8. Data Synthesis

Use complete paragraphs rather than bullet points where appropriate.

The review information is as follows:

---

## REVIEW TOPIC

Review title:
${titleVal ? `"${titleVal}"` : `[Insert review title]`}

Research question:
${qText || "[Information Required]"}

Review objective(s):
${objText || "[Information Required]"}

Framework used (PICO/PECO/SPIDER/etc.):
[Information Required]

---

## REPORTING GUIDELINES

Reporting standard:
PRISMA 2020

Protocol registration:
[PROSPERO registration number or "Not registered"]

---

## DATABASES SEARCHED

Databases searched:
${databasesUsed.length > 0 ? databasesUsed.map(db => `* ${db}`).join('\n') : "* Scopus\n* Web of Science\n* NCBI (PubMed)"}

Search period:
From January ${startY} to December ${endY}

Date search conducted:
May 31, 2026

---

## SEARCH STRATEGY

Primary keywords:
${tab1PasteText ? "[Extracted from Tab 1 details below]" : "[Insert keywords]"}

Boolean search string(s):
${tab1PasteText ? "[Extracted from Tab 1 details below]" : "[Insert exact search strings]"}

Were database-specific modifications used?
[Information Required]

Reference list searching performed?
[Information Required]

Manual searching performed?
[Information Required]

---

## SEARCH RESULTS

Records identified:

${Object.entries(dbDisplayNames).map(([key, name]) => {
  const initCount = window.rawData?.[key]?.length || 0;
  return initCount > 0 ? `${name}: ${initCount}` : null;
}).filter(Boolean).join('\n') || '[No database records uploaded yet]'}

Other databases/results:
0

Additional records identified manually:
0

Total records identified:
${nTotalIdent}

---

## DUPLICATE REMOVAL

Duplicates removed:
${nDups}

Records remaining after duplicate removal:
${nTotalIdent - nDups}

---

## TITLE AND ABSTRACT SCREENING

Records screened:
${nTotalIdent - nDups}

Records excluded:
${nExScreen}

Reasons for exclusion:
${reasonsMarkdown || 'Did not meet predefined abstract/title inclusion parameters'}
${catPasteText ? `\nDetailed exclusions and reasons (from Categories to Screen Gemini Result):\n${catPasteText}` : ''}

---

## FULL-TEXT ELIGIBILITY ASSESSMENT

Full-text articles assessed:
${nTotalScreen}

Full-text articles excluded:
${nManualEx < 0 ? 0 : nManualEx}

Reasons for exclusion and counts:

* Wrong population:
  [Information Required]

* Wrong intervention/exposure:
  [Information Required]

* Wrong outcome:
  [Information Required]

* Wrong study design:
  [Information Required]

* Insufficient data:
  [Information Required]

* Full text unavailable:
  [Information Required]

* Other:
  ${nManualEx < 0 ? 0 : nManualEx}

---

## FINAL INCLUSION

Studies included in qualitative synthesis:
${nFinalIncl}

Studies included in quantitative synthesis/meta-analysis:
[Information Required or N/A]

---

## REVIEWERS

Number of reviewers:
[Information Required]

Screening performed independently?
[Information Required]

Method for resolving disagreements:
[Consensus / Third reviewer / Other]

Use of AI-assisted screening:
[Information Required]

If yes, specify tool:
[Information Required]

Role of AI:
[Information Required]

Human verification performed?
[Information Required]

---

## ELIGIBILITY CRITERIA

Inclusion criteria:

1. Focused on: ${titleVal ? `"${titleVal}"` : 'the research topic'}
2. Peer-reviewed original academic literature
3. Published from year ${startY} to ${endY}
4. Written in English (if applicable)

Exclusion criteria:

${reasonsMarkdown || 'Did not meet inclusion scope'}
${catPasteText ? `\nDetailed exclusions and reasons (from Categories to Screen Gemini Result):\n${catPasteText}` : ''}

Language restrictions:
${incEnglish ? 'English only' : '[Information Required]'}

Publication years included:
${startY} – ${endY}

Publication types included:
Original journal and research articles, excluding conference proceedings/chapters (if configured)

---

## QUALITY ASSESSMENT

Risk-of-bias or quality assessment tool used:

Examples:

* Newcastle–Ottawa Scale (NOS)
* Joanna Briggs Institute (JBI)
* ROBINS-I
* RoB 2
* SYRCLE
* CASP

Assessment domains:
[Information Required]

Number of reviewers:
[Information Required]

Method for resolving disagreements:
[Information Required]

---

## DATA EXTRACTION

Data extracted:

* Authors
* Publication year
* Country
* Study design
* Population/sample
* Sample size
* Exposure/intervention
* Outcomes
* Key findings

Additional variables extracted:
[Information Required]

Data extraction performed by:
[Information Required]

---

## DATA SYNTHESIS

Type of synthesis:
Qualitative narrative synthesis

Reason for synthesis approach:
To map, synthesize, and contrast thematic issues across selected literature.

Methods used to identify themes, trends, or patterns:
Thematic content analysis

Subgroup analyses performed?
[Information Required]

Sensitivity analyses performed?
[Information Required]

---

## OUTPUT REQUIREMENTS

Write a complete Materials and Methods section in formal academic style.

Ensure consistency between all reported numbers.

Ensure PRISMA terminology is used correctly.

Do not fabricate information.

Maintain journal-ready language suitable for publication. Please extract all the information from this apps${tab1PasteText ? `

---

## ADDITIONAL SEARCH STRATEGY INFORMATION (PASSED FROM TAB 1 ASSISTANT)

Below is the search keyword/string data pasted in Tab 1 for reference:
${tab1PasteText}` : ""}${catPasteText ? `

---

## ADDITIONAL CATEGORIES TO SCREEN EXCLUSION RESULTS (PASSED FROM TAB 3 CATEGORIES TO SCREEN RESULT BOX)

Below is the categories/exclusion reasons data pasted in Tab 3 for reference:
${catPasteText}` : ""}`;

    const finalPromptText = promptText
      .replace(/\brefs\b/g, 'records')
      .replace(/\bref\b/g, 'record')
      .replace(/\bRefs\b/g, 'Records')
      .replace(/\bRef\b/g, 'Record');

    const promptBox = document.getElementById('methodsPromptBox');
    const copyBtn = document.getElementById('copyMethodsPromptBtn');
    if (promptBox && copyBtn) {
      promptBox.innerText = finalPromptText;
      promptBox.style.display = 'block';
      copyBtn.style.display = 'block';
      promptBox.scrollIntoView({ behavior: 'smooth' });
    }
  };

  (window as any).copyMethodsPromptToClipboard = function() {
    const textEl = document.getElementById('methodsPromptBox');
    if (!textEl) return;
    const text = textEl.textContent || textEl.innerText;
    
    navigator.clipboard.writeText(text).then(() => {
      alert("Materials and Methods Synthesis Prompt copied for Gemini expansion!");
    }).catch(() => {
      const range = document.createRange();
      range.selectNodeContents(textEl);
      const sel = window.getSelection();
      if (sel) {
        sel.removeAllRanges();
        sel.addRange(range);
      }
      document.execCommand('copy');
      alert("Prompt selected! Please press Ctrl+C or Cmd+C to copy.");
    });
  };

  (window as any).copyPromptToClipboard = function() {
    const textEl = document.getElementById('geminiPromptContent');
    if (!textEl) return;
    const text = textEl.textContent || textEl.innerText;
    
    navigator.clipboard.writeText(text).then(() => {
      alert("Gemini Expansion Command copied to clipboard successfully!");
    }).catch(() => {
      const range = document.createRange();
      range.selectNodeContents(textEl);
      const sel = window.getSelection();
      if (sel) {
        sel.removeAllRanges();
        sel.addRange(range);
      }
      document.execCommand('copy');
      alert("Expansion Command selected! Please press Ctrl+C or Cmd+C to copy.");
    });
  };

  // Sync Methods Elaboration to Draft & Auto-Add References
  const methInput = document.getElementById('methodsElaborationInput');
  if (methInput) {
    methInput.addEventListener('paste', (e) => {
        e.preventDefault();
        const clipboardEvent = e as ClipboardEvent;
        const text = clipboardEvent.clipboardData?.getData('text/plain') || '';
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            selection.deleteFromDocument();
            const textNode = document.createTextNode(text);
            selection.getRangeAt(0).insertNode(textNode);
            
            const range = document.createRange();
            range.setStartAfter(textNode);
            selection.removeAllRanges();
            selection.addRange(range);
        } else {
            methInput.innerText += text;
        }
        methInput.dispatchEvent(new Event('input', { bubbles: true }));
    });
    methInput.addEventListener('input', () => {
      const isDiv = methInput.tagName !== 'TEXTAREA';
      const text = isDiv ? (methInput as HTMLElement).innerText : (methInput as HTMLTextAreaElement).value;
      // Auto-detect references
      (window as any).addReferencesFromText(text, 'tab3');
      window.syncPaperDraft(true);
    });
  }

  // Sync and handle paste for Assistant Gemini Search Result Paste
  const assistantPaste = document.getElementById('assistantGeminiSearchResultPaste');
  if (assistantPaste) {
    assistantPaste.addEventListener('paste', (e) => {
        e.preventDefault();
        const clipboardEvent = e as ClipboardEvent;
        const text = clipboardEvent.clipboardData?.getData('text/plain') || '';
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            selection.deleteFromDocument();
            const textNode = document.createTextNode(text);
            selection.getRangeAt(0).insertNode(textNode);
            
            const range = document.createRange();
            range.setStartAfter(textNode);
            selection.removeAllRanges();
            selection.addRange(range);
        } else {
            assistantPaste.innerText += text;
        }
        assistantPaste.dispatchEvent(new Event('input', { bubbles: true }));
    });
    assistantPaste.addEventListener('input', () => {
        // Triggers saving / synchronization state check if needed
    });
  }

  // Sync and handle paste for Categories to Screen Result Paste
  const categoriesToScreenResultPaste = document.getElementById('categoriesToScreenResultPaste');
  if (categoriesToScreenResultPaste) {
    categoriesToScreenResultPaste.addEventListener('paste', (e) => {
        e.preventDefault();
        const clipboardEvent = e as ClipboardEvent;
        const text = clipboardEvent.clipboardData?.getData('text/plain') || '';
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            selection.deleteFromDocument();
            const textNode = document.createTextNode(text);
            selection.getRangeAt(0).insertNode(textNode);
            
            const range = document.createRange();
            range.setStartAfter(textNode);
            selection.removeAllRanges();
            selection.addRange(range);
        } else {
            categoriesToScreenResultPaste.innerText += text;
        }
        categoriesToScreenResultPaste.dispatchEvent(new Event('input', { bubbles: true }));
    });
    categoriesToScreenResultPaste.addEventListener('input', () => {
        // Triggers saving / synchronization state check
    });
  }

  const manualPasteBox = document.getElementById('manualTablePaste');
  if (manualPasteBox) {
    manualPasteBox.addEventListener('paste', (e) => {
        e.preventDefault();
        const clipboardEvent = e as ClipboardEvent;
        const text = clipboardEvent.clipboardData?.getData('text/plain') || '';
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            selection.deleteFromDocument();
            const textNode = document.createTextNode(text);
            selection.getRangeAt(0).insertNode(textNode);
            
            const range = document.createRange();
            range.setStartAfter(textNode);
            selection.removeAllRanges();
            selection.addRange(range);
        } else {
            manualPasteBox.innerText += text;
        }
        manualPasteBox.dispatchEvent(new Event('input', { bubbles: true }));
    });
    manualPasteBox.addEventListener('input', () => {
        const isDiv = manualPasteBox.tagName !== 'TEXTAREA';
        const text = isDiv ? (manualPasteBox as HTMLElement).innerText : (manualPasteBox as HTMLTextAreaElement).value;
        (window as any).addReferencesFromText(text, 'tab3');
        if (typeof (window as any).syncManualPaste === 'function') {
            (window as any).syncManualPaste();
        }
    });
  }

  // Sync Theme Summaries (Tab 4)
  for (let i = 1; i <= 5; i++) {
    const ts = document.getElementById(`themeSummary${i}`);
    if (ts) {
        ts.addEventListener('paste', (e) => {
            e.preventDefault();
            const clipboardEvent = e as ClipboardEvent;
            const text = clipboardEvent.clipboardData?.getData('text/plain') || '';
            const selection = window.getSelection();
            if (selection && selection.rangeCount > 0) {
                selection.deleteFromDocument();
                const textNode = document.createTextNode(text);
                selection.getRangeAt(0).insertNode(textNode);
                
                // update cursor position
                const range = document.createRange();
                range.setStartAfter(textNode);
                selection.removeAllRanges();
                selection.addRange(range);
            } else {
                ts.innerText += text;
            }
            ts.dispatchEvent(new Event('input', { bubbles: true }));
        });
        ts.addEventListener('input', () => {
             const text = (ts as HTMLElement).innerText;
             (window as any).addReferencesFromText(text);
             window.syncPaperDraft(true);
        });
    }
    const ds = document.getElementById(`discThemeSummary${i}`);
    if (ds) {
        ds.addEventListener('paste', (e) => {
            e.preventDefault();
            const clipboardEvent = e as ClipboardEvent;
            const text = clipboardEvent.clipboardData?.getData('text/plain') || '';
            const selection = window.getSelection();
            if (selection && selection.rangeCount > 0) {
                selection.deleteFromDocument();
                const textNode = document.createTextNode(text);
                selection.getRangeAt(0).insertNode(textNode);
                
                // update cursor position
                const range = document.createRange();
                range.setStartAfter(textNode);
                selection.removeAllRanges();
                selection.addRange(range);
            } else {
                ds.innerText += text;
            }
            ds.dispatchEvent(new Event('input', { bubbles: true }));
        });
        ds.addEventListener('input', () => {
             const text = (ds as HTMLElement).innerText;
             (window as any).addReferencesFromText(text);
             window.syncPaperDraft(true);
        });
    }
  }

  const resultsInput = document.getElementById('geminiResultsInput');
  if (resultsInput) {
    resultsInput.addEventListener('input', () => {
        const isDiv = resultsInput.tagName !== 'TEXTAREA';
        const text = isDiv ? (resultsInput as HTMLElement).innerText : (resultsInput as HTMLTextAreaElement).value;
        (window as any).addReferencesFromText(text, 'tab2');
        window.syncPaperDraft(true);
    });
  }

  const finalIntroEdit = document.getElementById('finalIntroEdit');
  if (finalIntroEdit) {
    finalIntroEdit.addEventListener('input', () => {
        const isDiv = finalIntroEdit.tagName !== 'TEXTAREA';
        const text = isDiv ? (finalIntroEdit as HTMLElement).innerText : (finalIntroEdit as HTMLTextAreaElement).value;
        (window as any).addReferencesFromText(text);
        window.syncPaperDraft(true);
    });
  }

  const refinedIntro = document.getElementById('refinedIntro');
  if (refinedIntro) {
    refinedIntro.addEventListener('input', () => {
        const text = refinedIntro.innerText;
        (window as any).addReferencesFromText(text);
        window.syncPaperDraft(true);
    });
    refinedIntro.addEventListener('paste', (e) => {
        e.preventDefault();
        const text = e.clipboardData?.getData('text/plain') || '';
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            selection.deleteFromDocument();
            selection.getRangeAt(0).insertNode(document.createTextNode(text));
        } else {
            refinedIntro.innerText += text;
        }
        refinedIntro.dispatchEvent(new Event('input', { bubbles: true }));
    });
  }

  const refinedResearchQuestions = document.getElementById('refinedResearchQuestions');
  if (refinedResearchQuestions) {
    refinedResearchQuestions.addEventListener('input', () => {
        window.syncPaperDraft(true);
    });
    refinedResearchQuestions.addEventListener('paste', (e) => {
        e.preventDefault();
        const text = e.clipboardData?.getData('text/plain') || '';
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            selection.deleteFromDocument();
            selection.getRangeAt(0).insertNode(document.createTextNode(text));
        } else {
            refinedResearchQuestions.innerText += text;
        }
        refinedResearchQuestions.dispatchEvent(new Event('input', { bubbles: true }));
    });
  }

  const refinedObjectives = document.getElementById('refinedObjectives');
  if (refinedObjectives) {
    refinedObjectives.addEventListener('input', () => {
        window.syncPaperDraft(true);
    });
    refinedObjectives.addEventListener('paste', (e) => {
        e.preventDefault();
        const text = e.clipboardData?.getData('text/plain') || '';
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            selection.deleteFromDocument();
            selection.getRangeAt(0).insertNode(document.createTextNode(text));
        } else {
            refinedObjectives.innerText += text;
        }
        refinedObjectives.dispatchEvent(new Event('input', { bubbles: true }));
    });
  }

  const finalDiscEdit = document.getElementById('finalDiscEdit');
  if (finalDiscEdit) {
    finalDiscEdit.addEventListener('input', () => {
        const isDiv = finalDiscEdit.tagName !== 'TEXTAREA';
        const text = isDiv ? (finalDiscEdit as HTMLElement).innerText : (finalDiscEdit as HTMLTextAreaElement).value;
        (window as any).addReferencesFromText(text, 'tab6');
        window.syncPaperDraft(true);
    });
  }

  const finalDiscRefs = document.getElementById('finalDiscRefs');
  if (finalDiscRefs) {
    finalDiscRefs.addEventListener('input', () => {
        if (typeof (window as any).syncAndArrangeReferences === 'function') {
            (window as any).syncAndArrangeReferences('finalDiscRefs');
        }
        window.syncPaperDraft(true);
    });
  }

  const matrixInput = document.getElementById('summaryMatrixTable');
  if (matrixInput) {
    matrixInput.addEventListener('input', () => {
        const isDiv = matrixInput.tagName !== 'TEXTAREA';
        const text = isDiv ? (matrixInput as HTMLElement).innerText : (matrixInput as HTMLTextAreaElement).value;
        (window as any).addReferencesFromText(text, 'tab4');
        window.syncPaperDraft(true);
    });
  }

  const themeBasedMatrixInput = document.getElementById('themeBasedMatrixTable');
  if (themeBasedMatrixInput) {
    themeBasedMatrixInput.addEventListener('input', () => {
        const isDiv = themeBasedMatrixInput.tagName !== 'TEXTAREA';
        const text = isDiv ? (themeBasedMatrixInput as HTMLElement).innerText : (themeBasedMatrixInput as HTMLTextAreaElement).value;
        (window as any).addReferencesFromText(text, 'tab4');
        window.syncPaperDraft(true);
    });
  }

  const concInput = document.getElementById('conclusionTextArea');
  if (concInput) {
    concInput.addEventListener('input', () => {
        const isDiv = concInput.tagName !== 'TEXTAREA';
        const text = isDiv ? (concInput as HTMLElement).innerText : (concInput as HTMLTextAreaElement).value;
        (window as any).addReferencesFromText(text, 'tab7');
        window.syncPaperDraft(true);
    });
  }

  (window as any).addReferencesFromText = function(text: string, tabSource?: string) {
    if (!text) return;
    const usedRefs = (window as any).usedReferences as Set<number>;
    let added = false;
    let localDetected: string[] = [];
    
    // Pattern 1: [ID: 12] or REFERENCE ID 12 or ID: 12 or [12]
    const idRegex = /(?:\[ID: |REFERENCE ID |ID:? |\[)(\d+)(?:\s*\])?/gi;
    let match;
    while ((match = idRegex.exec(text)) !== null) {
      const id = parseInt(match[1]) - 1;
      if (id >= 0 && id < window.filteredList.length) {
        if (!usedRefs.has(id)) {
          usedRefs.add(id);
          added = true;
        }
        const item = window.filteredList[id];
        localDetected.push(`[ID: ${id+1}] ${item.data.authors} (${item.data.year})`);
      }
    }
    
    // Pattern 2: (Author, Year) or Author (Year) or list format like "Doe, J. (2020)"
    window.filteredList.forEach((item, idx) => {
        const firstAuthor = (item.data.authors || "").split(',')[0].trim();
        const year = item.data.year || "";
        
        if (!firstAuthor || firstAuthor.length < 2 || !year) return;

        // Try loose matching on first author and year
        const cleanAuthor = firstAuthor.replace(/[^a-zA-Z]/g, '');
        const escapedAuthor = firstAuthor.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        
        // Exact search for Author (Year) or (Author, Year)
        const citeRegex = new RegExp(`(?:${escapedAuthor})[\\s,.]*\\(?(?:${year})\\)?`, 'i');
        const isMentioned = citeRegex.test(text);
        
        if (isMentioned) {
            if (!usedRefs.has(idx) && item.active) {
                usedRefs.add(idx);
                added = true;
            }
            localDetected.push(`${item.data.authors} (${item.data.year})`);
        }
    });

    // Update local "Detected" UI if tabSource provided
    if (tabSource) {
        const listEl = document.getElementById(`detected-refs-${tabSource}-list`);
        const boxEl = document.getElementById(`detected-refs-${tabSource}`);
        if (listEl && boxEl) {
            const uniqueDetected = Array.from(new Set(localDetected));
            if (uniqueDetected.length > 0) {
                listEl.innerHTML = uniqueDetected.map(r => `<div class="truncate">- ${r}</div>`).join('');
                boxEl.classList.remove('hidden');
            } else {
                boxEl.classList.add('hidden');
            }
        }
    }

    if (added) {
      window.updateReferenceList();
      // Ensure the bibliography refresh triggers a sync to the draft tab's APA section
      const draftRefs = document.getElementById('draftReferences') as HTMLTextAreaElement;
      if (draftRefs) window.syncPaperDraft(true); 
    }
  };

  window.renderAuthors();
  window.renderAffiliations();
}
