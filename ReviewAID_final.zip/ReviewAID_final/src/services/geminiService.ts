function getSafeApiKey(): string {
  try {
    const k = localStorage.getItem('user_gemini_api_key') || '';
    if (k) (window as any).__user_gemini_api_key = k;
    return k;
  } catch {
    return (window as any).__user_gemini_api_key || '';
  }
}

export async function callGemini(prompt: string): Promise<string> {
  const customKey = getSafeApiKey();

  // Direct REST API fallback for Windows / Standalone Electron builds without an active Express server
  if (customKey && customKey.trim()) {
    try {
      const cleanKey = customKey.trim();
      const directUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${cleanKey}`;
      const response = await fetch(directUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: prompt
                }
              ]
            }
          ]
        }),
      });

      if (!response.ok) {
        const errObj = await response.json().catch(() => ({}));
        const errMsg = errObj.error?.message || response.statusText || 'Direct API call failed';
        throw new Error(errMsg);
      }

      const data = await response.json();
      const textOut = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (textOut) {
        return textOut;
      }
      throw new Error('No text content returned in candidates from direct Gemini call');
    } catch (directErr) {
      console.error('Direct Google GenAI API Call failed inside geminiService, trying Express server fallback:', directErr);
    }
  }

  try {
    const response = await fetch('/api/gemini', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Gemini-API-Key': customKey,
      },
      body: JSON.stringify({ prompt }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to call Gemini API');
    }

    const data = await response.json();
    return data.text;
  } catch (error) {
    console.error('Gemini Service Error:', error);
    throw error;
  }
}

export async function splitIntroduction(text: string): Promise<{ introduction: string; references: string }> {
  try {
    const response = await fetch('/api/gemini/split-intro', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Gemini-API-Key': getSafeApiKey(),
      },
      body: JSON.stringify({ text }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to split introduction');
    }

    return await response.json();
  } catch (error) {
    console.error('splitIntroduction Error:', error);
    throw error;
  }
}

export async function synthesizeDiscussion(themes: Array<{ id: number; name: string; text: string }>): Promise<{ discussion: string; references: string }> {
  try {
    const response = await fetch('/api/gemini/synthesize-discussion', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Gemini-API-Key': getSafeApiKey(),
      },
      body: JSON.stringify({ themes }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to synthesize discussion');
    }

    return await response.json();
  } catch (error) {
    console.error('synthesizeDiscussion Error:', error);
    throw error;
  }
}

export async function splitDiscussion(text: string): Promise<{ discussion: string; references: string }> {
  try {
    const response = await fetch('/api/gemini/split-discussion', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Gemini-API-Key': getSafeApiKey(),
      },
      body: JSON.stringify({ text }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to split discussion');
    }

    return await response.json();
  } catch (error) {
    console.error('splitDiscussion Error:', error);
    throw error;
  }
}
