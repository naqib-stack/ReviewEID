@echo off

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Downloading Node.js...

    powershell -Command "Invoke-WebRequest -Uri 'https://nodejs.org/dist/latest/node-v24.4.1-x64.msi' -OutFile '%TEMP%\node.msi'"

    echo Installing Node.js...
    msiexec /i "%TEMP%\node.msi" /quiet /norestart

    timeout /t 10
)

REM Change to the folder containing this BAT file
cd /d "%~dp0"

echo Current directory: %CD%

if not exist package.json (
    echo ERROR: package.json not found in:
    echo %CD%
    pause
    exit /b 1
)

call npm install
call npm run build
call npx electron-builder --win --x64

pause