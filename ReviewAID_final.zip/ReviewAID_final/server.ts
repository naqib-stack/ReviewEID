import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Recursive search to get any file matching "logo" in name inside the workspace
function findLogoFile(dir: string, depth = 0): string | null {
  if (depth > 2) return null; // Avoid searching too deep
  try {
    const files = fs.readdirSync(dir);
    
    // First pass: look in current level files
    for (const file of files) {
      const fullPath = path.join(dir, file);
      try {
        const stat = fs.statSync(fullPath);
        if (!stat.isDirectory()) {
          const lowerFile = file.toLowerCase();
          const isImage = /\.(png|jpe?g|svg|webp|gif|bmp)$/i.test(lowerFile);
          if (isImage && (lowerFile.includes("logo") || file === "logo PKTAAB EID.png")) {
            return fullPath;
          }
        }
      } catch (e) {
        // Safe skip for inaccessible files
      }
    }
    
    // Second pass: go into subdirectories
    for (const file of files) {
      if (
        file === "node_modules" || 
        file === "dist" || 
        file === ".git" || 
        file === ".next" || 
        file === "build" ||
        file === "coverage"
      ) {
        continue;
      }
      const fullPath = path.join(dir, file);
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          const found = findLogoFile(fullPath, depth + 1);
          if (found) return found;
        }
      } catch (e) {
        // Safe skip
      }
    }
  } catch (err) {
    // Safe skip
  }
  return null;
}

const isProd = process.env.NODE_ENV === "production";
const PORT = 3000;

// Helper function to dynamically initialize GoogleGenAI with either user-supplied header key or environment key
function getAiClient(req: express.Request): GoogleGenAI {
  const userApiKey = req.headers["x-gemini-api-key"] as string;
  const activeKey = (userApiKey && userApiKey.trim()) || process.env.GEMINI_API_KEY;
  if (!activeKey) {
    throw new Error("GEMINI_API_KEY is not set. Please click the 'Gemini Key' button in the application header to paste your API key.");
  }
  return new GoogleGenAI({
    apiKey: activeKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "50mb" })); // Increase limits for large text inputs like discussion themes

  // Auto logo detection endpoints
  app.get("/api/detected-logo", (req, res) => {
    try {
      const foundFile = findLogoFile(process.cwd());
      if (foundFile) {
        res.json({
          found: true,
          filename: path.basename(foundFile),
          url: `/api/logo-image?t=${Date.now()}`
        });
      } else {
        res.json({ found: false });
      }
    } catch (err) {
      res.json({ found: false });
    }
  });

  app.get("/api/logo-image", (req, res) => {
    try {
      const foundFile = findLogoFile(process.cwd());
      if (foundFile && fs.existsSync(foundFile)) {
        const ext = path.extname(foundFile).toLowerCase();
        let contentType = "image/png";
        if (ext === ".jpg" || ext === ".jpeg") contentType = "image/jpeg";
        else if (ext === ".svg") contentType = "image/svg+xml";
        else if (ext === ".webp") contentType = "image/webp";
        else if (ext === ".gif") contentType = "image/gif";

        res.setHeader("Content-Type", contentType);
        res.sendFile(foundFile);
      } else {
        // Return a refined fallback SVG if no file is found
        res.setHeader("Content-Type", "image/svg+xml");
        res.send(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 100" width="100%" height="100%" style="background:#f8fafc; border-radius:8px;">
          <rect width="100" height="100" fill="#4f46e5" rx="16"/>
          <path d="M50 30v40M30 50h40" stroke="#ffffff" stroke-width="8" stroke-linecap="round"/>
          <circle cx="50" cy="50" r="10" fill="none" stroke="#ffffff" stroke-width="4"/>
          <text x="120" y="45" font-family="system-ui, sans-serif" font-size="22" font-weight="900" fill="#0f172a">EID GROUP</text>
          <text x="120" y="70" font-family="system-ui, sans-serif" font-size="14" font-weight="600" fill="#64748b">Filtration &amp; Synthesis Tool</text>
        </svg>`);
      }
    } catch (error) {
      res.status(500).send("Error loading logo image");
    }
  });

  // API Routes
  app.post("/api/gemini", async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      const client = getAiClient(req);

      // Call Gemini 3.5 Flash for basic text / parsing tasks
      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
      });

      const text = response.text || "";
      res.json({ text });
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: error.message || "Failed to generate content" });
    }
  });

  // Dedicated endpoint for structured JSON splitting/refinement
  app.post("/api/gemini/split-intro", async (req, res) => {
    try {
      const { text } = req.body;
      if (!text) {
        return res.status(400).json({ error: "Text is required" });
      }

      const client = getAiClient(req);

      const prompt = `You are a professional scholastic parsing assistant.
Take the following raw Academic Introduction content which contains both writing and bibliography references.
Your objective is to separate them meticulously into two parts:
1. "introduction": Keep all the narrative writing paragraphs EXACTLY as they are originally written, with ABSOLUTELY ZERO rewriting, ZERO paraphrasing, ZERO stylistic changes, and ZERO omissions of sentences or words. Every word and standard in-text parenthetical or numeric citation (e.g., (Smith et al., 2021) or [3]) must be retained 100% verbatim.
2. "references": Separate all the final references list/bibliography list (e.g. APA styles bibliography at the end of the text) and output them nicely, clean, and properly formatted in APA style.

Do NOT alter, paraphrase, rewrite, summarize, or edit any words or technical terms. Every original sentence must be preserved 100% intact.

Respond ONLY with a valid JSON object matching this schema. Do not include markdown code block backticks (like \`\`\`json) or any additional commentary or text outside the JSON.

JSON Schema:
{
  "introduction": "the narrative paragraphs of the introduction, retaining standard parenthetical citations verbatim",
  "references": "the clean bibliography/references list properly separated"
}

Academic Introduction Content to Split:
${text}`;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              introduction: {
                type: Type.STRING,
                description: "the narrative paragraphs of the introduction, retaining standard parenthetical citations"
              },
              references: {
                type: Type.STRING,
                description: "the clean bibliography/references list properly separated"
              }
            },
            required: ["introduction", "references"]
          }
        }
      });

      const resultText = response.text || "";
      try {
        // Clean markdown backticks if any
        let cleanText = resultText.trim();
        if (cleanText.startsWith("```json")) {
          cleanText = cleanText.substring(7);
        }
        if (cleanText.startsWith("```")) {
          cleanText = cleanText.substring(3);
        }
        if (cleanText.endsWith("```")) {
          cleanText = cleanText.substring(0, cleanText.length - 3);
        }
        const json = JSON.parse(cleanText.trim());
        res.json(json);
      } catch (parseError) {
        console.error("JSON Parsing Error from Gemini Response:", resultText);
        res.json({
          introduction: text.substring(0, Math.floor(text.length * 0.8)),
          references: text.substring(Math.floor(text.length * 0.8)),
          raw: resultText
        });
      }
    } catch (error: any) {
      console.error("Split Intro API Error:", error);
      res.status(500).json({ error: error.message || "Failed to split introduction" });
    }
  });

  // Dedicated endpoint for structured JSON splitting/refinement of pasted combined discussion
  app.post("/api/gemini/split-discussion", async (req, res) => {
    try {
      const { text } = req.body;
      if (!text) {
        return res.status(400).json({ error: "Text is required" });
      }

      const client = getAiClient(req);

      const prompt = `You are an expert academic text editor.
Take the following raw discussion content which has been generated by Gemini or another model. It includes both discussion content and a compiled list of bibliography/references at the end.
Your job is to separate them meticulously into two parts:
1. "discussion": Extract and keep all narrative writing paragraphs of the discussion section EXACTLY as they are originally written, with ABSOLUTELY ZERO rewriting, ZERO paraphrasing, ZERO stylistic changes, and ZERO omissions of sentences or words. Every word and standard in-text parenthetical or numeric citation (e.g., (Johnson et al., 2020) or [4]) must be retained 100% verbatim.
2. "references": Extract and clean all the bibliographic reference list entries/bibliography listed at the end of the text. Format them nicely in professional standard APA format.

Do NOT alter, paraphrase, rewrite, summarize, or edit any words or technical terms. Every original sentence must be preserved 100% intact.

Respond ONLY with a valid JSON object matching the schema below. Do not include markdown code block backticks (like \`\`\`json) or any additional commentary or text outside the JSON.

JSON Schema:
{
  "discussion": "the complete narrative discussion writing, retaining standard parenthetical or numeric in-text citations verbatim",
  "references": "the clean reference list properly separated and formatted in APA style"
}

Academic Discussion Content to Split:
${text}`;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              discussion: {
                type: Type.STRING,
                description: "the complete narrative discussion writing, retaining standard parenthetical or numeric in-text citations"
              },
              references: {
                type: Type.STRING,
                description: "the clean reference list properly separated and formatted in APA style"
              }
            },
            required: ["discussion", "references"]
          }
        }
      });

      const resultText = response.text || "";
      try {
        let cleanText = resultText.trim();
        if (cleanText.startsWith("```json")) {
          cleanText = cleanText.substring(7);
        }
        if (cleanText.startsWith("```")) {
          cleanText = cleanText.substring(3);
        }
        if (cleanText.endsWith("```")) {
          cleanText = cleanText.substring(0, cleanText.length - 3);
        }
        const json = JSON.parse(cleanText.trim());
        res.json(json);
      } catch (parseError) {
        console.error("JSON Parsing Error from Gemini Response inside Split Discussion:", resultText);
        res.json({
          discussion: text.substring(0, Math.floor(text.length * 0.8)),
          references: text.substring(Math.floor(text.length * 0.8)),
          raw: resultText
        });
      }
    } catch (error: any) {
      console.error("Split Discussion API Error:", error);
      res.status(500).json({ error: error.message || "Failed to split discussion" });
    }
  });

  // Dedicated endpoint to synthesize discussion across themes and split references
  app.post("/api/gemini/synthesize-discussion", async (req, res) => {
    try {
      const { themes } = req.body; // Array of { id, text } or key-value mapping
      if (!themes || !Array.isArray(themes)) {
        return res.status(400).json({ error: "themes array is required" });
      }

      const client = getAiClient(req);

      const themesText = themes.map(t => `### ${t.name || `Theme ${t.id}`}\n${t.text}`).join("\n\n");

      const prompt = `You are an expert academic compilation assistant.
We have 5 distinct discussion theme inputs below.
Your objective is to extract and compile the exact narrative discussion text from these 5 themes together without changing a single word of the narrative, and separately compile all references/bibliography into a separate box.

Observe these strict rules:
1. Compile the narrative of Theme 1, Theme 2, Theme 3, Theme 4, and Theme 5 in order.
2. DO NOT change ANY wording, sentences, or phrasing. For example, if a sentence is "The physiological management of intestinal inflammation during oral exposure to Toxoplasma gondii is heavily governed by an integrated network containing host pattern recognition structures", it must remain EXACTLY that. Do NOT simplify, rewrite, condense, paraphrase or alter any specific biological or scientific details. Keep it 100% VERBATIM.
3. For each theme, separate the narrative text from the bibliography/reference list at the end.
4. Put all verbatim narrative paragraphs (with their in-text citations preserved exactly) into the "discussion" field.
5. Put all bibliographic reference list entries/bibliography sources into the "references" field. Eliminate duplicate references if any, while keeping their original verbatim spelling and formatting.

Respond ONLY with a valid JSON object matching the schema below. Do not include markdown code block backticks (like \`\`\`json) or any additional commentary or text outside the JSON.

JSON Schema:
{
  "discussion": "the complete verbatim narrative paragraphs compiled from the themes, with absolutely zero paraphrasing, modifications, or rewriting",
  "references": "compiled reference list from the themes"
}

Sections to compile verbatim:
${themesText}`;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              discussion: {
                type: Type.STRING,
                description: "the complete narrative discussion synthesis with in-text references"
              },
              references: {
                type: Type.STRING,
                description: "compiled bibliography list in APA format"
              }
            },
            required: ["discussion", "references"]
          }
        }
      });

      const resultText = response.text || "";
      try {
        let cleanText = resultText.trim();
        if (cleanText.startsWith("```json")) {
          cleanText = cleanText.substring(7);
        }
        if (cleanText.startsWith("```")) {
          cleanText = cleanText.substring(3);
        }
        if (cleanText.endsWith("```")) {
          cleanText = cleanText.substring(0, cleanText.length - 3);
        }
        const json = JSON.parse(cleanText.trim());
        res.json(json);
      } catch (parseError) {
        console.error("JSON Parsing Error from Gemini Discussion synthesis:", resultText);
        res.status(500).json({ error: "Failed to parse final discussion JSON from Gemini response.", raw: resultText });
      }
    } catch (error: any) {
      console.error("Synthesize Discussion API Error:", error);
      res.status(500).json({ error: error.message || "Failed to synthesize discussion" });
    }
  });

  // Direct routes for serving PWA configuration and install launcher icon
  app.get("/manifest.json", (req, res) => {
    res.setHeader("Content-Type", "application/json");
    res.sendFile(path.join(process.cwd(), "manifest.json"));
  });

  app.get("/logo_pwa_square.svg", (req, res) => {
    res.setHeader("Content-Type", "image/svg+xml");
    res.sendFile(path.join(process.cwd(), "logo_pwa_square.svg"));
  });

  // Vite Middleware or Static Serving
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
